# Variable actions
> **Enum macros:** {TF} = TRUE / FALSE; {TFN} = TRUE / FALSE / NOT_SET; {ANY_ALL} = ANY / ALL; {ITEM_MATCH} = EXACT / IGNORE_NAME_DURABILITY / IGNORE_NAME_DURABILITY_ENCHANTMENTS / CUSTOM_TAGS_CONTAINS / MINECRAFT_TAG / ITEM_TYPE; {DEG_RAD} = DEGREES / RADIANS; {CMP} = EXACTLY / IGNORE_STACK_SIZE / IGNORE_DURABILITY_AND_STACK_SIZE / TYPE_ONLY. Icon column omitted.


|  ID  |  Name  |  Description  |  Category/Subcategory  |  Arguments  |  Works with  |  Additional info  |  Status  |
|  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |
|  if_variable_block_equals  |  Block equals  |  Checks whether the block equals at least one of the given values.  |  if_variable  |  value: block<br/>compare: block  |    |    |    |
|  if_variable_block_is_minecraft_tagged  |  Block has Minecraft tag  |  Checks whether the block has the given Minecraft tag (e.g. "mineable/shovel").  |  if_variable  |  block: block<br/>namespace: text  |    |  The Minecraft tag must start with "#minecraft:"  |    |
|  if_variable_block_is_solid  |  Block is full  |  Checks whether the given block is full.  |  if_variable  |  block: block  |    |    |    |
|  if_variable_equals  |  Equals  |  Checks whether the variable equals at least one of the compared values.  |  if_variable  |  value: any<br/>compare: any<br/>compare_type: enum<br/>{ANY_ALL}  |    |    |    |
|  if_variable_exists  |  Variable exists  |  Checks whether the chosen variable exists.  |  if_variable  |  variable: variable<br/>compare_type: enum<br/>{ANY_ALL}  |    |    |    |
|  if_variable_greater  |  Greater  |  Checks whether the number variable is greater than the given value.  |  if_variable  |  value: number<br/>compare: number  |    |    |    |
|  if_variable_greater_or_equals  |  Greater or equal  |  Checks whether the number variable is greater than or equal to the given value.  |  if_variable  |  value: number<br/>compare: number  |    |    |    |
|  if_variable_in_range  |  In range  |  Checks whether the variable is in the given range.  |  if_variable  |  value: any<br/>min: any<br/>max: any  |    |    |  deprecated  |
|  if_variable_is_type  |  Variable type equals  |  Checks whether the variable value type equals the given one.  |  if_variable  |  value: any<br/>variable_type: enum<br/>&nbsp;&nbsp;- NUMBER<br/>&nbsp;&nbsp;- TEXT<br/>&nbsp;&nbsp;- LOCATION<br/>&nbsp;&nbsp;- ITEM<br/>&nbsp;&nbsp;- POTION<br/>&nbsp;&nbsp;- SOUND<br/>&nbsp;&nbsp;- PARTICLE<br/>&nbsp;&nbsp;- VECTOR<br/>&nbsp;&nbsp;- ARRAY<br/>&nbsp;&nbsp;- MAP<br/>compare_type: enum<br/>{ANY_ALL}  |    |    |    |
|  if_variable_item_equals  |  Item equals  |  Checks whether the item variable equals at least one of the given items.  |  if_variable  |  value: item<br/>compare: item<br/>comparison_mode: enum<br/>{CMP}  |    |    |    |
|  if_variable_item_has_enchantment  |  Item has enchantment  |  Checks whether the item variable has the given enchantment at the given level.  |  if_variable  |  item: item<br/>enchant: text<br/>level: number<br/>enchantment_type: enum<br/>&nbsp;&nbsp;- NORMAL<br/>&nbsp;&nbsp;- STORED<br/>&nbsp;&nbsp;- BOTH  |    |    |    |
|  if_variable_item_has_stored_enchantment  |  Item has stored enchantment  |  Checks whether the item has the given stored enchantment at the given level.  |  if_variable  |  item: item<br/>enchant: text<br/>level: number  |    |    |  deprecated  |
|  if_variable_item_has_tag  |  Item has tag  |  Checks whether the item variable has the given tag with the chosen value.  |  if_variable  |  item: item<br/>tag: text<br/>value: text<br/>compare_type: enum<br/>&nbsp;&nbsp;- EQUALS<br/>&nbsp;&nbsp;- CONTAINS<br/>&nbsp;&nbsp;- STARTS_WITH<br/>&nbsp;&nbsp;- ENDS_WITH  |    |    |    |
|  if_variable_item_is_block  |  Item is block  |  Checks whether the given item is a block.  |  if_variable  |  item: item  |    |    |    |
|  if_variable_item_is_minecraft_tagged  |  Item has Minecraft tag  |  Checks whether the item has the given Minecraft tag (e.g. "swords").  |  if_variable  |  item: item<br/>namespace: text  |    |  The Minecraft tag must start with "#minecraft:"  |    |
|  if_variable_less  |  Less  |  Checks whether the number variable is less than the given value.  |  if_variable  |  value: number<br/>compare: number  |    |    |    |
|  if_variable_less_or_equals  |  Less or equal  |  Checks whether the number variable is less than or equal to the given value.  |  if_variable  |  value: number<br/>compare: number  |    |    |    |
|  if_variable_list_contains_value  |  List contains value  |  Checks whether the list contains the given value.  |  if_variable  |  list: array<br/>values: any<br/>check_mode: enum<br/>{ANY_ALL}  |    |    |    |
|  if_variable_list_is_empty  |  Value is empty  |  Checks whether the value size is zero.  |  if_variable  |  list: any<br/>compare_type: enum<br/>{ANY_ALL}  |  Text values<br/>Lists<br/>Maps<br/>Items<br/>Nonexistent variables<br/>Empty values  |    |    |
|  if_variable_list_value_equals  |  List element equals  |  Checks whether the list element value equals at least one of the compared values.  |  if_variable  |  list: array<br/>index: number<br/>values: any  |    |    |    |
|  if_variable_location_in_range  |  Location in range  |  Checks whether the location is in the given range.  |  if_variable  |  value: location<br/>min: location<br/>max: location<br/>border_handling: enum<br/>&nbsp;&nbsp;- EXACT<br/>&nbsp;&nbsp;- BLOCK<br/>&nbsp;&nbsp;- FULL_BLOCK_RANGE  |    |    |    |
|  if_variable_location_is_near  |  Near location  |  Checks whether the location variable is near the given location.  |  if_variable  |  location: location<br/>radius: number<br/>check: location<br/>shape: enum<br/>&nbsp;&nbsp;- SPHERE<br/>&nbsp;&nbsp;- CIRCLE<br/>&nbsp;&nbsp;- CUBE<br/>&nbsp;&nbsp;- SQUARE  |    |    |    |
|  if_variable_map_has_key  |  Map has key  |  Checks whether the map has the given key.  |  if_variable  |  map: map<br/>key: any<br/>check_mode: enum<br/>{ANY_ALL}  |    |    |    |
|  if_variable_map_value_equals  |  Map value equals  |  Checks whether the map value by key equals at least one of the compared values.  |  if_variable  |  map: map<br/>key: any<br/>values: any  |    |    |    |
|  if_variable_multiple_equals  |  Equal  |  Checks whether the variables equal the compared values.   |  if_variable  |  values: any<br/>compares: any<br/>compare_type: enum<br/>{ANY_ALL}  |    |    |    |
|  if_variable_not_equals  |  Not equal  |  Checks whether the variable equals none of the compared values.  |  if_variable  |  value: any<br/>compare: any  |  Restored on the server (previously deprecated)  |    |
|  if_variable_number_in_range  |  In range  |  Checks whether the number variable is in the given range of the given value.   |  if_variable  |  value: number<br/>min: number<br/>max: number<br/>including: enum<br/>&nbsp;&nbsp;- NOT_INCLUDE<br/>&nbsp;&nbsp;- INCLUDE_FIRST<br/>&nbsp;&nbsp;- INCLUDE_LAST<br/>&nbsp;&nbsp;- INCLUDE_ALL  |    |    |    |
|  if_variable_range_intersects_range  |  Region intersects region  |  Checks whether one region intersects another.  |  if_variable  |  min1: location<br/>max1: location<br/>min2: location<br/>max2: location<br/>check_type: enum<br/>&nbsp;&nbsp;- OVERLAPS<br/>&nbsp;&nbsp;- CONTAINS  |    |    |    |
|  if_variable_text_contains  |  Text contains  |  Checks whether the text variable contains the given text.  |  if_variable  |  value: text<br/>compare: text<br/>ignore_case: enum<br/>{TF}  |    |    |    |
|  if_variable_text_ends_with  |  Text ends with  |  Checks whether the text variable ends with the given text.  |  if_variable  |  value: text<br/>compare: text<br/>ignore_case: enum<br/>{TF}  |    |    |    |
|  if_variable_text_matches  |  Text matches  |  Checks whether the text variable matches the given text or regular expression (RegEx).  |  if_variable  |  match: text<br/>values: text<br/>ignore_case: enum<br/>{TF}<br/>regular_expressions: enum<br/>{TF}  |    |    |    |
|  if_variable_text_starts_with  |  Text starts with  |  Checks whether the text variable starts with the given text.  |  if_variable  |  value: text<br/>compare: text<br/>ignore_case: enum<br/>{TF}  |    |    |    |
|  set_variable_absolute  |  Number absolute value  |  Assigns the absolute value of the chosen number to a variable.  |  set_variable/numerical  |  variable: variable<br/>number: number  |    |    |    |
|  set_variable_add  |  Add numbers (+)  |  Assigns the sum of numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>value: number  |    |    |    |
|  set_variable_add_item_enchantment  |  Add item enchantment  |  Adds an enchantment to an item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>enchantment: text<br/>level: number<br/>enchantment_type: enum<br/>&nbsp;&nbsp;- NORMAL<br/>&nbsp;&nbsp;- STORED<br/>&nbsp;&nbsp;- BOTH  |    |    |    |
|  set_variable_add_item_potion_effects  |  Set item potion effects  |  Sets item potion effects and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>potions: potion<br/>overwrite: enum<br/>{TF}<br/>show_icon: enum<br/>{TF}<br/>particle_mode: enum<br/>&nbsp;&nbsp;- REGULAR<br/>&nbsp;&nbsp;- AMBIENT<br/>&nbsp;&nbsp;- NONE  |    |    |    |
|  set_variable_add_item_stored_enchantment  |  Add stored item enchantment  |  Adds a stored enchantment to an item and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>item: item<br/>enchantment: text<br/>level: number  |    |    |  deprecated  |
|  set_variable_add_vectors  |  Vector sum  |  Assigns the vector sum to a variable.  |  set_variable/vector  |  variable: variable<br/>vectors: vector  |    |    |    |
|  set_variable_align_location  |  Round location  |  Rounds the location to the block center or corner and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location: location<br/>rotation_mode: enum<br/>&nbsp;&nbsp;- KEEP<br/>&nbsp;&nbsp;- REMOVE<br/>coordinates_mode: enum<br/>&nbsp;&nbsp;- ALL<br/>&nbsp;&nbsp;- X_Z<br/>&nbsp;&nbsp;- Y<br/>align_mode: enum<br/>&nbsp;&nbsp;- BLOCK_CENTER<br/>&nbsp;&nbsp;- CORNER  |    |    |    |
|  set_variable_align_to_axis_vector  |  Align vector  |  Aligns the vector to the nearest axis and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector<br/>normalize: enum<br/>{TF}  |    |    |    |
|  set_variable_append_component  |  Join stylable texts  |  Joins the given stylable texts into one stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>components: text<br/>merging: enum<br/>&nbsp;&nbsp;- SPACES<br/>&nbsp;&nbsp;- CONCATENATION<br/>&nbsp;&nbsp;- SEPARATE_LINES  |    |    |    |
|  set_variable_append_list  |  Join two lists  |  Joins the two given lists into one.  |  set_variable  |  variable: variable<br/>list_1: array<br/>list_2: array  |    |    |  deprecated  |
|  set_variable_append_lists  |  Join lists  |  Joins the given lists into one and assigns the result to a variable.  |  set_variable/list  |  variable: variable<br/>lists: array  |    |    |    |
|  set_variable_append_map  |  Join maps  |  Joins two maps and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>map: map<br/>other_map: map  |    |    |  deprecated  |
|  set_variable_append_maps  |  Join maps  |  Joins the given maps into one and assigns the result to a variable.  |  set_variable/map  |  variable: variable<br/>maps: map  |    |    |    |
|  set_variable_append_value  |  Add value  |  Appends the given values to the end of a list.  |  set_variable/list  |  variable: variable<br/>values: any  |    |    |    |
|  set_variable_atan2  |  Arctangent of values (atan2)  |  Returns the arctangent of the two given numbers.  |  set_variable/numerical  |  variable: variable<br/>y: number<br/>x: number  |    |    |    |
|  set_variable_average  |  Average value  |  Assigns the average of numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>value: number<br/>type: enum<br/>&nbsp;&nbsp;- ARITHMETIC<br/>&nbsp;&nbsp;- GEOMETRIC<br/>&nbsp;&nbsp;- HARMONIC<br/>&nbsp;&nbsp;- QUADRATIC  |    |    |    |
|  set_variable_bitwise_operation  |  Bitwise operation on numbers  |  Assigns the result of a bitwise operation on numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>operand1: number<br/>operand2: number<br/>operator: enum<br/>&nbsp;&nbsp;- OR<br/>&nbsp;&nbsp;- AND<br/>&nbsp;&nbsp;- NOT<br/>&nbsp;&nbsp;- XOR<br/>&nbsp;&nbsp;- LEFT_SHIFT<br/>&nbsp;&nbsp;- RIGHT_SHIFT<br/>&nbsp;&nbsp;- UNSIGNED_RIGHT_SHIFT<br/>&nbsp;&nbsp;- LEFT_ROTATE<br/>&nbsp;&nbsp;- RIGHT_ROTATE  |    |    |    |
|  set_variable_bytes_to_text  |  Convert bytes to text  |  Converts bytes to text and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>bytes: array<br/>charset: enum<br/>&nbsp;&nbsp;- UTF_16<br/>&nbsp;&nbsp;- UTF_8<br/>&nbsp;&nbsp;- ASCII  |    |    |    |
|  set_variable_center_location  |  Get center location  |  Finds the location at the center between several locations and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>locations: location  |    |    |    |
|  set_variable_change_component_parsing  |  Change stylable text type  |  Changes the stylable text type, converting its styles from one format to another, and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>parsing: enum<br/>&nbsp;&nbsp;- PLAIN<br/>&nbsp;&nbsp;- LEGACY<br/>&nbsp;&nbsp;- MINIMESSAGE<br/>&nbsp;&nbsp;- JSON  |    |    |    |
|  set_variable_char_to_number  |  Get number from character  |  Gets the given number from a character and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>char: text  |    |    |    |
|  set_variable_chunk_list  |  Split list  |  Splits a list into sublists by the given element count.  |  set_variable/list  |  variable: variable<br/>list: array<br/>size: number  |    |    |    |
|  set_variable_chunk_text  |  Split text  |  Splits text into a list of strings by the given character count and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>size: number  |    |    |    |
|  set_variable_clamp  |  Clamp number  |  Checks whether the number is between min and max, and if not, clamps it to the nearest.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>min: number<br/>max: number  |    |    |    |
|  set_variable_clamp_location  |  Clamp location  |  Checks whether the location is inside the region, and if not, sets the nearest location inside the region.  |  set_variable/location  |  variable: variable<br/>location: location<br/>corner_1: location<br/>corner_2: location<br/>coordinates_mode: enum<br/>&nbsp;&nbsp;- XYZ<br/>&nbsp;&nbsp;- XZ<br/>&nbsp;&nbsp;- Y  |    |    |    |
|  set_variable_clear_color_codes  |  Clear text colors  |  Strips color codes from text and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text  |    |    |    |
|  set_variable_clear_map  |  Clear map  |  Clears the map.  |  set_variable  |  map: variable  |    |    |  deprecated  |
|  set_variable_code_bytes  |  Encode bytes  |  Encodes/decodes the input bytes with the chosen method and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>input: array<br/>codec: enum<br/>&nbsp;&nbsp;- BASE64_ENCODE<br/>&nbsp;&nbsp;- BASE64_DECODE<br/>&nbsp;&nbsp;- ZLIB_COMPRESS<br/>&nbsp;&nbsp;- ZLIB_DECOMPRESS  |    |    |    |
|  set_variable_compact_component  |  Compress stylable text  |  Assigns the given stylable text without style elements and child parts to a variable.  |  set_variable/component  |  variable: variable<br/>component: text  |    |    |    |
|  set_variable_component_of_children  |  Create stylable text from child parts  |  Creates a stylable text from the given child stylable texts and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>components: text  |    |    |  unused  |
|  set_variable_convert_number_to_text  |  Convert number to text  |  Assigns the result of converting a number to text to a variable.  |  set_variable/text  |  variable: variable<br/>number: number<br/>radix: number  |    |  Works with integers only.<br/>The radix must be between 2 and 36 inclusive.  |    |
|  set_variable_convert_text_to_number  |  Convert text to number  |  Assigns the result of converting a number in another radix text form to a decimal number to a variable. Works with integers only.  |  set_variable/numerical  |  variable: variable<br/>text: text<br/>radix: number  |    |    |    |
|  set_variable_cosine  |  Cosine of number  |  Returns the cosine of a number.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>variant: enum<br/>&nbsp;&nbsp;- COSINE<br/>&nbsp;&nbsp;- ARCCOSINE<br/>&nbsp;&nbsp;- HYPERBOLIC_COSINE<br/>&nbsp;&nbsp;- HYPERBOLIC_ARCCOSINE<br/>input: enum<br/>{DEG_RAD}  |    |    |    |
|  set_variable_cotangent  |  Cotangent of number  |  Returns the cotangent of a number.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>variant: enum<br/>&nbsp;&nbsp;- COTANGENT<br/>&nbsp;&nbsp;- ARCCOTANGENT<br/>&nbsp;&nbsp;- HYPERBOLIC_COTANGENT<br/>&nbsp;&nbsp;- HYPERBOLIC_ARCCOTANGENT<br/>input: enum<br/>{DEG_RAD}  |    |    |    |
|  set_variable_create_head_object_component  |  Create stylable text with head  |  Assigns a stylable text containing the given head to a variable.  |  set_variable/component  |  variable: variable<br/>name_or_uuid: text<br/>hat: enum<br/>{TF}  |    |    |    |
|  set_variable_create_keybind_component  |  Create stylable text bound to key  |  Assigns a stylable text bound to a client key to a variable.  |  set_variable/component  |  variable: variable<br/>key: text  |    |    |    |
|  set_variable_create_list  |  Create list  |  Creates a list containing the given values.  |  set_variable/list  |  variable: variable<br/>values: any  |    |  Clears the list if it already exists.  |    |
|  set_variable_create_map  |  Create map  |  Creates a map from a list of keys and values and assigns the result to a variable.  |  set_variable/map  |  variable: variable<br/>keys: array<br/>values: array  |    |  Clears the map if it already exists.  |    |
|  set_variable_create_map_from_values  |  Create map from values  |  Creates a map from keys and values and assigns the result to a variable.  |  set_variable/map  |  variable: variable<br/>keys: any<br/>values: any  |    |  Clears the map if it already exists.  |    |
|  set_variable_create_sprite_object_component  |  Create stylable text with sprite  |  Assigns a stylable text containing the given sprite to a variable.  |  set_variable/component  |  variable: variable<br/>sprite: text<br/>atlas: text  |    |  If the "Sprite atlas" argument is omitted, the "block" atlas is used for the sprite.  |    |
|  set_variable_create_translatable_component  |  Create translatable stylable text  |  Assigns a translatable stylable text with the given arguments to a variable.  |  set_variable/component  |  variable: variable<br/>key: text<br/>fallback: text<br/>args: text  |    |  If no fallback message is set and the given key has no translation, the final message equals the given key.  |    |
|  set_variable_decrement  |  Subtraction (-=)  |  Subtracts the chosen number from a variable.  |  set_variable/numerical  |  variable: variable<br/>number: number  |    |    |    |
|  set_variable_destructure_list  |  Explode list  |  Spreads list values into separate variables.  |  set_variable/list  |  variables: variable<br/>list: array  |    |    |    |
|  set_variable_divide  |  Divide numbers (÷)  |  Assigns the quotient of numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>value: number<br/>division_mode: enum<br/>&nbsp;&nbsp;- DEFAULT<br/>&nbsp;&nbsp;- ROUND_TO_INT<br/>&nbsp;&nbsp;- FLOOR<br/>&nbsp;&nbsp;- CEIL  |    |    |    |
|  set_variable_divide_vector  |  Vector division  |  Assigns the result of dividing two vectors to a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector<br/>divider: vector  |    |    |    |
|  set_variable_edit_item_custom_model_data  |  Change item model data  |  Changes item model data (CustomModelData) and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>data: any<br/>value_type: enum<br/>&nbsp;&nbsp;- FLOATS<br/>&nbsp;&nbsp;- BOOLEANS<br/>&nbsp;&nbsp;- STRINGS<br/>&nbsp;&nbsp;- COLORS<br/>setup_mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- REMOVE_ALL<br/>&nbsp;&nbsp;- REMOVE_FIRST<br/>&nbsp;&nbsp;- REMOVE_LAST  |    |    |    |
|  set_variable_face_location  |  Direct location  |  Rotates a location towards another location and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location: location<br/>target: location  |    |    |    |
|  set_variable_find_nearest_location  |  Get nearest location  |  Finds the location closest to the given one among the listed locations and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location: location<br/>locations: location<br/>distance_type: enum<br/>&nbsp;&nbsp;- XYZ<br/>&nbsp;&nbsp;- XZ<br/>&nbsp;&nbsp;- Y<br/>compare_mode: enum<br/>&nbsp;&nbsp;- NEAREST<br/>&nbsp;&nbsp;- FARTHEST  |    |    |    |
|  set_variable_find_nearest_number  |  Nearest number  |  Finds the number closest to the given one among the listed numbers and assigns the result to a variable.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>numbers: number  |    |    |    |
|  set_variable_flatten_list  |  Flatten list  |  Splits the sublists of the given list into separate elements.  |  set_variable/list  |  variable: variable<br/>list: array<br/>deep: enum<br/>{TF}  |    |    |    |
|  set_variable_format_timestamp  |  Create time format  |  Converts a number (milliseconds) to the given time format and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>time: number<br/>pattern: text<br/>zone_id: text<br/>locale: text<br/>format: enum<br/>&nbsp;&nbsp;- CUSTOM<br/>&nbsp;&nbsp;- DD_MM_YYYY_HH_MM_S<br/>&nbsp;&nbsp;- DD_MM_YYYY<br/>&nbsp;&nbsp;- YYYY_MM_DD_HH_MM_S<br/>&nbsp;&nbsp;- YYYY_MM_DD<br/>&nbsp;&nbsp;- EEE_D_MMMM<br/>&nbsp;&nbsp;- EEE_MMMM_D<br/>&nbsp;&nbsp;- EEEE<br/>&nbsp;&nbsp;- HH_MM_SS<br/>&nbsp;&nbsp;- H_MM_A<br/>&nbsp;&nbsp;- H_H_M_M_S_S<br/>&nbsp;&nbsp;- S_S  |    |    |    |
|  set_variable_gamma_function  |  Gamma function  |  Returns the gamma function of a number and assigns it to a variable.  |  set_variable/numerical  |  variable: variable<br/>number: number  |    |  A generalization of the factorial. <br/>The gamma function can be represented as (n-1)!, where n is the given number.  |    |
|  set_variable_gaussian_distribution  |  Normally distributed random number  |  Yields a random number near the mean μ with standard deviation σ with a chance given by the normal distribution curve.  |  set_variable/numerical  |  variable: variable<br/>deviant: number<br/>mean: number<br/>distribution: enum<br/>&nbsp;&nbsp;- NORMAL<br/>&nbsp;&nbsp;- FOLDER_NORMAL  |    |    |    |
|  set_variable_get_all_block_data  |  Get all block data  |  Assigns all block data at the chosen location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>hide_unspecified: enum<br/>{TF}  |    |    |    |
|  set_variable_get_all_coordinates  |  Get all location coordinates  |  Gets all coordinate values from the location and assigns them to variables.  |  set_variable/location  |  location: location<br/>x: variable<br/>y: variable<br/>z: variable<br/>yaw: variable<br/>pitch: variable  |    |    |    |
|  set_variable_get_angle_between_vectors  |  Get angle between two vectors  |  Assigns the angle between two vectors to a variable.  |  set_variable/vector  |  variable: variable<br/>vector_1: vector<br/>vector_2: vector<br/>angle_units: enum<br/>{DEG_RAD}  |    |    |    |
|  set_variable_get_block_data  |  Get block data  |  Gets the block data and assigns it to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>tag_name: text  |  Block entities (chests, signs, barrels, etc.)  |    |    |
|  set_variable_get_block_growth  |  Get block growth level  |  Assigns the block growth level at the given location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>growth_unit: enum<br/>&nbsp;&nbsp;- GROWTH_STAGE<br/>&nbsp;&nbsp;- GROWTH_PERCENTAGE  |    |    |    |
|  set_variable_get_block_material  |  Get block type  |  Assigns the block type at the chosen location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>value_type: enum<br/>&nbsp;&nbsp;- ID<br/>&nbsp;&nbsp;- ID_WITH_DATA<br/>&nbsp;&nbsp;- NAME<br/>&nbsp;&nbsp;- ITEM  |    |    |    |
|  set_variable_get_block_material_property  |  Get block property  |  Gets the given block property and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>block: block<br/>property: enum<br/>&nbsp;&nbsp;- HARDNESS<br/>&nbsp;&nbsp;- BLAST_RESISTANCE<br/>&nbsp;&nbsp;- SLIPPERINESS  |    |    |    |
|  set_variable_get_block_power  |  Get redstone power  |  Assigns the redstone signal strength at the given location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |    |    |    |
|  set_variable_get_block_sound  |  Get block sound  |  Gets the sound of the given block and assigns it to a variable.  |  set_variable/misc  |  variable: variable<br/>block: block<br/>source: enum<br/>&nbsp;&nbsp;- BREAK<br/>&nbsp;&nbsp;- PLACE<br/>&nbsp;&nbsp;- HIT<br/>&nbsp;&nbsp;- FALL<br/>&nbsp;&nbsp;- STEP  |    |    |    |
|  set_variable_get_blocks_by_tag  |  Get blocks by Minecraft tag  |  Gets blocks by Minecraft tag (e.g. "mineable/shovel") and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>namespace: text<br/>result_type: enum<br/>&nbsp;&nbsp;- ID<br/>&nbsp;&nbsp;- TRANSLATION_KEY<br/>&nbsp;&nbsp;- ITEM  |    |    |    |
|  set_variable_get_book_text  |  Get book text  |  Assigns the book text on the given page to a variable.  |  set_variable/item  |  variable: variable<br/>book: item<br/>page: number  |    |    |    |
|  set_variable_get_brushable_block_item  |  Get item from suspicious block  |  Gets the item from a suspicious block (sand, gravel) and assigns the result to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |    |    |    |
|  set_variable_get_bundle_items  |  Get bundle contents  |  Gets the bundle contents and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>bundle: item  |    |    |    |
|  set_variable_get_char_at  |  Get character by index  |  Gets a character from the text at the given index and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>index: number  |    |    |    |
|  set_variable_get_color_channels  |  Get color channels  |  Gets the RGB/HSB/HSL color numeric values as a list.  |  set_variable/misc  |  variable: variable<br/>color: text<br/>color_channels: enum<br/>&nbsp;&nbsp;- RGB<br/>&nbsp;&nbsp;- HSB<br/>&nbsp;&nbsp;- HSL  |    |    |    |
|  set_variable_get_compass_lodestone  |  Get magnetite location  |  Gets the lodestone location from a magnetized compass and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_component_children  |  Get stylable text child parts  |  Assigns the child parts of the given stylable text to a variable.  |  set_variable/component  |  variable: variable<br/>component: text  |    |    |    |
|  set_variable_get_component_decorations  |  Get stylable text decorations  |  Assigns all decorations (styling) of the stylable text to a variable.  |  set_variable/component  |  variable: variable<br/>component: text  |    |    |    |
|  set_variable_get_component_hex_color  |  Get stylable text HEX color  |  Assigns the HEX color of the given stylable text to a variable.  |  set_variable/component  |  variable: variable<br/>component: text  |    |    |    |
|  set_variable_get_component_parsing  |  Get stylable text transformation type  |  Assigns the conversion type value of the given stylable text to a variable.  |  set_variable/component  |  variable: variable<br/>component: text  |    |    |    |
|  set_variable_get_container_contents  |  Get container contents  |  Assigns the container contents list at the chosen location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>ignore_empty_slots: enum<br/>{TF}  |    |    |    |
|  set_variable_get_container_lock  |  Get container key  |  Assigns the container key item at the given location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |    |    |    |
|  set_variable_get_container_name  |  Get container name  |  Assigns the container name at the chosen location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |    |    |    |
|  set_variable_get_coordinate  |  Get location coordinate  |  Gets the chosen coordinate value from the location and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location: location<br/>type: enum<br/>&nbsp;&nbsp;- X<br/>&nbsp;&nbsp;- Y<br/>&nbsp;&nbsp;- Z<br/>&nbsp;&nbsp;- YAW<br/>&nbsp;&nbsp;- PITCH  |    |    |    |
|  set_variable_get_custom_recipes  |  Get world custom recipes  |  Gets custom or vanilla world recipes and assigns the result to a variable.  |  set_variable/world  |  variable: variable<br/>is_vanilla_recipes: enum<br/>{TF}  |    |    |    |
|  set_variable_get_decorate_pot_sherd  |  Get vase decoration  |  Assigns the sherd material of the chosen pot face at the given location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>side: enum<br/>&nbsp;&nbsp;- BACK<br/>&nbsp;&nbsp;- FRONT<br/>&nbsp;&nbsp;- LEFT<br/>&nbsp;&nbsp;- RIGHT  |    |    |    |
|  set_variable_get_entity_types_by_tag  |  Get entities by Minecraft tag  |  Gets entities by Minecraft tag (e.g. "aquatic") and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>namespace: text<br/>result_type: enum<br/>&nbsp;&nbsp;- ID<br/>&nbsp;&nbsp;- TRANSLATION_KEY  |    |    |    |
|  set_variable_get_index_of_subtext  |  Get substring index  |  Gets the substring index from the text and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>subtext: text<br/>start_index: number<br/>search_mode: enum<br/>&nbsp;&nbsp;- FIRST<br/>&nbsp;&nbsp;- LAST  |    |    |    |
|  set_variable_get_item_amount  |  Get item amount  |  Assigns the item count in the stack to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_attack_range  |  Get attack radius  |  Gets the attack radius of the given item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>property: enum<br/>&nbsp;&nbsp;- MIN_RANGE<br/>&nbsp;&nbsp;- MAX_RANGE<br/>&nbsp;&nbsp;- MIN_CREATIVE_RANGE<br/>&nbsp;&nbsp;- MAX_CREATIVE_RANGE<br/>&nbsp;&nbsp;- HITBOX_MARGIN<br/>&nbsp;&nbsp;- MOB_FACTORY  |    |    |    |
|  set_variable_get_item_attribute  |  Get item attribute  |  Gets the given attribute from the item as a "UUID - Value" map and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>name: text<br/>attribute: enum<br/>&nbsp;&nbsp;- GENERIC_MAX_HEALTH<br/>&nbsp;&nbsp;- GENERIC_MAX_ABSORPTION<br/>&nbsp;&nbsp;- GENERIC_FOLLOW_RANGE<br/>&nbsp;&nbsp;- GENERIC_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_SPEED<br/>&nbsp;&nbsp;- GENERIC_FLYING_SPEED<br/>&nbsp;&nbsp;- GENERIC_ATTACK_DAMAGE<br/>&nbsp;&nbsp;- GENERIC_ATTACK_KNOCKBACK<br/>&nbsp;&nbsp;- GENERIC_ATTACK_SPEED<br/>&nbsp;&nbsp;- GENERIC_ARMOR<br/>&nbsp;&nbsp;- GENERIC_ARMOR_TOUGHNESS<br/>&nbsp;&nbsp;- GENERIC_LUCK<br/>&nbsp;&nbsp;- GENERIC_JUMP_STRENGTH<br/>&nbsp;&nbsp;- ZOMBIE_SPAWN_REINFORCEMENTS<br/>&nbsp;&nbsp;- GENERIC_FALL_DAMAGE_MULTIPLIER<br/>&nbsp;&nbsp;- GENERIC_SAFE_FALL_DISTANCE<br/>&nbsp;&nbsp;- GENERIC_SCALE<br/>&nbsp;&nbsp;- GENERIC_STEP_HEIGHT<br/>&nbsp;&nbsp;- GENERIC_GRAVITY<br/>&nbsp;&nbsp;- PLAYER_BLOCK_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_ENTITY_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_BLOCK_BREAK_SPEED<br/>&nbsp;&nbsp;- GENERIC_BURNING_TIME<br/>&nbsp;&nbsp;- GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- GENERIC_OXYGEN_BONUS<br/>&nbsp;&nbsp;- GENERIC_WATER_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_MINING_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_SNEAKING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SUBMERGED_MINING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SWEEPING_DAMAGE_RATIO<br/>&nbsp;&nbsp;- TEMP_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_TRANSMIT_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_RECEIVE_RANGE<br/>&nbsp;&nbsp;- CAMERA_DISTANCE<br/>&nbsp;&nbsp;- BOUNCINESS<br/>&nbsp;&nbsp;- FRICTION_MODIFIER<br/>&nbsp;&nbsp;- AIR_DRAG_MODIFIER<br/>&nbsp;&nbsp;- NAME_TAG_DISTANCE<br/>&nbsp;&nbsp;- BELOW_NAME_DISTANCE<br/>slot: enum<br/>&nbsp;&nbsp;- ALL<br/>&nbsp;&nbsp;- MAIN_HAND<br/>&nbsp;&nbsp;- OFF_HAND<br/>&nbsp;&nbsp;- HAND<br/>&nbsp;&nbsp;- BOOTS<br/>&nbsp;&nbsp;- LEGGINGS<br/>&nbsp;&nbsp;- CHEST<br/>&nbsp;&nbsp;- HEAD<br/>&nbsp;&nbsp;- ARMOR<br/>&nbsp;&nbsp;- BODY  |    |    |    |
|  set_variable_get_item_break_sound  |  Get item breaking sound  |  Gets the sound played when the given item breaks and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_color  |  Get item color  |  Assigns the item color value to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |  Leather armor<br/>Potions<br/>Tipped arrows<br/>Filled maps  |    |    |
|  set_variable_get_item_component  |  Get item component  |  Gets the item component value and assigns it to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>component: text  |    |    |    |
|  set_variable_get_item_contents  |  Get item contents  |  Gets the contents of the given item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_custom_model_data  |  Get item model data  |  Gets the item model data (CustomModelData) and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>item: item  |    |    |  deprecated  |
|  set_variable_get_item_custom_tag  |  Get item custom tag  |  Assigns the item custom tag value to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>tag_name: text<br/>default_value: any  |    |    |    |
|  set_variable_get_item_custom_tags  |  Get item custom tags  |  Assigns the item custom tags map to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_destroyable_blocks  |  Get blocks breakable by item  |  Gets the blocks the item can break and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_durability  |  Get item durability  |  Assigns the durability of the given item to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>durability_type: enum<br/>&nbsp;&nbsp;- DAMAGE<br/>&nbsp;&nbsp;- DAMAGE_PERCENTAGE<br/>&nbsp;&nbsp;- REMAINING<br/>&nbsp;&nbsp;- REMAINING_PERCENTAGE<br/>&nbsp;&nbsp;- MAXIMUM  |    |    |    |
|  set_variable_get_item_effective_name  |  Get item inventory display name  |  Gets the item name as shown in the inventory and assigns it to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |  The returned text is built from several parts that affect the display name, including rarity and the translatable item name.  |    |
|  set_variable_get_item_enchantment  |  Get item enchantment  |  Gets the given item enchantment level and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>enchantment: text<br/>enchantment_type: enum<br/>&nbsp;&nbsp;- NORMAL<br/>&nbsp;&nbsp;- STORED<br/>&nbsp;&nbsp;- BOTH  |    |    |    |
|  set_variable_get_item_enchantments  |  Get item enchantments  |  Assigns the map of the item enchantments and their levels to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>enchantment_type: enum<br/>&nbsp;&nbsp;- NORMAL<br/>&nbsp;&nbsp;- STORED<br/>&nbsp;&nbsp;- BOTH  |    |    |    |
|  set_variable_get_item_food_properties  |  Get item food component value  |  Gets the item food component value and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>property: enum<br/>&nbsp;&nbsp;- NUTRITION<br/>&nbsp;&nbsp;- SATURATION  |    |    |    |
|  set_variable_get_item_lore  |  Get item lore  |  Assigns the item lore text to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_lore_line  |  Get item lore line  |  Assigns the item lore line to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>line: number  |    |    |    |
|  set_variable_get_item_max_stack_size  |  Get item max stack size  |  Assigns the maximum stack size of the item to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_minimum_attack_charge  |  Get minimum attack charge  |  Gets the minimum item charge needed for an attack and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_model_data  |  Get item model  |  Gets the model of the given item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_name  |  Get item name  |  Assigns the item display name to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_nbt_tags  |  Get item data  |  Assigns the data about the given item to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>fetch_mode: enum<br/>&nbsp;&nbsp;- ALL<br/>&nbsp;&nbsp;- CUSTOM_DATA  |    |    |    |
|  set_variable_get_item_placeable_blocks  |  Get blocks for item placement  |  Gets the blocks the item can be placed on and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_potion_effects  |  Get potion effects from item  |  Gets the potion effects from the item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_rarity  |  Get item rarity  |  Gets the item rarity and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_sprite  |  Get item sprite  |  Gets the sprite of the given item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_stored_enchantments  |  Get item stored enchantments  |  Gets the item stored enchantments and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>item: item  |    |    |  deprecated  |
|  set_variable_get_item_swing_animation  |  Get swing animation data  |  Gets the given item swing animation data and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>property: enum<br/>&nbsp;&nbsp;- DURATION<br/>&nbsp;&nbsp;- ANIMATION  |    |    |    |
|  set_variable_get_item_tooltip_style  |  Get item tooltip style  |  Gets the item tooltip style and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_type  |  Get item type  |  Assigns the item type represented as text to a variable.  |  set_variable/item  |  variable: variable<br/>type: item<br/>value: enum<br/>&nbsp;&nbsp;- ID<br/>&nbsp;&nbsp;- NAME<br/>&nbsp;&nbsp;- ITEM  |    |    |    |
|  set_variable_get_item_use_remainder  |  Get item transformation  |  Gets the item the given item turns into after use and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_get_item_weapon  |  Get item weapon component value  |  Gets the item weapon component value and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>property: enum<br/>&nbsp;&nbsp;- ITEM_DAMAGE_PER_ATTACK<br/>&nbsp;&nbsp;- DISABLE_BLOCKING  |    |    |    |
|  set_variable_get_items_by_tag  |  Get items by Minecraft tag  |  Gets items by Minecraft tag (e.g. "swords") and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>namespace: text<br/>result_type: enum<br/>&nbsp;&nbsp;- ID<br/>&nbsp;&nbsp;- TRANSLATION_KEY<br/>&nbsp;&nbsp;- ITEM  |    |    |    |
|  set_variable_get_lectern_book  |  Get book from lectern  |  Assigns the book from the lectern at the given location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |    |    |    |
|  set_variable_get_lectern_page  |  Get book page from lectern  |  Assigns the current page number of the book on the lectern at the given location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |    |    |    |
|  set_variable_get_light_level  |  Get light level  |  Assigns the light level value at the given location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>value_type: enum<br/>&nbsp;&nbsp;- TOTAL<br/>&nbsp;&nbsp;- SKY<br/>&nbsp;&nbsp;- BLOCKS  |    |    |    |
|  set_variable_get_list_index_of_value  |  Get list value index  |  Searches for a value in the list and gets its index if found. Returns -1 on failure.  |  set_variable/list  |  variable: variable<br/>list: array<br/>value: any<br/>search_mode: enum<br/>&nbsp;&nbsp;- FIRST<br/>&nbsp;&nbsp;- LAST  |    |    |    |
|  set_variable_get_list_length  |  Get list size  |  Gets the number of elements in the given list.  |  set_variable/list  |  variable: variable<br/>list: array  |    |    |    |
|  set_variable_get_list_random_value  |  Get random list value  |  Gets a random value from the list.  |  set_variable/list  |  variable: variable<br/>list: array  |    |    |    |
|  set_variable_get_list_value  |  Get value from list  |  Gets a value from the list at the given index.  |  set_variable/list  |  variable: variable<br/>list: array<br/>number: number<br/>default_value: any  |    |    |    |
|  set_variable_get_list_variables  |  Get variable names  |  Gets the list of names of all variables and assigns the result to a variable.  |  set_variable/setting  |  variable: variable<br/>names: text<br/>scope: enum<br/>&nbsp;&nbsp;- GAME<br/>&nbsp;&nbsp;- SAVE<br/>&nbsp;&nbsp;- LOCAL<br/>&nbsp;&nbsp;- LINE<br/>match: enum<br/>&nbsp;&nbsp;- EQUALS<br/>&nbsp;&nbsp;- NAME_CONTAINS<br/>&nbsp;&nbsp;- PART_CONTAINS<br/>&nbsp;&nbsp;- STARTS_WITH<br/>&nbsp;&nbsp;- ENDS_WITH<br/>ignore_case: enum<br/>{TF}  |    |    |    |
|  set_variable_get_location_direction  |  Get location direction  |  Assigns the location direction to a variable.  |  set_variable/location  |  variable: variable<br/>location: location  |    |    |    |
|  set_variable_get_map_entry_by_index  |  Get map entry by index  |  Gets the given map key and value by index and assigns the results to variables.  |  set_variable/map  |  variable_key: variable<br/>variable_value: variable<br/>map: map<br/>index: number<br/>default_key: any<br/>default_value: any  |    |    |    |
|  set_variable_get_map_key_by_index  |  Get map key by index  |  Gets a key by index and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>map: map<br/>index: number<br/>default_value: any  |    |    |  deprecated  |
|  set_variable_get_map_keys  |  Get map keys list  |  Assigns the map keys list to a variable.  |  set_variable/map  |  variable: variable<br/>map: map  |    |    |    |
|  set_variable_get_map_keys_by_value  |  Get map keys by value  |  Gets the map key or list of keys by value and assigns the result to a variable.  |  set_variable/map  |  variable: variable<br/>map: map<br/>value: any<br/>default_value: any<br/>find_mode: enum<br/>&nbsp;&nbsp;- FIRST<br/>&nbsp;&nbsp;- LAST<br/>&nbsp;&nbsp;- ALL  |    |    |    |
|  set_variable_get_map_random_entry  |  Get random map entry  |  Gets a random map key and value and assigns the results to variables.  |  set_variable/map  |  variable_key: variable<br/>variable_value: variable<br/>map: map  |    |    |    |
|  set_variable_get_map_size  |  Get map size  |  Assigns the map size value to a variable.  |  set_variable/map  |  variable: variable<br/>map: map  |    |    |    |
|  set_variable_get_map_value  |  creative_plus.action.set_variable_get_map_value.name  |  creative_plus.action.set_variable_get_map_value.description  |  set_variable  |  variable: variable<br/>map: map<br/>key: any<br/>default_value: any  |    |    |  deprecated  |
|  set_variable_get_map_value_by_index  |  Get map value by index  |  Gets a value by index and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>map: map<br/>index: number<br/>default_value: any  |    |    |  deprecated  |
|  set_variable_get_map_value_single  |  Get map value  |  Gets the given map value by key and assigns the result to a variable.  |  set_variable/map  |  variable: variable<br/>map: map<br/>key: any<br/>default_value: any  |    |    |    |
|  set_variable_get_map_values  |  Get map values list  |  Assigns the map values list to a variable.  |  set_variable/map  |  variable: variable<br/>map: map  |    |    |    |
|  set_variable_get_midpoint_between_vectors  |  Get central value between vectors  |  Assigns the central value between two vectors to a variable.  |  set_variable/vector  |  variable: variable<br/>vector_1: vector<br/>vector_2: vector  |    |    |    |
|  set_variable_get_particle_amount  |  Get particle count  |  Assigns the particle count value to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle  |    |    |    |
|  set_variable_get_particle_color  |  Get particle color  |  Assigns the particle color value to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>color_type: enum<br/>&nbsp;&nbsp;- COLOR<br/>&nbsp;&nbsp;- TO_COLOR  |    |    |    |
|  set_variable_get_particle_material  |  Get particle material  |  Assigns the particle material value to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle  |    |    |    |
|  set_variable_get_particle_offset  |  Get particle motion  |  Assigns the particle motion value to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle  |    |    |    |
|  set_variable_get_particle_size  |  Get particle size  |  Assigns the particle size value to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle  |    |    |    |
|  set_variable_get_particle_spread  |  Get particle spread  |  Assigns the particle spread value to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>type: enum<br/>&nbsp;&nbsp;- VERTICAL<br/>&nbsp;&nbsp;- HORIZONTAL  |    |    |    |
|  set_variable_get_particle_type  |  Get particle type  |  Assigns the particle type value to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle  |    |    |    |
|  set_variable_get_player_head  |  Get player head  |  Gets the player head as an item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>name_or_uuid: text<br/>receive_type: enum<br/>&nbsp;&nbsp;- NAME_OR_UUID<br/>&nbsp;&nbsp;- VALUE  |    |    |    |
|  set_variable_get_player_head_owner  |  Get head owner  |  Gets the head owner name or UUID and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>head: item<br/>return_value: enum<br/>&nbsp;&nbsp;- NAME<br/>&nbsp;&nbsp;- UUID<br/>&nbsp;&nbsp;- VALUE  |    |    |    |
|  set_variable_get_player_head_value  |  Get head owner at location  |  Gets the name or UUID of the head owner at the location and assigns the result to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>return_value: enum<br/>&nbsp;&nbsp;- NAME<br/>&nbsp;&nbsp;- UUID<br/>&nbsp;&nbsp;- VALUE  |    |    |    |
|  set_variable_get_potion_effect_amplifier  |  Get potion strength  |  Assigns the potion strength value to a variable.  |  set_variable/misc  |  variable: variable<br/>potion: potion  |    |    |    |
|  set_variable_get_potion_effect_duration  |  Get potion duration  |  Assigns the potion duration value to a variable.  |  set_variable/misc  |  variable: variable<br/>potion: potion  |    |    |    |
|  set_variable_get_potion_effect_type  |  Get potion type  |  Assigns the potion type value to a variable.  |  set_variable/misc  |  variable: variable<br/>potion: potion  |    |    |    |
|  set_variable_get_sculk_shrieker_warning_level  |  Get sculk shrieker warning level  |  Assigns the sculk shrieker warning level at the given location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |    |    |    |
|  set_variable_get_sign_text  |  Get sign line text  |  Assigns the sign line text at the chosen location to a variable.  |  set_variable/world  |  variable: variable<br/>location: location<br/>check_side: enum<br/>&nbsp;&nbsp;- FRONT<br/>&nbsp;&nbsp;- BACK<br/>&nbsp;&nbsp;- ALL<br/>sign_line: enum<br/>&nbsp;&nbsp;- FIRST<br/>&nbsp;&nbsp;- SECOND<br/>&nbsp;&nbsp;- THIRD<br/>&nbsp;&nbsp;- FOURTH<br/>&nbsp;&nbsp;- ALL  |    |    |    |
|  set_variable_get_sound_pitch  |  Get sound pitch  |  Assigns the sound pitch value to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound  |    |    |    |
|  set_variable_get_sound_source  |  Get sound source  |  Gets the sound source and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound  |    |    |    |
|  set_variable_get_sound_type  |  Get sound type  |  Assigns the sound type value to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound  |    |    |    |
|  set_variable_get_sound_variation  |  Get sound variation  |  Gets the sound variation and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound  |    |  Returns empty text if a random seed is used.  |    |
|  set_variable_get_sound_volume_action  |  Get sound volume  |  Assigns the sound volume value to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound  |    |    |    |
|  set_variable_get_template_code  |  Get code from template  |  Assigns the code from a template to a variable.  |  set_variable/misc  |  variable: variable<br/>template: item<br/>return_type: enum<br/>&nbsp;&nbsp;- TEXT<br/>&nbsp;&nbsp;- MAP  |    |    |    |
|  set_variable_get_text_regex_groups  |  Parse with regular expression  |  Parses the text with a regular expression and assigns the matches with the contents of all capture groups, or the contents of certain groups, to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>regex: text<br/>group: text<br/>match_mode: enum<br/>&nbsp;&nbsp;- ALL<br/>&nbsp;&nbsp;- FIRST<br/>get_group_by: enum<br/>&nbsp;&nbsp;- INDEX<br/>&nbsp;&nbsp;- NAME<br/>ignore_case: enum<br/>{TF}<br/>multiline: enum<br/>{TF}<br/>literal: enum<br/>{TF}<br/>unix_lines: enum<br/>{TF}<br/>comments: enum<br/>{TF}<br/>dot_matches_all: enum<br/>{TF}<br/>cannon_eq: enum<br/>{TF}  |    |    |    |
|  set_variable_get_text_similarity  |  Get text similarity  |  Gets the text similarity coefficient and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text_1: text<br/>text_2: text<br/>value_type: enum<br/>&nbsp;&nbsp;- SIMILARITY<br/>&nbsp;&nbsp;- LEVENSHTEIN_DISTANCE  |    |    |    |
|  set_variable_get_text_width  |  Get text width in pixels  |  Gets the size of each character in the text, sums them and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text  |    |  Values may be outdated if a resource pack with its own symbols is used.  |    |
|  set_variable_get_tile_block_custom_tag  |  Get block entity custom tag  |  Gets the block entity custom tag data and assigns the result to a variable.  |  set_variable/block  |  variable: variable<br/>location: location<br/>tag_name: text<br/>default_value: any  |  Block entities (chests, signs, barrels, etc.)  |    |    |
|  set_variable_get_tile_block_nbt  |  Get block entity NBT tags  |  Gets the block entity NBT tags data and assigns the result to a variable.  |  set_variable/block  |  variable: variable<br/>location: location<br/>path: text<br/>value_type: enum<br/>&nbsp;&nbsp;- ANY_VALUE<br/>&nbsp;&nbsp;- NBT_STRING  |  Block entities (chests, signs, barrels, etc.)  |    |    |
|  set_variable_get_vault_displayed_item  |  Get vault displayed item  |  Gets the vault displayed item and assigns it to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |  Vaults  |    |    |
|  set_variable_get_vault_next_state_update_time  |  Get vault next state update time  |  Gets the vault next state update time and assigns it to a variable.  |  set_variable/world  |  variable: variable<br/>location: location  |  Vaults  |    |    |
|  set_variable_get_vector_all_components  |  Get all vector coordinates  |  Gets all vector coordinates and assigns the results to variables.  |  set_variable/vector  |  vector: vector<br/>x: variable<br/>y: variable<br/>z: variable  |    |    |    |
|  set_variable_get_vector_between_locations  |  Create vector between locations  |  Creates a vector between the start and end locations and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>start_location: location<br/>end_location: location  |    |    |    |
|  set_variable_get_vector_component  |  Get vector coordinate  |  Gets the given vector coordinate and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector<br/>vector_component: enum<br/>&nbsp;&nbsp;- X<br/>&nbsp;&nbsp;- Y<br/>&nbsp;&nbsp;- Z  |    |    |    |
|  set_variable_get_vector_from_block_face  |  Create vector from cardinal direction  |  Creates a normalized vector from the given cardinal direction ("south", "north", "east", "west", "up", "down").  |  set_variable/vector  |  variable: variable<br/>block_face: text  |    |    |    |
|  set_variable_get_vector_length  |  Get vector length  |  Assigns the vector length value to a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector<br/>length_type: enum<br/>&nbsp;&nbsp;- LENGTH<br/>&nbsp;&nbsp;- LENGTH_SQUARED  |    |    |    |
|  set_variable_hadamard_vector_product  |  Hadamard product of vectors  |  Assigns the Hadamard product of two vectors to a variable.  |  set_variable/vector  |  variable: variable<br/>vector_1: vector<br/>vector_2: vector  |    |    |    |
|  set_variable_hash  |  Get text hash  |  Assigns the text hash value to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>algorithm: enum<br/>&nbsp;&nbsp;- MD5<br/>&nbsp;&nbsp;- SHA1<br/>&nbsp;&nbsp;- SHA256  |    |    |    |
|  set_variable_hide_item_components  |  Hide item components  |  Hides the given item components and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>components: text<br/>mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- REMOVE  |    |    |    |
|  set_variable_increment  |  Addition (+=)  |  Adds the chosen number to a variable.  |  set_variable/numerical  |  variable: variable<br/>number: number  |    |    |    |
|  set_variable_insert_list_value  |  Insert value into list  |  Inserts a value into the list at the given index, shifting all values after it to the right.  |  set_variable/list  |  variable: variable<br/>list: array<br/>number: number<br/>value: any  |    |    |    |
|  set_variable_join_text  |  Join list into text  |  Joins the list elements into a single text and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>list: array<br/>separator: text<br/>prefix: text<br/>postfix: text<br/>limit: number<br/>truncated: text  |    |    |    |
|  set_variable_join_to_component  |  Join list into stylable text  |  Assigns the stylable text joined from list elements to a variable.  |  set_variable/component  |  variable: variable<br/>list: array<br/>separator: text<br/>prefix: text<br/>suffix: text  |    |    |    |
|  set_variable_lerp_number  |  Interpolate number  |  Computes a number between two numbers with a given coefficient and assigns the result to a variable. At coefficient 0 the first number is returned, at 1 the second, at 0.5 the average.  |  set_variable/numerical  |  variable: variable<br/>start: number<br/>stop: number<br/>amount: number  |    |    |    |
|  set_variable_location_relative  |  Set relative location  |  Sets the location relative to a block face at a given distance and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location: location<br/>distance: number<br/>block_face: enum<br/>&nbsp;&nbsp;- NORTH<br/>&nbsp;&nbsp;- EAST<br/>&nbsp;&nbsp;- SOUTH<br/>&nbsp;&nbsp;- WEST<br/>&nbsp;&nbsp;- UP<br/>&nbsp;&nbsp;- DOWN<br/>&nbsp;&nbsp;- NORTH_EAST<br/>&nbsp;&nbsp;- NORTH_WEST<br/>&nbsp;&nbsp;- SOUTH_EAST<br/>&nbsp;&nbsp;- SOUTH_WEST  |    |    |    |
|  set_variable_locations_distance  |  Get distance between locations  |  Gets the distance between locations and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location_1: location<br/>location_2: location<br/>type: enum<br/>&nbsp;&nbsp;- THREE_D<br/>&nbsp;&nbsp;- TWO_D<br/>&nbsp;&nbsp;- ALTITUDE<br/>&nbsp;&nbsp;- SQUARED_3D<br/>&nbsp;&nbsp;- SQUARED_2D  |    |    |    |
|  set_variable_log  |  Logarithm of a number (log)  |  Assigns the logarithm value with the chosen argument and base to a variable.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>base: number  |    |    |    |
|  set_variable_map_range  |  Map number to another range  |  Maps a number from one range to another and assigns the result to a variable.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>from_start: number<br/>from_stop: number<br/>to_start: number<br/>to_stop: number  |    |    |    |
|  set_variable_mathematical_expectation  |  Expected value  |  Computes the expected value, i.e. the weighted average of all possible outcomes of a random variable. Can be represented as Σ nᵢ * pᵢ, where n is the outcome and p is the probability  |  set_variable/numerical  |  variable: variable<br/>values: number<br/>probabilities: number  |    |    |    |
|  set_variable_max  |  Maximum value  |  Assigns the largest of the chosen numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>value: number  |    |    |    |
|  set_variable_median  |  Median value  |  Assigns the median value of numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>value: number  |    |    |    |
|  set_variable_min  |  Minimum value  |  Assigns the smallest of the chosen numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>value: number  |    |    |    |
|  set_variable_multiple  |  Set multiple variables (=)  |  Assigns the given values to the given variables.  |  set_variable/setting  |  variables: variable<br/>values: any  |    |    |    |
|  set_variable_multiply  |  Multiplication of numbers (×)  |  Assigns the product of numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>value: number  |    |    |    |
|  set_variable_multiply_vector  |  Multiply vector by number  |  Assigns the result of multiplying a vector by a number to a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector<br/>multiplier: number  |    |    |    |
|  set_variable_obtain_item_custom_model_data  |  Get item model data  |  Gets the list of item model data (CustomModelData) and assigns it to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>value_type: enum<br/>&nbsp;&nbsp;- FLOATS<br/>&nbsp;&nbsp;- BOOLEANS<br/>&nbsp;&nbsp;- STRINGS<br/>&nbsp;&nbsp;- COLORS  |    |    |    |
|  set_variable_parse_json  |  Parse JSON  |  Parses JSON text into elements: maps (if the text is enclosed in curly braces) and lists (if the text is enclosed in square brackets), which you can work with to get the needed values.  |  set_variable/text  |  variable: variable<br/>json: text  |    |    |    |
|  set_variable_parse_to_component  |  Set stylable text type  |  Sets the stylable text type without changing its content and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>text: text<br/>parsing: enum<br/>&nbsp;&nbsp;- PLAIN<br/>&nbsp;&nbsp;- LEGACY<br/>&nbsp;&nbsp;- MINIMESSAGE<br/>&nbsp;&nbsp;- JSON  |    |    |    |
|  set_variable_perlin_noise_3d  |  Perlin noise  |  Assigns the Perlin noise value at the given location to a variable. Returns a number from -1 to 1.  |  set_variable/numerical  |  variable: variable<br/>location: location<br/>seed: number<br/>loc_frequency: number<br/>octaves: number<br/>frequency: number<br/>amplitude: number<br/>range_mode: enum<br/>&nbsp;&nbsp;- ZERO_TO_ONE<br/>&nbsp;&nbsp;- FULL_RANGE<br/>normalized: enum<br/>{TF}  |    |    |    |
|  set_variable_pow  |  Power of a number (^)  |  Assigns the power value with the chosen base and exponent to a variable.  |  set_variable/numerical  |  variable: variable<br/>base: number<br/>power: number  |    |    |    |
|  set_variable_purge  |  Clear variables  |  Clears all variables matching the chosen names.  |  set_variable/setting  |  names: text<br/>scope: enum<br/>&nbsp;&nbsp;- GAME<br/>&nbsp;&nbsp;- SAVE<br/>&nbsp;&nbsp;- LOCAL<br/>&nbsp;&nbsp;- LINE<br/>match: enum<br/>&nbsp;&nbsp;- EQUALS<br/>&nbsp;&nbsp;- NAME_CONTAINS<br/>&nbsp;&nbsp;- PART_CONTAINS<br/>&nbsp;&nbsp;- STARTS_WITH<br/>&nbsp;&nbsp;- ENDS_WITH<br/>ignore_case: enum<br/>{TF}  |    |    |    |
|  set_variable_put_map_value  |  Replace map value  |  Replaces a value in the map by key and assigns the result to a variable.  |  set_variable/map  |  replaced_value: variable<br/>variable: variable<br/>map: map<br/>key: any<br/>value: any  |    |    |    |
|  set_variable_random  |  Set random value  |  Assigns a random value to a variable.  |  set_variable/setting  |  variable: variable<br/>values: any  |    |    |    |
|  set_variable_random_location  |  Create random location  |  Creates a random location in the region between two corners and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location_1: location<br/>location_2: location<br/>integer: enum<br/>{TF}  |    |    |    |
|  set_variable_random_number  |  Random number  |  Assigns a random number in the chosen range to a variable.  |  set_variable/numerical  |  variable: variable<br/>min: number<br/>max: number<br/>integer: enum<br/>{TF}  |    |    |    |
|  set_variable_randomize_list_order  |  Randomize list  |  Sets the element order randomly.  |  set_variable/list  |  variable: variable<br/>list: array  |    |    |    |
|  set_variable_randomize_map_order  |  Randomize map  |  Randomizes the map and assigns the result to a variable.  |  set_variable/map  |  variable: variable<br/>map: map  |    |    |    |
|  set_variable_ray_trace_result  |  Get raycast result  |  Launches a ray with the given parameters. When the ray collides with the given objects (an entity or block) you can get the ray landing location, the block location and face, the entity UUID and the hitbox face. The beam width only affects entities (grows or shrinks their hitboxes).  |  set_variable/world  |  start: location<br/>ray_size: number<br/>max_distance: number<br/>ray_collision_mode: enum<br/>&nbsp;&nbsp;- ONLY_BLOCKS<br/>&nbsp;&nbsp;- BLOCKS_AND_ENTITIES<br/>&nbsp;&nbsp;- ONLY_ENTITIES<br/>ignore_passable_blocks: enum<br/>{TF}<br/>fluid_collision_mode: enum<br/>&nbsp;&nbsp;- NEVER<br/>&nbsp;&nbsp;- SOURCE_ONLY<br/>&nbsp;&nbsp;- ALWAYS<br/>variable_for_hit_location: variable<br/>variable_for_hit_block_location: variable<br/>variable_for_hit_block_face: variable<br/>variable_for_hit_entity_uuid: variable<br/>entities: array<br/>blocks: block  |    |    |    |
|  set_variable_reflect_vector_product  |  Reflect vector relative to second vector  |  Reflects a vector relative to another vector and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>vector_1: vector<br/>vector_2: vector<br/>bounce: number  |    |    |    |
|  set_variable_regex_replace_text  |  Replace regex match  |  Replaces text matching the given regular expression and assigns the result to a variable. The "Replacement" argument may contain $<group name> to reference a group. Include only the flags you need!  |  set_variable/text  |  variable: variable<br/>text: text<br/>regex: text<br/>replacement: text<br/>first: enum<br/>&nbsp;&nbsp;- ANY<br/>&nbsp;&nbsp;- FIRST<br/>ignore_case: enum<br/>{TF}<br/>multiline: enum<br/>{TF}<br/>literal: enum<br/>{TF}<br/>unix_lines: enum<br/>{TF}<br/>comments: enum<br/>{TF}<br/>dot_matches_all: enum<br/>{TF}<br/>cannon_eq: enum<br/>{TF}  |    |    |    |
|  set_variable_remainder  |  Modulo of division (%)  |  Assigns the remainder of dividing two numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>dividend: number<br/>divisor: number<br/>remainder_mode: enum<br/>&nbsp;&nbsp;- REMAINDER<br/>&nbsp;&nbsp;- MODULO  |    |    |    |
|  set_variable_remove  |  Clear variables  |  Clears the values stored in variables.  |  set_variable/setting  |  variables: variable  |    |    |    |
|  set_variable_remove_compass_lodestone  |  Remove lodestone location  |  Removes the lodestone location from the magnetized compass and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_remove_enchantment  |  Remove item enchantment  |  Removes an enchantment from the item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>enchantment: text<br/>enchantment_type: enum<br/>&nbsp;&nbsp;- NORMAL<br/>&nbsp;&nbsp;- STORED<br/>&nbsp;&nbsp;- BOTH  |    |    |    |
|  set_variable_remove_item_attribute  |  Remove item attribute  |  Removes an attribute from the item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>name_or_uuid: text<br/>attribute: enum<br/>&nbsp;&nbsp;- GENERIC_MAX_HEALTH<br/>&nbsp;&nbsp;- GENERIC_MAX_ABSORPTION<br/>&nbsp;&nbsp;- GENERIC_FOLLOW_RANGE<br/>&nbsp;&nbsp;- GENERIC_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_SPEED<br/>&nbsp;&nbsp;- GENERIC_FLYING_SPEED<br/>&nbsp;&nbsp;- GENERIC_ATTACK_DAMAGE<br/>&nbsp;&nbsp;- GENERIC_ATTACK_KNOCKBACK<br/>&nbsp;&nbsp;- GENERIC_ATTACK_SPEED<br/>&nbsp;&nbsp;- GENERIC_ARMOR<br/>&nbsp;&nbsp;- GENERIC_ARMOR_TOUGHNESS<br/>&nbsp;&nbsp;- GENERIC_LUCK<br/>&nbsp;&nbsp;- GENERIC_JUMP_STRENGTH<br/>&nbsp;&nbsp;- ZOMBIE_SPAWN_REINFORCEMENTS<br/>&nbsp;&nbsp;- GENERIC_FALL_DAMAGE_MULTIPLIER<br/>&nbsp;&nbsp;- GENERIC_SAFE_FALL_DISTANCE<br/>&nbsp;&nbsp;- GENERIC_SCALE<br/>&nbsp;&nbsp;- GENERIC_STEP_HEIGHT<br/>&nbsp;&nbsp;- GENERIC_GRAVITY<br/>&nbsp;&nbsp;- PLAYER_BLOCK_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_ENTITY_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_BLOCK_BREAK_SPEED<br/>&nbsp;&nbsp;- GENERIC_BURNING_TIME<br/>&nbsp;&nbsp;- GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- GENERIC_OXYGEN_BONUS<br/>&nbsp;&nbsp;- GENERIC_WATER_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_MINING_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_SNEAKING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SUBMERGED_MINING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SWEEPING_DAMAGE_RATIO<br/>&nbsp;&nbsp;- TEMP_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_TRANSMIT_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_RECEIVE_RANGE<br/>&nbsp;&nbsp;- CAMERA_DISTANCE<br/>&nbsp;&nbsp;- BOUNCINESS<br/>&nbsp;&nbsp;- FRICTION_MODIFIER<br/>&nbsp;&nbsp;- AIR_DRAG_MODIFIER<br/>&nbsp;&nbsp;- NAME_TAG_DISTANCE<br/>&nbsp;&nbsp;- BELOW_NAME_DISTANCE  |    |    |    |
|  set_variable_remove_item_custom_model_data  |  Remove item model data  |  Removes the item model data (CustomModelData) and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>item: item  |    |    |  deprecated  |
|  set_variable_remove_item_custom_tag  |  Remove item custom tag  |  Removes an item custom tag and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>tag_name: text  |    |    |    |
|  set_variable_remove_item_custom_tags  |  Remove item custom tags  |  Removes all item custom tags and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item  |    |    |    |
|  set_variable_remove_item_lore_line  |  Remove item lore line  |  Removes an item lore line and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>line: number  |    |    |    |
|  set_variable_remove_item_potion_effects  |  Remove potion effects from item  |  Removes potion effects from the item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>effects: potion  |    |    |    |
|  set_variable_remove_item_stored_enchantment  |  Remove item stored enchantment  |  Removes the given item stored enchantment and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>item: item<br/>enchantment: text  |    |    |  deprecated  |
|  set_variable_remove_list_duplicates  |  Remove duplicate values  |  Removes all values that occur more than once in the list.  |  set_variable/list  |  variable: variable<br/>list: array  |    |    |    |
|  set_variable_remove_list_value  |  Remove value from list  |  Removes the given value from the list.  |  set_variable/list  |  variable: variable<br/>list: array<br/>value: any<br/>remove_mode: enum<br/>&nbsp;&nbsp;- FIRST<br/>&nbsp;&nbsp;- LAST<br/>&nbsp;&nbsp;- ALL  |    |    |    |
|  set_variable_remove_list_value_at_index  |  Remove list value by index  |  Removes the value from the list at the given index.  |  set_variable/list  |  removed_value: variable<br/>variable: variable<br/>list: array<br/>index: number  |    |    |    |
|  set_variable_remove_map_entry  |  Remove map element  |  Removes a map element and assigns the result to a variable.  |  set_variable/map  |  removed_value: variable<br/>variable: variable<br/>map: map<br/>key: any<br/>values: any  |    |    |    |
|  set_variable_remove_text  |  Remove text  |  Removes all text or part of it and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>remove: text<br/>regex: enum<br/>{TF}  |    |    |    |
|  set_variable_repeat_text  |  Repeat text  |  Assigns the text repeated a given number of times to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>repeat: number  |    |    |    |
|  set_variable_replace_text  |  Replace text  |  Replaces all text or part of it and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>replace: text<br/>replacement: text<br/>first: enum<br/>&nbsp;&nbsp;- ANY<br/>&nbsp;&nbsp;- FIRST<br/>ignore_case: enum<br/>{TF}  |    |    |    |
|  set_variable_reverse_list  |  Reverse list  |  Reverses the order of elements.  |  set_variable/list  |  variable: variable<br/>list: array  |    |    |    |
|  set_variable_reverse_map  |  Flip map  |  Flips the map and assigns the result to a variable.   |  set_variable/map  |  variable: variable<br/>map: map  |    |    |    |
|  set_variable_root  |  Square root of a number (√)  |  Assigns the root value with the chosen radicand and exponent to a variable.  |  set_variable/numerical  |  variable: variable<br/>base: number<br/>root: number  |    |    |    |
|  set_variable_rotate_vector_around_axis  |  Rotate vector around axis  |  Rotates a vector around an axis by the given amount and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector<br/>angle: number<br/>axis: enum<br/>&nbsp;&nbsp;- X<br/>&nbsp;&nbsp;- Y<br/>&nbsp;&nbsp;- Z<br/>angle_units: enum<br/>{DEG_RAD}  |    |    |    |
|  set_variable_rotate_vector_around_vector  |  Rotate vector around another vector  |  Rotates a vector around another vector by the given amount and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>rotating_vector: vector<br/>axis_vector: vector<br/>angle: number<br/>angle_units: enum<br/>{DEG_RAD}  |    |    |    |
|  set_variable_round  |  Round number  |  Assigns the number rounded with the chosen method to a variable.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>precision: number<br/>round_type: enum<br/>&nbsp;&nbsp;- ROUND<br/>&nbsp;&nbsp;- FLOOR<br/>&nbsp;&nbsp;- CEIL  |    |    |    |
|  set_variable_set_all_coordinates  |  Create location  |  Creates a location from the given coordinates.  |  set_variable/location  |  variable: variable<br/>x: number<br/>y: number<br/>z: number<br/>yaw: number<br/>pitch: number  |    |    |    |
|  set_variable_set_armor_trim  |  Set armor trim  |  Sets the given armor trim and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>armor: item<br/>material: item<br/>pattern: item  |    |    |    |
|  set_variable_set_book_page  |  Set book text on page  |  Sets the book text on the given page and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>book: item<br/>text: text<br/>page: number<br/>mode: enum<br/>&nbsp;&nbsp;- MERGE<br/>&nbsp;&nbsp;- APPEND  |    |    |    |
|  set_variable_set_book_pages  |  Set book text  |  Sets the book text and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>book: item<br/>text: text  |    |    |    |
|  set_variable_set_bundle_items  |  Change bundle contents  |  Changes the bundle contents and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>bundle: item<br/>items: item<br/>setting_mode: enum<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- REMOVE  |    |    |    |
|  set_variable_set_compass_lodestone  |  Set lodestone location  |  Sets the lodestone location on the compass and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>location: location<br/>tracked: enum<br/>{TF}  |    |    |    |
|  set_variable_set_component_children  |  Set stylable text child parts  |  Assigns the stylable text with the given child parts to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>children: text  |    |    |  unused  |
|  set_variable_set_component_click  |  Set stylable text click action  |  Sets the click action for the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>value: text<br/>click_action: enum<br/>&nbsp;&nbsp;- COPY_TO_CLIPBOARD<br/>&nbsp;&nbsp;- SUGGEST_COMMAND<br/>&nbsp;&nbsp;- OPEN_URL<br/>&nbsp;&nbsp;- CHANGE_PAGE  |    |    |    |
|  set_variable_set_component_decorations  |  Set stylable text decorations  |  Sets the decorations of the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>bold: enum<br/>&nbsp;&nbsp;- FALSE<br/>&nbsp;&nbsp;- NOT_SET<br/>&nbsp;&nbsp;- TRUE<br/>italic: enum<br/>&nbsp;&nbsp;- FALSE<br/>&nbsp;&nbsp;- NOT_SET<br/>&nbsp;&nbsp;- TRUE<br/>underlined: enum<br/>&nbsp;&nbsp;- FALSE<br/>&nbsp;&nbsp;- NOT_SET<br/>&nbsp;&nbsp;- TRUE<br/>strikethrough: enum<br/>&nbsp;&nbsp;- FALSE<br/>&nbsp;&nbsp;- NOT_SET<br/>&nbsp;&nbsp;- TRUE<br/>obfuscated: enum<br/>&nbsp;&nbsp;- FALSE<br/>&nbsp;&nbsp;- NOT_SET<br/>&nbsp;&nbsp;- TRUE  |    |    |    |
|  set_variable_set_component_entity_hover  |  Set stylable text hover entity  |  Sets the entity shown on hover for the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>name_or_uuid: text  |    |    |    |
|  set_variable_set_component_font  |  Set stylable text font  |  Sets the font of the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>namespace: text<br/>value: text  |    |    |    |
|  set_variable_set_component_hex_color  |  Set stylable text HEX color  |  Sets the HEX color of the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>color: text  |    |    |    |
|  set_variable_set_component_hover  |  Set stylable text hover text  |  Sets the text shown on hover for the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>hover: text  |    |    |    |
|  set_variable_set_component_insertion  |  Set stylable text suggested message  |  Sets the Shift-click suggested message for the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>insertion: text  |    |    |    |
|  set_variable_set_component_item_hover  |  Set stylable text hover item  |  Sets the item shown on hover for the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>hover: item  |    |    |    |
|  set_variable_set_component_shadow_color  |  Set stylable text shadow color  |  Sets the shadow color of the given stylable text and assigns the result to a variable.  |  set_variable/component  |  variable: variable<br/>component: text<br/>color: text  |    |    |    |
|  set_variable_set_coordinate  |  Set location coordinate  |  Sets the chosen coordinate value in the location and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location: location<br/>coordinate: number<br/>type: enum<br/>&nbsp;&nbsp;- X<br/>&nbsp;&nbsp;- Y<br/>&nbsp;&nbsp;- Z<br/>&nbsp;&nbsp;- PITCH<br/>&nbsp;&nbsp;- YAW  |    |    |    |
|  set_variable_set_item_amount  |  Set item count  |  Sets the item count in the stack.  |  set_variable/item  |  variable: variable<br/>item: item<br/>amount: number  |    |    |    |
|  set_variable_set_item_attack_range  |  Set attack radius  |  Sets the given item attack radius and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>min_reach: number<br/>min_max: number<br/>min_creative_reach: number<br/>max_creative_reach: number<br/>hitbox_margin: number<br/>mob_factor: number  |    |    |    |
|  set_variable_set_item_attribute  |  Add attribute to item  |  Adds the given attribute to an item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>amount: number<br/>name: text<br/>attribute: enum<br/>&nbsp;&nbsp;- GENERIC_MAX_HEALTH<br/>&nbsp;&nbsp;- GENERIC_MAX_ABSORPTION<br/>&nbsp;&nbsp;- GENERIC_FOLLOW_RANGE<br/>&nbsp;&nbsp;- GENERIC_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_SPEED<br/>&nbsp;&nbsp;- GENERIC_FLYING_SPEED<br/>&nbsp;&nbsp;- GENERIC_ATTACK_DAMAGE<br/>&nbsp;&nbsp;- GENERIC_ATTACK_KNOCKBACK<br/>&nbsp;&nbsp;- GENERIC_ATTACK_SPEED<br/>&nbsp;&nbsp;- GENERIC_ARMOR<br/>&nbsp;&nbsp;- GENERIC_ARMOR_TOUGHNESS<br/>&nbsp;&nbsp;- GENERIC_LUCK<br/>&nbsp;&nbsp;- GENERIC_JUMP_STRENGTH<br/>&nbsp;&nbsp;- ZOMBIE_SPAWN_REINFORCEMENTS<br/>&nbsp;&nbsp;- GENERIC_FALL_DAMAGE_MULTIPLIER<br/>&nbsp;&nbsp;- GENERIC_SAFE_FALL_DISTANCE<br/>&nbsp;&nbsp;- GENERIC_SCALE<br/>&nbsp;&nbsp;- GENERIC_STEP_HEIGHT<br/>&nbsp;&nbsp;- GENERIC_GRAVITY<br/>&nbsp;&nbsp;- PLAYER_BLOCK_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_ENTITY_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_BLOCK_BREAK_SPEED<br/>&nbsp;&nbsp;- GENERIC_BURNING_TIME<br/>&nbsp;&nbsp;- GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- GENERIC_OXYGEN_BONUS<br/>&nbsp;&nbsp;- GENERIC_WATER_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_MINING_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_SNEAKING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SUBMERGED_MINING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SWEEPING_DAMAGE_RATIO<br/>&nbsp;&nbsp;- TEMP_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_TRANSMIT_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_RECEIVE_RANGE<br/>&nbsp;&nbsp;- CAMERA_DISTANCE<br/>&nbsp;&nbsp;- BOUNCINESS<br/>&nbsp;&nbsp;- FRICTION_MODIFIER<br/>&nbsp;&nbsp;- AIR_DRAG_MODIFIER<br/>&nbsp;&nbsp;- NAME_TAG_DISTANCE<br/>&nbsp;&nbsp;- BELOW_NAME_DISTANCE<br/>slot: enum<br/>&nbsp;&nbsp;- ALL<br/>&nbsp;&nbsp;- MAIN_HAND<br/>&nbsp;&nbsp;- OFF_HAND<br/>&nbsp;&nbsp;- HAND<br/>&nbsp;&nbsp;- BOOTS<br/>&nbsp;&nbsp;- LEGGINGS<br/>&nbsp;&nbsp;- CHEST<br/>&nbsp;&nbsp;- HEAD<br/>&nbsp;&nbsp;- ARMOR<br/>&nbsp;&nbsp;- BODY<br/>operation: enum<br/>&nbsp;&nbsp;- MULTIPLY_SCALAR_1<br/>&nbsp;&nbsp;- ADD_NUMBER<br/>&nbsp;&nbsp;- ADD_SCALAR  |    |    |    |
|  set_variable_set_item_break_sound  |  Set item break sound  |  Sets the sound played when the given item breaks and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>break_sound: sound  |    |    |    |
|  set_variable_set_item_color  |  Set item color  |  Sets the given item color and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>color: text  |  Leather armor<br/>Potions<br/>Tipped arrows<br/>Filled maps<br/>Firework stars  |    |    |
|  set_variable_set_item_component  |  Set item component  |  Sets the item component with the given value and assigns the item to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>component: text<br/>value: text  |    |    |    |
|  set_variable_set_item_contents  |  Set item contents  |  Sets the contents of the given item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>items: item<br/>setting_mode: enum<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- REMOVE  |    |    |    |
|  set_variable_set_item_custom_model_data  |  Set item model data  |  Sets the item model data (CustomModelData) and assigns the result to a variable.  |  set_variable  |  variable: variable<br/>item: item<br/>model: number  |    |    |  deprecated  |
|  set_variable_set_item_custom_tag  |  Set item custom tag  |  Sets an item custom tag and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>tag_name: text<br/>tag_value: text  |    |    |    |
|  set_variable_set_item_destroyable_blocks  |  Set item breakable blocks  |  Sets the blocks the item can break and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>destroyable: item  |    |    |    |
|  set_variable_set_item_durability  |  Set item durability  |  Sets the item durability and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>durability: number<br/>durability_type: enum<br/>&nbsp;&nbsp;- DAMAGE<br/>&nbsp;&nbsp;- DAMAGE_PERCENTAGE<br/>&nbsp;&nbsp;- REMAINING<br/>&nbsp;&nbsp;- REMAINING_PERCENTAGE<br/>&nbsp;&nbsp;- MAX_DAMAGE  |    |    |    |
|  set_variable_set_item_enchantments  |  Set item enchantments  |  Sets the item enchantments and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>enchantments: map<br/>enchantment_type: enum<br/>&nbsp;&nbsp;- NORMAL<br/>&nbsp;&nbsp;- STORED<br/>&nbsp;&nbsp;- BOTH  |    |    |    |
|  set_variable_set_item_food_properties  |  Set item food component data  |  Sets the item food component data and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>nutrition: number<br/>saturation: number<br/>can_always_eat: enum<br/>{TF}  |    |    |    |
|  set_variable_set_item_glider  |  Set item friction  |  Sets the item friction and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>glider: enum<br/>{TF}  |    |  Equipping an item with friction, the player can slide on the ground and glide as if wearing elytra.  |    |
|  set_variable_set_item_glint_override  |  Override item glow  |  Overrides the item glow and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>glowing: enum<br/>{TFN}  |    |    |    |
|  set_variable_set_item_hidden_tooltip  |  Hide item tooltip  |  Hides the item tooltip and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>tooltip_hidden: enum<br/>{TF}  |    |    |    |
|  set_variable_set_item_lore  |  Set item lore  |  Sets the item lore.  |  set_variable/item  |  variable: variable<br/>lore: text<br/>item: item  |    |  Clears the lore if no new one is given.  |    |
|  set_variable_set_item_lore_line  |  Set item lore line  |  Sets the item lore line.  |  set_variable/item  |  variable: variable<br/>item: item<br/>text: text<br/>line: number<br/>mode: enum<br/>&nbsp;&nbsp;- MERGE<br/>&nbsp;&nbsp;- APPEND  |    |    |    |
|  set_variable_set_item_max_stack_size  |  Set maximum stack size  |  Sets the maximum stack size for the given item and assigns it to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>size: number  |    |  The item count in a stack can only be from 1 to 99.<br/>Value 0 resets the maximum stack size to the default.  |    |
|  set_variable_set_item_minimum_attack_charge  |  Set minimum attack charge  |  Sets the minimum item charge needed for an attack and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>minimum_attack_charge: number  |    |    |    |
|  set_variable_set_item_model_data  |  Set item model  |  Sets the model of the given item and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>model: text  |    |    |    |
|  set_variable_set_item_name  |  Set item name  |  Sets the item display name.  |  set_variable/item  |  variable: variable<br/>item: item<br/>text: text  |    |    |    |
|  set_variable_set_item_piercing_weapon  |  Set piercing  |  Sets the item piercing and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>deals_knockback: enum<br/>{TF}<br/>dismounts: enum<br/>{TF}<br/>sound: sound<br/>hit_sound: sound  |    |    |    |
|  set_variable_set_item_placeable_blocks  |  Set item placeable blocks  |  Sets the blocks the item can be placed on and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>placeable: item  |    |    |    |
|  set_variable_set_item_rarity  |  Set item rarity  |  Sets the item rarity and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>rarity: enum<br/>&nbsp;&nbsp;- NONE<br/>&nbsp;&nbsp;- COMMON<br/>&nbsp;&nbsp;- UNCOMMON<br/>&nbsp;&nbsp;- RARE<br/>&nbsp;&nbsp;- EPIC  |    |    |    |
|  set_variable_set_item_swing_animation  |  Set swing animation data  |  Sets the given item swing animation data and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>duration: number<br/>animation: enum<br/>&nbsp;&nbsp;- NONE<br/>&nbsp;&nbsp;- WHACK<br/>&nbsp;&nbsp;- STAB  |    |    |    |
|  set_variable_set_item_tooltip_style  |  Set item tooltip style  |  Sets the item tooltip style and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>style: text  |    |    |    |
|  set_variable_set_item_type  |  Set item type  |  Changes the item type without changing other item data.  |  set_variable/item  |  variable: variable<br/>item: item<br/>type: text  |    |    |    |
|  set_variable_set_item_unbreakable  |  Set item unbreakable  |  Sets the item unbreakable state and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>unbreakable: enum<br/>{TF}  |    |    |    |
|  set_variable_set_item_use_effects  |  Set use effects  |  Sets the item effects appearing on use and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>can_sprint: enum<br/>{TF}<br/>interact_vibrations: enum<br/>{TF}<br/>speed_multiplier: number  |    |    |    |
|  set_variable_set_item_use_remainder  |  Set item transformation  |  Sets the item the given item turns into after use and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>remainder: item  |    |    |    |
|  set_variable_set_item_visibility_flags  |  Set item visibility flags  |  Sets the given item visibility flags and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>hide_dye: enum<br/>&nbsp;&nbsp;- ON<br/>&nbsp;&nbsp;- NO_CHANGE<br/>&nbsp;&nbsp;- OFF<br/>hide_enchantments: enum<br/>&nbsp;&nbsp;- ON<br/>&nbsp;&nbsp;- NO_CHANGE<br/>&nbsp;&nbsp;- OFF<br/>hide_attributes: enum<br/>&nbsp;&nbsp;- ON<br/>&nbsp;&nbsp;- NO_CHANGE<br/>&nbsp;&nbsp;- OFF<br/>hide_unbreakable: enum<br/>&nbsp;&nbsp;- ON<br/>&nbsp;&nbsp;- NO_CHANGE<br/>&nbsp;&nbsp;- OFF<br/>hide_place_on: enum<br/>&nbsp;&nbsp;- ON<br/>&nbsp;&nbsp;- NO_CHANGE<br/>&nbsp;&nbsp;- OFF<br/>hide_destroys: enum<br/>&nbsp;&nbsp;- ON<br/>&nbsp;&nbsp;- NO_CHANGE<br/>&nbsp;&nbsp;- OFF<br/>hide_potion_effects: enum<br/>&nbsp;&nbsp;- ON<br/>&nbsp;&nbsp;- NO_CHANGE<br/>&nbsp;&nbsp;- OFF<br/>hide_armor_trim: enum<br/>&nbsp;&nbsp;- ON<br/>&nbsp;&nbsp;- NO_CHANGE<br/>&nbsp;&nbsp;- OFF  |    |    |    |
|  set_variable_set_item_weapon  |  Set item weapon component data  |  Sets the item weapon component data and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>item_damage_per_attack: number<br/>disable_blocking: number  |    |    |    |
|  set_variable_set_list_value  |  Set list value  |  Sets the list value at the given index.  |  set_variable/list  |  variable: variable<br/>list: array<br/>number: number<br/>value: any  |    |    |    |
|  set_variable_set_location_direction  |  Set location direction  |  Sets the location direction and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location: location<br/>vector: vector  |    |    |    |
|  set_variable_set_map_value  |  Set map value  |  Sets the given map value by key and assigns the result to a variable.  |  set_variable/map  |  variable: variable<br/>map: map<br/>key: any<br/>value: any  |    |    |    |
|  set_variable_set_particle_amount  |  Set particle count  |  Sets the particle count and assigns the result to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>amount: number  |    |    |    |
|  set_variable_set_particle_color  |  Set particle color  |  Sets the particle color and assigns the result to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>hex_color: text<br/>color_type: enum<br/>&nbsp;&nbsp;- COLOR<br/>&nbsp;&nbsp;- TO_COLOR  |    |    |    |
|  set_variable_set_particle_material  |  Set particle material  |  Sets the particle material and assigns the result to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>material: item  |    |    |    |
|  set_variable_set_particle_offset  |  Set particle motion  |  Sets the particle motion and assigns the result to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>offset: vector  |    |    |    |
|  set_variable_set_particle_size  |  Set particle size  |  Sets the particle size and assigns the result to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>size: number  |    |    |    |
|  set_variable_set_particle_spread  |  Set particle spread  |  Assigns the particle spread value to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>horizontal: number<br/>vertical: number  |    |    |    |
|  set_variable_set_particle_type  |  Set particle type  |  Sets the particle type and assigns the result to a variable.  |  set_variable/particle  |  variable: variable<br/>particle: particle<br/>type: text  |    |    |    |
|  set_variable_set_potion_effect_amplifier  |  Set potion strength  |  Sets the potion strength and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>potion: potion<br/>amplifier: number  |    |    |    |
|  set_variable_set_potion_effect_duration  |  Set potion duration  |  Sets the potion duration and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>potion: potion<br/>duration: number  |    |    |    |
|  set_variable_set_potion_effect_type  |  Set potion effect  |  Sets the potion effect and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>potion: potion<br/>effect_type: text  |    |    |    |
|  set_variable_set_sound_pitch  |  Set sound pitch  |  Sets the sound pitch and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound<br/>pitch: number  |    |    |    |
|  set_variable_set_sound_source  |  Set sound source  |  Sets the sound source and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound<br/>source: enum<br/>&nbsp;&nbsp;- AMBIENT<br/>&nbsp;&nbsp;- BLOCK<br/>&nbsp;&nbsp;- HOSTILE<br/>&nbsp;&nbsp;- MASTER<br/>&nbsp;&nbsp;- MUSIC<br/>&nbsp;&nbsp;- NEUTRAL<br/>&nbsp;&nbsp;- PLAYER<br/>&nbsp;&nbsp;- RECORD<br/>&nbsp;&nbsp;- VOICE<br/>&nbsp;&nbsp;- WEATHER<br/>&nbsp;&nbsp;- UI  |    |    |    |
|  set_variable_set_sound_type  |  Set sound type  |  Sets the sound type and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound<br/>namespace: text<br/>value: text  |    |    |    |
|  set_variable_set_sound_variation  |  Set sound variation  |  Sets the sound variation and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound<br/>variation: text  |    |  Either a text variation or a numeric seed can be set.<br/>Random seed if it could not be set.  |    |
|  set_variable_set_sound_volume_action  |  Set sound volume  |  Sets the sound volume and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>sound: sound<br/>volume: number  |    |    |    |
|  set_variable_set_template_code  |  Set code into template  |  Sets code into a template and assigns the result to a variable.  |  set_variable/misc  |  variable: variable<br/>template: item<br/>code: any  |    |    |    |
|  set_variable_set_texture_to_map  |  Set map image  |  Sets the map image from the given URL. Images may disappear on server restart, so it is recommended to set them again for the same maps on world start.  |  set_variable/item  |  variable: variable<br/>map: item<br/>url: text  |    |    |    |
|  set_variable_set_vector_component  |  Set vector coordinate  |  Sets the given vector coordinate and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector<br/>value: number<br/>vector_component: enum<br/>&nbsp;&nbsp;- X<br/>&nbsp;&nbsp;- Y<br/>&nbsp;&nbsp;- Z  |    |    |    |
|  set_variable_set_vector_length  |  Set vector length  |  Sets the vector length and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector<br/>length: number  |    |    |    |
|  set_variable_shift_all_coordinates  |  Shift all location coordinates  |  Shifts all location coordinates by the given values.  |  set_variable/location  |  variable: variable<br/>location: location<br/>x: number<br/>y: number<br/>z: number<br/>yaw: number<br/>pitch: number  |    |    |    |
|  set_variable_shift_coordinate  |  Shift location coordinate  |  Shifts a location coordinate by the given value.  |  set_variable/location  |  variable: variable<br/>location: location<br/>distance: number<br/>type: enum<br/>&nbsp;&nbsp;- X<br/>&nbsp;&nbsp;- Y<br/>&nbsp;&nbsp;- Z<br/>&nbsp;&nbsp;- PITCH<br/>&nbsp;&nbsp;- YAW  |    |    |    |
|  set_variable_shift_location_in_direction  |  Shift location in direction  |  Shifts the location in the given direction by the given value.  |  set_variable/location  |  variable: variable<br/>location: location<br/>shift: number<br/>direction: enum<br/>&nbsp;&nbsp;- FORWARD<br/>&nbsp;&nbsp;- UPWARD<br/>&nbsp;&nbsp;- SIDEWAYS  |    |    |    |
|  set_variable_shift_location_on_vector  |  Shift location by vector  |  Shifts the given location along a vector and assigns the result to a variable.  |  set_variable/location  |  variable: variable<br/>location: location<br/>vector: vector<br/>length: number  |    |    |    |
|  set_variable_shift_location_towards_location  |  Offset location towards location  |  Offsets the location towards the given location by a given distance and assigns it to a variable.  |  set_variable/location  |  variable: variable<br/>location_from: location<br/>location_to: location<br/>distance: number  |    |    |    |
|  set_variable_simplex_noise_3d  |  Simplex noise  |  Assigns the Simplex noise value at the given location to a variable. Returns a number from -1 to 1.  |  set_variable/numerical  |  variable: variable<br/>location: location<br/>seed: number<br/>loc_frequency: number<br/>octaves: number<br/>frequency: number<br/>amplitude: number<br/>range_mode: enum<br/>&nbsp;&nbsp;- ZERO_TO_ONE<br/>&nbsp;&nbsp;- FULL_RANGE<br/>normalized: enum<br/>{TF}  |    |    |    |
|  set_variable_sine  |  Sine of a number  |  Returns the sine of a number.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>variant: enum<br/>&nbsp;&nbsp;- SINE<br/>&nbsp;&nbsp;- ARCSINE<br/>&nbsp;&nbsp;- HYPERBOLIC_SINE<br/>&nbsp;&nbsp;- HYPERBOLIC_ARCSINE<br/>input: enum<br/>{DEG_RAD}  |    |    |    |
|  set_variable_sort_any_list  |  Sort list  |  Sorts the list elements.  |  set_variable/list  |  variable: variable<br/>list: array<br/>sort_mode: enum<br/>&nbsp;&nbsp;- ASCENDING<br/>&nbsp;&nbsp;- DESCENDING  |  Numbers<br/>Text<br/>Lists  |    |    |
|  set_variable_sort_any_map  |  Sort map  |  Sorts the map by the given parameters and assigns the result to a variable.  |  set_variable/map  |  variable: variable<br/>map: map<br/>sort_order: enum<br/>&nbsp;&nbsp;- ASCENDING<br/>&nbsp;&nbsp;- DESCENDING<br/>sort_type: enum<br/>&nbsp;&nbsp;- KEYS<br/>&nbsp;&nbsp;- VALUES  |    |    |    |
|  set_variable_split_text  |  Split text into elements  |  Splits text into list elements by the given character and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>delimiter: text  |    |    |    |
|  set_variable_split_text_by_length  |  Word wrap  |  Splits text by words into a list of strings and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>max_length: number  |    |    |    |
|  set_variable_strip_text  |  Remove spaces  |  Removes spaces in the text and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>strip_type: enum<br/>&nbsp;&nbsp;- ALL<br/>&nbsp;&nbsp;- START<br/>&nbsp;&nbsp;- END<br/>&nbsp;&nbsp;- INDENT  |    |    |    |
|  set_variable_subtract  |  Subtraction of numbers (-)  |  Assigns the difference of numbers to a variable.  |  set_variable/numerical  |  variable: variable<br/>value: number  |    |    |    |
|  set_variable_subtract_vectors  |  Vector difference  |  Assigns the vector difference value to a variable.  |  set_variable/vector  |  variable: variable<br/>vectors: vector  |    |    |    |
|  set_variable_tangent  |  Tangent of a number  |  Returns the tangent of a number.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>variant: enum<br/>&nbsp;&nbsp;- TANGENT<br/>&nbsp;&nbsp;- ARCTANGENT<br/>&nbsp;&nbsp;- HYPERBOLIC_TANGENT<br/>&nbsp;&nbsp;- HYPERBOLIC_ARCTANGENT<br/>input: enum<br/>{DEG_RAD}  |    |    |    |
|  set_variable_text  |  Set text into variable  |  Joins and assigns one or more text values to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>merging: enum<br/>&nbsp;&nbsp;- SPACES<br/>&nbsp;&nbsp;- CONCATENATION<br/>&nbsp;&nbsp;- SEPARATE_LINES  |    |    |    |
|  set_variable_text_case  |  Set text case  |  Sets the text case and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>case_type: enum<br/>&nbsp;&nbsp;- UPPER<br/>&nbsp;&nbsp;- LOWER<br/>&nbsp;&nbsp;- PROPER<br/>&nbsp;&nbsp;- INVERT<br/>&nbsp;&nbsp;- RANDOM  |    |    |    |
|  set_variable_text_length  |  Get text length  |  Assigns the number of characters in the text to a variable.  |  set_variable/text  |  variable: variable<br/>text: text  |    |    |    |
|  set_variable_text_to_bytes  |  Convert text to bytes  |  Converts text to bytes and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>charset: enum<br/>&nbsp;&nbsp;- UTF_16<br/>&nbsp;&nbsp;- UTF_8<br/>&nbsp;&nbsp;- ASCII  |    |    |    |
|  set_variable_text_to_chars  |  Convert text to characters  |  Converts text to characters of the chosen type and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>chars_type: enum<br/>&nbsp;&nbsp;- CHARS<br/>&nbsp;&nbsp;- CODES<br/>&nbsp;&nbsp;- CODEPOINTS_CHARS<br/>&nbsp;&nbsp;- CODEPOINTS  |    |    |    |
|  set_variable_to_char  |  Get character by number  |  Gets the given character by number and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>number: number  |    |    |    |
|  set_variable_to_hsb  |  Create HSB color  |  Creates a HEX color based on hue, saturation and brightness.  |  set_variable/misc  |  variable: variable<br/>hue: number<br/>saturation: number<br/>brightness: number  |    |    |    |
|  set_variable_to_hsl  |  Create HSL color  |  Creates a HEX color based on hue, saturation and lightness.  |  set_variable/misc  |  variable: variable<br/>hue: number<br/>saturation: number<br/>lightness: number  |    |    |    |
|  set_variable_to_json  |  Convert to JSON  |  Converts maps and lists to JSON text.  |  set_variable/text  |  variable: variable<br/>value: any<br/>pretty_print: enum<br/>{TF}  |    |    |    |
|  set_variable_to_rgb  |  Create RGB color  |  Creates a HEX color from the red, green and blue channels.  |  set_variable/misc  |  variable: variable<br/>red: number<br/>green: number<br/>blue: number  |    |    |    |
|  set_variable_trim_list  |  Trim list  |  Returns the list containing the elements of the given list between the given start and end indices, inclusive.  |  set_variable/list  |  variable: variable<br/>list: array<br/>start: number<br/>end: number  |    |    |    |
|  set_variable_trim_text  |  Trim text  |  Trims the text and assigns the result to a variable.  |  set_variable/text  |  variable: variable<br/>text: text<br/>start: number<br/>end: number  |    |    |    |
|  set_variable_unset_item_components  |  Remove item components  |  Removes the given item components and assigns the result to a variable.  |  set_variable/item  |  variable: variable<br/>item: item<br/>components: text  |    |    |    |
|  set_variable_value  |  Set value (=)  |  Assigns a value to a variable.  |  set_variable/setting  |  variable: variable<br/>value: any  |    |    |    |
|  set_variable_vector  |  Create vector  |  Creates a vector from the given coordinates and assigns the result to a variable.  |  set_variable/vector  |  variable: variable<br/>x: number<br/>y: number<br/>z: number  |    |    |    |
|  set_variable_vector_cross_product  |  Cross product of two vectors  |  Assigns the cross product of two vectors to a variable.  |  set_variable/vector  |  variable: variable<br/>vector_1: vector<br/>vector_2: vector  |    |    |    |
|  set_variable_vector_dot_product  |  Dot product of two vectors  |  Assigns the dot product of two vectors to a variable.  |  set_variable/vector  |  variable: variable<br/>vector_1: vector<br/>vector_2: vector  |    |    |    |
|  set_variable_vector_to_direction_name  |  Get vector cardinal direction  |  Sets the cardinal direction the vector points to into a variable.  |  set_variable/vector  |  variable: variable<br/>vector: vector  |    |    |    |
|  set_variable_voronoi_noise_3d  |  Voronoi noise  |  Assigns the Voronoi noise value at the given location to a variable. Returns a number from 0 to 1.  |  set_variable/numerical  |  variable: variable<br/>location: location<br/>seed: number<br/>frequency: number<br/>displacement: number<br/>range_mode: enum<br/>&nbsp;&nbsp;- ZERO_TO_ONE<br/>&nbsp;&nbsp;- FULL_RANGE<br/>enable_distance: enum<br/>{TF}  |    |    |    |
|  set_variable_warp  |  Wrap number  |  Checks whether the number is between two bounds, and if not, wraps it around those bounds.  |  set_variable/numerical  |  variable: variable<br/>number: number<br/>min: number<br/>max: number  |    |    |    |

## Quick ref
> Argument **names and types only**, one line per action/condition — scan this first. Exact enum values and extra info: see the full table row above. ⚠ deprecated = do not use.

- `if_variable_block_equals` — (no arguments)
- `if_variable_block_is_minecraft_tagged` — (no arguments)
- `if_variable_block_is_solid` — (no arguments)
- `if_variable_equals` — (no arguments)
- `if_variable_exists` — (no arguments)
- `if_variable_greater` — (no arguments)
- `if_variable_greater_or_equals` — (no arguments)
- `if_variable_in_range` — (no arguments) ⚠ deprecated
- `if_variable_is_type` — (no arguments)
- `if_variable_item_equals` — (no arguments)
- `if_variable_item_has_enchantment` — (no arguments)
- `if_variable_item_has_stored_enchantment` — (no arguments) ⚠ deprecated
- `if_variable_item_has_tag` — (no arguments)
- `if_variable_item_is_block` — (no arguments)
- `if_variable_item_is_minecraft_tagged` — (no arguments)
- `if_variable_less` — (no arguments)
- `if_variable_less_or_equals` — (no arguments)
- `if_variable_list_contains_value` — (no arguments)
- `if_variable_list_is_empty` — (no arguments)
- `if_variable_list_value_equals` — (no arguments)
- `if_variable_location_in_range` — (no arguments)
- `if_variable_location_is_near` — (no arguments)
- `if_variable_map_has_key` — (no arguments)
- `if_variable_map_value_equals` — (no arguments)
- `if_variable_multiple_equals` — (no arguments)
- `if_variable_not_equals` — (no arguments) ⚠ deprecated
- `if_variable_number_in_range` — (no arguments)
- `if_variable_range_intersects_range` — (no arguments)
- `if_variable_text_contains` — (no arguments)
- `if_variable_text_ends_with` — (no arguments)
- `if_variable_text_matches` — (no arguments)
- `if_variable_text_starts_with` — (no arguments)
- `set_variable_absolute` — (no arguments)
- `set_variable_add` — (no arguments)
- `set_variable_add_item_enchantment` — (no arguments)
- `set_variable_add_item_potion_effects` — (no arguments)
- `set_variable_add_item_stored_enchantment` — (no arguments) ⚠ deprecated
- `set_variable_add_vectors` — (no arguments)
- `set_variable_align_location` — (no arguments)
- `set_variable_align_to_axis_vector` — (no arguments)
- `set_variable_append_component` — (no arguments)
- `set_variable_append_list` — (no arguments) ⚠ deprecated
- `set_variable_append_lists` — (no arguments)
- `set_variable_append_map` — (no arguments) ⚠ deprecated
- `set_variable_append_maps` — (no arguments)
- `set_variable_append_value` — (no arguments)
- `set_variable_atan2` — (no arguments)
- `set_variable_average` — (no arguments)
- `set_variable_bitwise_operation` — (no arguments)
- `set_variable_bytes_to_text` — (no arguments)
- `set_variable_center_location` — (no arguments)
- `set_variable_change_component_parsing` — (no arguments)
- `set_variable_char_to_number` — (no arguments)
- `set_variable_chunk_list` — (no arguments)
- `set_variable_chunk_text` — (no arguments)
- `set_variable_clamp` — (no arguments)
- `set_variable_clamp_location` — (no arguments)
- `set_variable_clear_color_codes` — (no arguments)
- `set_variable_clear_map` — (no arguments) ⚠ deprecated
- `set_variable_code_bytes` — (no arguments)
- `set_variable_compact_component` — (no arguments)
- `set_variable_component_of_children` — (no arguments)
- `set_variable_convert_number_to_text` — (no arguments)
- `set_variable_convert_text_to_number` — (no arguments)
- `set_variable_cosine` — (no arguments)
- `set_variable_cotangent` — (no arguments)
- `set_variable_create_head_object_component` — (no arguments)
- `set_variable_create_keybind_component` — (no arguments)
- `set_variable_create_list` — (no arguments)
- `set_variable_create_map` — (no arguments)
- `set_variable_create_map_from_values` — (no arguments)
- `set_variable_create_sprite_object_component` — (no arguments)
- `set_variable_create_translatable_component` — (no arguments)
- `set_variable_decrement` — (no arguments)
- `set_variable_destructure_list` — (no arguments)
- `set_variable_divide` — (no arguments)
- `set_variable_divide_vector` — (no arguments)
- `set_variable_edit_item_custom_model_data` — (no arguments)
- `set_variable_face_location` — (no arguments)
- `set_variable_find_nearest_location` — (no arguments)
- `set_variable_find_nearest_number` — (no arguments)
- `set_variable_flatten_list` — (no arguments)
- `set_variable_format_timestamp` — (no arguments)
- `set_variable_gamma_function` — (no arguments)
- `set_variable_gaussian_distribution` — (no arguments)
- `set_variable_get_all_block_data` — (no arguments)
- `set_variable_get_all_coordinates` — (no arguments)
- `set_variable_get_angle_between_vectors` — (no arguments)
- `set_variable_get_block_data` — (no arguments)
- `set_variable_get_block_growth` — (no arguments)
- `set_variable_get_block_material` — (no arguments)
- `set_variable_get_block_material_property` — (no arguments)
- `set_variable_get_block_power` — (no arguments)
- `set_variable_get_block_sound` — (no arguments)
- `set_variable_get_blocks_by_tag` — (no arguments)
- `set_variable_get_book_text` — (no arguments)
- `set_variable_get_brushable_block_item` — (no arguments)
- `set_variable_get_bundle_items` — (no arguments)
- `set_variable_get_char_at` — (no arguments)
- `set_variable_get_color_channels` — (no arguments)
- `set_variable_get_compass_lodestone` — (no arguments)
- `set_variable_get_component_children` — (no arguments)
- `set_variable_get_component_decorations` — (no arguments)
- `set_variable_get_component_hex_color` — (no arguments)
- `set_variable_get_component_parsing` — (no arguments)
- `set_variable_get_container_contents` — (no arguments)
- `set_variable_get_container_lock` — (no arguments)
- `set_variable_get_container_name` — (no arguments)
- `set_variable_get_coordinate` — (no arguments)
- `set_variable_get_custom_recipes` — (no arguments)
- `set_variable_get_decorate_pot_sherd` — (no arguments)
- `set_variable_get_entity_types_by_tag` — (no arguments)
- `set_variable_get_index_of_subtext` — (no arguments)
- `set_variable_get_item_amount` — (no arguments)
- `set_variable_get_item_attack_range` — (no arguments)
- `set_variable_get_item_attribute` — (no arguments)
- `set_variable_get_item_break_sound` — (no arguments)
- `set_variable_get_item_color` — (no arguments)
- `set_variable_get_item_component` — (no arguments)
- `set_variable_get_item_contents` — (no arguments)
- `set_variable_get_item_custom_model_data` — (no arguments) ⚠ deprecated
- `set_variable_get_item_custom_tag` — (no arguments)
- `set_variable_get_item_custom_tags` — (no arguments)
- `set_variable_get_item_destroyable_blocks` — (no arguments)
- `set_variable_get_item_durability` — (no arguments)
- `set_variable_get_item_effective_name` — (no arguments)
- `set_variable_get_item_enchantment` — (no arguments)
- `set_variable_get_item_enchantments` — (no arguments)
- `set_variable_get_item_food_properties` — (no arguments)
- `set_variable_get_item_lore` — (no arguments)
- `set_variable_get_item_lore_line` — (no arguments)
- `set_variable_get_item_max_stack_size` — (no arguments)
- `set_variable_get_item_minimum_attack_charge` — (no arguments)
- `set_variable_get_item_model_data` — (no arguments)
- `set_variable_get_item_name` — (no arguments)
- `set_variable_get_item_nbt_tags` — (no arguments)
- `set_variable_get_item_placeable_blocks` — (no arguments)
- `set_variable_get_item_potion_effects` — (no arguments)
- `set_variable_get_item_rarity` — (no arguments)
- `set_variable_get_item_sprite` — (no arguments)
- `set_variable_get_item_stored_enchantments` — (no arguments) ⚠ deprecated
- `set_variable_get_item_swing_animation` — (no arguments)
- `set_variable_get_item_tooltip_style` — (no arguments)
- `set_variable_get_item_type` — (no arguments)
- `set_variable_get_item_use_remainder` — (no arguments)
- `set_variable_get_item_weapon` — (no arguments)
- `set_variable_get_items_by_tag` — (no arguments)
- `set_variable_get_lectern_book` — (no arguments)
- `set_variable_get_lectern_page` — (no arguments)
- `set_variable_get_light_level` — (no arguments)
- `set_variable_get_list_index_of_value` — (no arguments)
- `set_variable_get_list_length` — (no arguments)
- `set_variable_get_list_random_value` — (no arguments)
- `set_variable_get_list_value` — (no arguments)
- `set_variable_get_list_variables` — (no arguments)
- `set_variable_get_location_direction` — (no arguments)
- `set_variable_get_map_entry_by_index` — (no arguments)
- `set_variable_get_map_key_by_index` — (no arguments) ⚠ deprecated
- `set_variable_get_map_keys` — (no arguments)
- `set_variable_get_map_keys_by_value` — (no arguments)
- `set_variable_get_map_random_entry` — (no arguments)
- `set_variable_get_map_size` — (no arguments)
- `set_variable_get_map_value` — (no arguments) ⚠ deprecated
- `set_variable_get_map_value_by_index` — (no arguments) ⚠ deprecated
- `set_variable_get_map_value_single` — (no arguments)
- `set_variable_get_map_values` — (no arguments)
- `set_variable_get_midpoint_between_vectors` — (no arguments)
- `set_variable_get_particle_amount` — (no arguments)
- `set_variable_get_particle_color` — (no arguments)
- `set_variable_get_particle_material` — (no arguments)
- `set_variable_get_particle_offset` — (no arguments)
- `set_variable_get_particle_size` — (no arguments)
- `set_variable_get_particle_spread` — (no arguments)
- `set_variable_get_particle_type` — (no arguments)
- `set_variable_get_player_head` — (no arguments)
- `set_variable_get_player_head_owner` — (no arguments)
- `set_variable_get_player_head_value` — (no arguments)
- `set_variable_get_potion_effect_amplifier` — (no arguments)
- `set_variable_get_potion_effect_duration` — (no arguments)
- `set_variable_get_potion_effect_type` — (no arguments)
- `set_variable_get_sculk_shrieker_warning_level` — (no arguments)
- `set_variable_get_sign_text` — (no arguments)
- `set_variable_get_sound_pitch` — (no arguments)
- `set_variable_get_sound_source` — (no arguments)
- `set_variable_get_sound_type` — (no arguments)
- `set_variable_get_sound_variation` — (no arguments)
- `set_variable_get_sound_volume_action` — (no arguments)
- `set_variable_get_template_code` — (no arguments)
- `set_variable_get_text_regex_groups` — (no arguments)
- `set_variable_get_text_similarity` — (no arguments)
- `set_variable_get_text_width` — (no arguments)
- `set_variable_get_tile_block_custom_tag` — (no arguments)
- `set_variable_get_tile_block_nbt` — (no arguments)
- `set_variable_get_vault_displayed_item` — (no arguments)
- `set_variable_get_vault_next_state_update_time` — (no arguments)
- `set_variable_get_vector_all_components` — (no arguments)
- `set_variable_get_vector_between_locations` — (no arguments)
- `set_variable_get_vector_component` — (no arguments)
- `set_variable_get_vector_from_block_face` — (no arguments)
- `set_variable_get_vector_length` — (no arguments)
- `set_variable_hadamard_vector_product` — (no arguments)
- `set_variable_hash` — (no arguments)
- `set_variable_hide_item_components` — (no arguments)
- `set_variable_increment` — (no arguments)
- `set_variable_insert_list_value` — (no arguments)
- `set_variable_join_text` — (no arguments)
- `set_variable_join_to_component` — (no arguments)
- `set_variable_lerp_number` — (no arguments)
- `set_variable_location_relative` — (no arguments)
- `set_variable_locations_distance` — (no arguments)
- `set_variable_log` — (no arguments)
- `set_variable_map_range` — (no arguments)
- `set_variable_mathematical_expectation` — (no arguments)
- `set_variable_max` — (no arguments)
- `set_variable_median` — (no arguments)
- `set_variable_min` — (no arguments)
- `set_variable_multiple` — (no arguments)
- `set_variable_multiply` — (no arguments)
- `set_variable_multiply_vector` — (no arguments)
- `set_variable_obtain_item_custom_model_data` — (no arguments)
- `set_variable_parse_json` — (no arguments)
- `set_variable_parse_to_component` — (no arguments)
- `set_variable_perlin_noise_3d` — (no arguments)
- `set_variable_pow` — (no arguments)
- `set_variable_purge` — (no arguments)
- `set_variable_put_map_value` — (no arguments)
- `set_variable_random` — (no arguments)
- `set_variable_random_location` — (no arguments)
- `set_variable_random_number` — (no arguments)
- `set_variable_randomize_list_order` — (no arguments)
- `set_variable_randomize_map_order` — (no arguments)
- `set_variable_ray_trace_result` — (no arguments)
- `set_variable_reflect_vector_product` — (no arguments)
- `set_variable_regex_replace_text` — (no arguments)
- `set_variable_remainder` — (no arguments)
- `set_variable_remove` — (no arguments)
- `set_variable_remove_compass_lodestone` — (no arguments)
- `set_variable_remove_enchantment` — (no arguments)
- `set_variable_remove_item_attribute` — (no arguments)
- `set_variable_remove_item_custom_model_data` — (no arguments) ⚠ deprecated
- `set_variable_remove_item_custom_tag` — (no arguments)
- `set_variable_remove_item_custom_tags` — (no arguments)
- `set_variable_remove_item_lore_line` — (no arguments)
- `set_variable_remove_item_potion_effects` — (no arguments)
- `set_variable_remove_item_stored_enchantment` — (no arguments) ⚠ deprecated
- `set_variable_remove_list_duplicates` — (no arguments)
- `set_variable_remove_list_value` — (no arguments)
- `set_variable_remove_list_value_at_index` — (no arguments)
- `set_variable_remove_map_entry` — (no arguments)
- `set_variable_remove_text` — (no arguments)
- `set_variable_repeat_text` — (no arguments)
- `set_variable_replace_text` — (no arguments)
- `set_variable_reverse_list` — (no arguments)
- `set_variable_reverse_map` — (no arguments)
- `set_variable_root` — (no arguments)
- `set_variable_rotate_vector_around_axis` — (no arguments)
- `set_variable_rotate_vector_around_vector` — (no arguments)
- `set_variable_round` — (no arguments)
- `set_variable_set_all_coordinates` — (no arguments)
- `set_variable_set_armor_trim` — (no arguments)
- `set_variable_set_book_page` — (no arguments)
- `set_variable_set_book_pages` — (no arguments)
- `set_variable_set_bundle_items` — (no arguments)
- `set_variable_set_compass_lodestone` — (no arguments)
- `set_variable_set_component_children` — (no arguments)
- `set_variable_set_component_click` — (no arguments)
- `set_variable_set_component_decorations` — (no arguments)
- `set_variable_set_component_entity_hover` — (no arguments)
- `set_variable_set_component_font` — (no arguments)
- `set_variable_set_component_hex_color` — (no arguments)
- `set_variable_set_component_hover` — (no arguments)
- `set_variable_set_component_insertion` — (no arguments)
- `set_variable_set_component_item_hover` — (no arguments)
- `set_variable_set_component_shadow_color` — (no arguments)
- `set_variable_set_coordinate` — (no arguments)
- `set_variable_set_item_amount` — (no arguments)
- `set_variable_set_item_attack_range` — (no arguments)
- `set_variable_set_item_attribute` — (no arguments)
- `set_variable_set_item_break_sound` — (no arguments)
- `set_variable_set_item_color` — (no arguments)
- `set_variable_set_item_component` — (no arguments)
- `set_variable_set_item_contents` — (no arguments)
- `set_variable_set_item_custom_model_data` — (no arguments) ⚠ deprecated
- `set_variable_set_item_custom_tag` — (no arguments)
- `set_variable_set_item_destroyable_blocks` — (no arguments)
- `set_variable_set_item_durability` — (no arguments)
- `set_variable_set_item_enchantments` — (no arguments)
- `set_variable_set_item_food_properties` — (no arguments)
- `set_variable_set_item_glider` — (no arguments)
- `set_variable_set_item_glint_override` — (no arguments)
- `set_variable_set_item_hidden_tooltip` — (no arguments)
- `set_variable_set_item_lore` — (no arguments)
- `set_variable_set_item_lore_line` — (no arguments)
- `set_variable_set_item_max_stack_size` — (no arguments)
- `set_variable_set_item_minimum_attack_charge` — (no arguments)
- `set_variable_set_item_model_data` — (no arguments)
- `set_variable_set_item_name` — (no arguments)
- `set_variable_set_item_piercing_weapon` — (no arguments)
- `set_variable_set_item_placeable_blocks` — (no arguments)
- `set_variable_set_item_rarity` — (no arguments)
- `set_variable_set_item_swing_animation` — (no arguments)
- `set_variable_set_item_tooltip_style` — (no arguments)
- `set_variable_set_item_type` — (no arguments)
- `set_variable_set_item_unbreakable` — (no arguments)
- `set_variable_set_item_use_effects` — (no arguments)
- `set_variable_set_item_use_remainder` — (no arguments)
- `set_variable_set_item_visibility_flags` — (no arguments)
- `set_variable_set_item_weapon` — (no arguments)
- `set_variable_set_list_value` — (no arguments)
- `set_variable_set_location_direction` — (no arguments)
- `set_variable_set_map_value` — (no arguments)
- `set_variable_set_particle_amount` — (no arguments)
- `set_variable_set_particle_color` — (no arguments)
- `set_variable_set_particle_material` — (no arguments)
- `set_variable_set_particle_offset` — (no arguments)
- `set_variable_set_particle_size` — (no arguments)
- `set_variable_set_particle_spread` — (no arguments)
- `set_variable_set_particle_type` — (no arguments)
- `set_variable_set_potion_effect_amplifier` — (no arguments)
- `set_variable_set_potion_effect_duration` — (no arguments)
- `set_variable_set_potion_effect_type` — (no arguments)
- `set_variable_set_sound_pitch` — (no arguments)
- `set_variable_set_sound_source` — (no arguments)
- `set_variable_set_sound_type` — (no arguments)
- `set_variable_set_sound_variation` — (no arguments)
- `set_variable_set_sound_volume_action` — (no arguments)
- `set_variable_set_template_code` — (no arguments)
- `set_variable_set_texture_to_map` — (no arguments)
- `set_variable_set_vector_component` — (no arguments)
- `set_variable_set_vector_length` — (no arguments)
- `set_variable_shift_all_coordinates` — (no arguments)
- `set_variable_shift_coordinate` — (no arguments)
- `set_variable_shift_location_in_direction` — (no arguments)
- `set_variable_shift_location_on_vector` — (no arguments)
- `set_variable_shift_location_towards_location` — (no arguments)
- `set_variable_simplex_noise_3d` — (no arguments)
- `set_variable_sine` — (no arguments)
- `set_variable_sort_any_list` — (no arguments)
- `set_variable_sort_any_map` — (no arguments)
- `set_variable_split_text` — (no arguments)
- `set_variable_split_text_by_length` — (no arguments)
- `set_variable_strip_text` — (no arguments)
- `set_variable_subtract` — (no arguments)
- `set_variable_subtract_vectors` — (no arguments)
- `set_variable_tangent` — (no arguments)
- `set_variable_text` — (no arguments)
- `set_variable_text_case` — (no arguments)
- `set_variable_text_length` — (no arguments)
- `set_variable_text_to_bytes` — (no arguments)
- `set_variable_text_to_chars` — (no arguments)
- `set_variable_to_char` — (no arguments)
- `set_variable_to_hsb` — (no arguments)
- `set_variable_to_hsl` — (no arguments)
- `set_variable_to_json` — (no arguments)
- `set_variable_to_rgb` — (no arguments)
- `set_variable_trim_list` — (no arguments)
- `set_variable_trim_text` — (no arguments)
- `set_variable_unset_item_components` — (no arguments)
- `set_variable_value` — (no arguments)
- `set_variable_vector` — (no arguments)
- `set_variable_vector_cross_product` — (no arguments)
- `set_variable_vector_dot_product` — (no arguments)
- `set_variable_vector_to_direction_name` — (no arguments)
- `set_variable_voronoi_noise_3d` — (no arguments)
- `set_variable_warp` — (no arguments)
