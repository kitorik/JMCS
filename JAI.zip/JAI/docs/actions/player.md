# Player actions
> **Enum macros:** {TF} = TRUE / FALSE; {TFN} = TRUE / FALSE / NOT_SET; {ANY_ALL} = ANY / ALL; {ITEM_MATCH} = EXACT / IGNORE_NAME_DURABILITY / IGNORE_NAME_DURABILITY_ENCHANTMENTS / CUSTOM_TAGS_CONTAINS / MINECRAFT_TAG / ITEM_TYPE; {DEG_RAD} = DEGREES / RADIANS; {CMP} = EXACTLY / IGNORE_STACK_SIZE / IGNORE_DURABILITY_AND_STACK_SIZE / TYPE_ONLY. Icon column omitted.


|  ID  |  Name  |  Description  |  Category/Subcategory  |  Arguments  |  Works with  |  Additional info  |  Status  |
|  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |
|  if_player_chat_colors_enabled  |  Has chat colors  |  Checks whether the "Chat colors" setting is enabled for the player.  |  if_player/toggleable  |    |    |    |    |
|  if_player_chat_message_equals  |  Message equals  |  Checks whether the player message equals the chosen one.  |  if_player/misc  |  chat_messages: text<br/>ignore_case: enum<br/>{TF}  |    |    |    |
|  if_player_collides_at_location  |  Collides at location  |  Checks whether the player collides with blocks, shulkers, boats and the world border at the given location.  |  if_player/location  |  location: location  |    |    |    |
|  if_player_collides_using_hitbox  |  Collides using a custom hitbox  |  Checks whether the player collides with blocks, shulkers, boats and the world border using a custom hitbox.  |  if_player/location  |  min: location<br/>max: location  |    |    |    |
|  if_player_collides_with_entity  |  Collides with entity  |  Checks whether the player hitbox collides with the given entity hitbox.  |  if_player/location  |  name_or_uuid: text<br/>check_type: enum<br/>&nbsp;&nbsp;- OVERLAPS<br/>&nbsp;&nbsp;- CONTAINS  |    |    |    |
|  if_player_cursor_item_equals  |  Cursor item equals  |  Checks whether the item on the player cursor equals the chosen item.  |  if_player/item  |  items: item<br/>comparison_mode: enum<br/>{CMP}  |    |    |    |
|  if_player_gamemode_equals  |  Game mode equals  |  Checks whether the player game mode equals the chosen one.  |  if_player/misc  |  gamemode: enum<br/>&nbsp;&nbsp;- SURVIVAL<br/>&nbsp;&nbsp;- CREATIVE<br/>&nbsp;&nbsp;- ADVENTURE<br/>&nbsp;&nbsp;- SPECTATOR  |    |    |    |
|  if_player_has_custom_recipe_discovered  |  Has displayed custom recipe  |  Checks whether the player has a displayed custom recipe in the recipe book.  |  if_player/misc  |  names: text<br/>is_vanilla_recipe: enum<br/>{TF}<br/>compare_type: enum<br/>{ANY_ALL}  |    |    |    |
|  if_player_has_input  |  Movement key pressed  |  Checks whether the chosen movement key is pressed for the player.  |  if_player/misc  |  input_type: enum<br/>&nbsp;&nbsp;- FORWARD<br/>&nbsp;&nbsp;- BACKWARDS<br/>&nbsp;&nbsp;- LEFT<br/>&nbsp;&nbsp;- RIGHT<br/>&nbsp;&nbsp;- JUMP<br/>&nbsp;&nbsp;- SNEAK<br/>&nbsp;&nbsp;- SPRINT  |    |    |    |
|  if_player_has_item  |  Has item  |  Checks whether the player has an item in their inventory.  |  if_player/item  |  items: item<br/>check_mode: enum<br/>{ANY_ALL}<br/>comparison_mode: enum<br/>{CMP}  |    |    |    |
|  if_player_has_item_at_least  |  Has item in amount  |  Checks whether the player has an item in the given amount.  |  if_player/item  |  item: item<br/>count: number<br/>comparison_mode: enum<br/>&nbsp;&nbsp;- EXACTLY<br/>&nbsp;&nbsp;- TYPE_ONLY  |    |    |    |
|  if_player_has_item_in_slot  |  Has item in slot  |  Checks whether the player has an item in the given inventory slot.  |  if_player/item  |  items: item<br/>slots: number<br/>comparison_mode: enum<br/>{CMP}  |    |    |    |
|  if_player_has_potion_effect  |  Has potion effect  |  Checks whether the player has a potion effect.  |  if_player/misc  |  potions: potion<br/>check_mode: enum<br/>{ANY_ALL}  |    |    |    |
|  if_player_has_privilege  |  Has permissions  |  Checks whether the player has the given world permissions.  |  if_player/misc  |  privilege: enum<br/>&nbsp;&nbsp;- BUILDER<br/>&nbsp;&nbsp;- DEVELOPER<br/>&nbsp;&nbsp;- BUILDER_AND_DEVELOPER<br/>&nbsp;&nbsp;- WHITELISTED<br/>&nbsp;&nbsp;- OWNER<br/>exact: enum<br/>{TF}  |    |  With the "Strict check" marker enabled, build and develop permissions are checked even if the player is a world operator.  |    |
|  if_player_has_room_for_item  |  Has room for items  |  Checks whether the player has inventory room for one or more items.  |  if_player/item  |  items: item<br/>check_mode: enum<br/>{ANY_ALL}<br/>checked_slots: enum<br/>&nbsp;&nbsp;- ENTIRE_INVENTORY<br/>&nbsp;&nbsp;- MAIN_INVENTORY<br/>&nbsp;&nbsp;- UPPER_INVENTORY<br/>&nbsp;&nbsp;- HOTBAR<br/>&nbsp;&nbsp;- ARMOR  |    |    |    |
|  if_player_hotbar_slot_equals  |  Hotbar slot equals  |  Checks whether the current player hotbar slot matches a slot from 1 to 9 in the chest.  |  if_player/misc  |  slot: number  |    |    |    |
|  if_player_in_area  |  Inside region  |  Checks whether the player is inside the given region.  |  if_player/location  |  location_1: location<br/>location_2: location<br/>ignore_y_axis: enum<br/>{TF}<br/>intersect_type: enum<br/>&nbsp;&nbsp;- POINT<br/>&nbsp;&nbsp;- HITBOX<br/>check_type: enum<br/>&nbsp;&nbsp;- OVERLAPS<br/>&nbsp;&nbsp;- CONTAINS  |    |    |    |
|  if_player_inventory_menu_slot_equals  |  Inventory slot contains  |  Checks whether the player with the open inventory currently holds the given item in a slot.  |  if_player/item  |  items: item<br/>slots: number<br/>comparison_mode: enum<br/>{CMP}  |    |    |    |
|  if_player_inventory_type_open  |  Inventory of type open  |  Checks whether an inventory of the given type is open for the player.  |  if_player/misc  |  inventory_type: enum<br/>&nbsp;&nbsp;- CHEST<br/>&nbsp;&nbsp;- DISPENSER<br/>&nbsp;&nbsp;- DROPPER<br/>&nbsp;&nbsp;- FURNACE<br/>&nbsp;&nbsp;- WORKBENCH<br/>&nbsp;&nbsp;- CRAFTING<br/>&nbsp;&nbsp;- ENCHANTING<br/>&nbsp;&nbsp;- BREWING<br/>&nbsp;&nbsp;- PLAYER<br/>&nbsp;&nbsp;- CREATIVE<br/>&nbsp;&nbsp;- MERCHANT<br/>&nbsp;&nbsp;- ENDER_CHEST<br/>&nbsp;&nbsp;- ANVIL<br/>&nbsp;&nbsp;- SMITHING<br/>&nbsp;&nbsp;- BEACON<br/>&nbsp;&nbsp;- HOPPER<br/>&nbsp;&nbsp;- SHULKER_BOX<br/>&nbsp;&nbsp;- BARREL<br/>&nbsp;&nbsp;- BLAST_FURNACE<br/>&nbsp;&nbsp;- LECTERN<br/>&nbsp;&nbsp;- SMOKER<br/>&nbsp;&nbsp;- LOOM<br/>&nbsp;&nbsp;- CARTOGRAPHY<br/>&nbsp;&nbsp;- GRINDSTONE<br/>&nbsp;&nbsp;- STONECUTTER<br/>&nbsp;&nbsp;- COMPOSTER<br/>&nbsp;&nbsp;- CHISELED_BOOKSHELF<br/>&nbsp;&nbsp;- JUKEBOX<br/>&nbsp;&nbsp;- SMITHING_NEW<br/>&nbsp;&nbsp;- DECORATED_POT<br/>&nbsp;&nbsp;- CRAFTER<br/>&nbsp;&nbsp;- SHELF  |    |    |    |
|  if_player_is_allow_server_listing  |  Shown in server player list  |  Checks whether the "Show in lists" setting is enabled for the player.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_blocking  |  Using shield  |  Checks whether the player is using a shield.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_disguised  |  Disguised for everyone  |  Checks whether the player is disguised for other players.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_flying  |  Flying  |  Checks whether the player is flying.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_gliding  |  Gliding  |  Checks whether the player is gliding on elytra.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_holding  |  Holding item  |  Checks whether the player is holding an item.  |  if_player/item  |  items: item<br/>hand_slot: enum<br/>&nbsp;&nbsp;- EITHER_HAND<br/>&nbsp;&nbsp;- MAIN_HAND<br/>&nbsp;&nbsp;- OFF_HAND<br/>comparison_mode: enum<br/>{CMP}  |    |    |    |
|  if_player_is_looking_at_block  |  Looking at block  |  Checks whether the player is looking at the given block or location.  |  if_player/location  |  blocks: block<br/>locations: location<br/>distance: number<br/>fluid_mode: enum<br/>&nbsp;&nbsp;- NEVER<br/>&nbsp;&nbsp;- SOURCE_ONLY<br/>&nbsp;&nbsp;- ALWAYS  |    |    |    |
|  if_player_is_near  |  Near location  |  Checks whether the player is near the given location (default: 5 blocks).  |  if_player/location  |  ignore_y_axis: enum<br/>{TF}<br/>location: location<br/>range: number  |    |    |    |
|  if_player_is_on_ground  |  Standing on ground  |  Checks whether the player is on the ground.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_online_mode  |  Has premium account  |  Checks whether the player has a premium account.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_riding_entity  |  Riding entity  |  Checks whether the player is riding an entity (including vehicles).  |  if_player/misc  |  entity_ids: text<br/>compare_mode: enum<br/>&nbsp;&nbsp;- TYPE<br/>&nbsp;&nbsp;- NAME_OR_UUID  |    |    |    |
|  if_player_is_self_disguised  |  Disguised for self  |  Checks whether the player is disguised for themselves.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_sleeping  |  Sleeping  |  Checks whether the player is sleeping.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_sneaking  |  Sneaking  |  Checks whether the player is sneaking.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_sprinting  |  Sprinting  |  Checks whether the player is sprinting or using the sprint key while swimming.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_standing_on_block  |  Standing on block  |  Checks whether the player is standing on the given block or location.  |  if_player/location  |  blocks: block<br/>locations: location<br/>only_solid: enum<br/>{TF}  |    |    |    |
|  if_player_is_swimming  |  Swimming  |  Checks whether the player is swimming in water or lava.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_transferred  |  Player moved to server  |  Checks whether the player was moved from another server.  |  if_player/toggleable  |    |    |    |    |
|  if_player_is_using_item  |  Using item  |  Checks whether the player is using a bow, shield or any other usable item.  |  if_player/item  |  items: item<br/>comparison_mode: enum<br/>{CMP}  |    |    |    |
|  if_player_is_wearing_item  |  Wearing item  |  Checks whether the player is wearing an item.  |  if_player/item  |  items: item<br/>check_mode: enum<br/>{ANY_ALL}<br/>comparison_mode: enum<br/>{CMP}  |    |    |    |
|  if_player_item_group_is_not_on_cooldown  |  Item group has no cooldown  |  Checks whether the player item group has no cooldown applicable to the given item type.  |  if_player/item  |  item_keys: text<br/>check_mode: enum<br/>{ANY_ALL}  |    |    |    |
|  if_player_item_is_not_on_cooldown  |  Item has no cooldown  |  Checks whether the player item has no cooldown applicable to the given item type.  |  if_player/item  |  items: item<br/>check_mode: enum<br/>{ANY_ALL}  |    |    |    |
|  if_player_name_equals  |  Name equals  |  Checks whether the player name equals the name in the chest.  |  if_player/misc  |  names_or_uuids: text  |    |    |    |
|  if_player_text_filtering_enabled  |  Has word filter  |  Checks whether the Mojang word filter is enabled for the player.  |  if_player/toggleable  |    |    |    |    |
|  player_add_inventory_menu_row  |  Add menu row  |  Adds a row with the given items to a "Chest" type inventory.  |  player/inventory_menus  |  items: item<br/>position: enum<br/>&nbsp;&nbsp;- TOP<br/>&nbsp;&nbsp;- BUTTON  |    |    |    |
|  player_allow_placing_breaking_blocks  |  creative_plus.action.player_allow_placing_breaking_blocks.name  |  creative_plus.action.player_allow_placing_breaking_blocks.description  |  player/settings  |  allow: enum<br/>{TF}<br/>blocks: block  |    |    |  unused  |
|  player_boost_elytra  |  Speed up elytra flight  |  Boosts the player elytra flight with the given firework power.  |  player/movement  |  firework: item  |    |    |    |
|  player_clear_active_item  |  Interrupt item use  |  Interrupts the use of the current item.  |  player/item_management  |    |    |    |    |
|  player_clear_chat  |  Clear chat  |  Removes all messages from the chosen players chat window.  |  player/communication  |    |    |    |    |
|  player_clear_debug_markers  |  Remove debug markers  |  Removes all debug markers for the player.  |  player/world  |    |    |    |    |
|  player_clear_ender_chest_contents  |  Clear ender chest  |  Clears items in the player ender chest.  |  player/item_management  |    |    |    |    |
|  player_clear_inventory  |  Clear inventory  |  Clears the player inventory.  |  player/item_management  |  clear_mode: enum<br/>&nbsp;&nbsp;- ENTIRE<br/>&nbsp;&nbsp;- MAIN<br/>&nbsp;&nbsp;- UPPER<br/>&nbsp;&nbsp;- HOTBAR<br/>&nbsp;&nbsp;- ARMOR  |    |    |    |
|  player_clear_items  |  Clear items  |  Removes all chosen items from the player inventory.  |  player/item_management  |  items: item  |    |    |    |
|  player_clear_potion_effects  |  Clear effects  |  Clears all effects from the player.  |  player/parameters  |    |    |    |    |
|  player_close_dialog_menu  |  Close dialog  |  Closes the player current dialog.  |  player/communication  |    |    |    |    |
|  player_close_inventory  |  Close menu  |  Closes the player open inventory menu.  |  player/inventory_menus  |    |    |    |    |
|  player_complete_using_active_item  |  Finish using item  |  Finishes using the current item in hand with a result.  |  player/item_management  |    |    |    |    |
|  player_connect_to_server  |  Send player to another server  |  Sends the player to the server with the given name (e.g. "cr-0").  |  player/miscellaneous  |  server_name: text  |    |    |    |
|  player_damage  |  Deal damage  |  Deals damage to the player.  |  player/parameters  |  damage: number<br/>source: text  |    |    |    |
|  player_disguise_as_block  |  Disguise player as block  |  Disguises the player as the chosen block.  |  player/appearance  |  block: block<br/>visible_to_self: enum<br/>{TF}  |    |    |    |
|  player_disguise_as_entity  |  Disguise player as entity  |  Disguises the player as the chosen entity.  |  player/appearance  |  entity_type: item<br/>visible_to_self: enum<br/>{TF}  |    |    |    |
|  player_disguise_as_item  |  Disguise player as item  |  Disguises the player as an item.  |  player/appearance  |  item: item<br/>visible_to_self: enum<br/>{TF}  |    |    |    |
|  player_display_bell_ring  |  Play bell ring  |  Plays the bell ring animation to the player without affecting others.  |  player/world  |  location: location<br/>direction: enum<br/>&nbsp;&nbsp;- DOWN<br/>&nbsp;&nbsp;- NORTH<br/>&nbsp;&nbsp;- SOUTH<br/>&nbsp;&nbsp;- WEST<br/>&nbsp;&nbsp;- EAST  |  Bells  |  The "Down" direction stops the ring animation.  |    |
|  player_display_block  |  Show block  |  Show a block to the player without affecting others.  |  player/world  |  location: location<br/>block: block  |    |    |    |
|  player_display_end_gateway_beam  |  Play End gate beam animation  |  Plays the End gate beam animation at the given location.  |  player/world  |  location: location<br/>color: enum<br/>&nbsp;&nbsp;- LIGHT_PURPLE<br/>&nbsp;&nbsp;- DARK_PURPLE  |    |    |    |
|  player_display_hologram  |  Show hologram  |  Shows a hologram to the player. Leave the text empty to remove the hologram at a location.  |  player/world  |  location: location<br/>text: text  |    |  To wrap text onto a new line use "\n", e.g. "Line1\nLine2".  |    |
|  player_display_lightning  |  Display lightning effect  |  Display lightning to the player without showing it to others or igniting the terrain.  |  player/particle  |  location: location  |    |    |    |
|  player_display_particle  |  Display particle effect  |  Displays a particle effect to the player at the chosen location.  |  player/particle  |  particle: particle<br/>location: location  |    |    |    |
|  player_display_particle_circle  |  Display particle circle  |  Displays a particle circle to the player with the given parameters.  |  player/particle  |  particle: particle<br/>center: location<br/>radius: number<br/>points: number<br/>start_angle: number<br/>perpendicular: vector<br/>angle_unit: enum<br/>{DEG_RAD}  |    |    |    |
|  player_display_particle_cube  |  Display particle cube  |  Displays a particle cube to the player with the given parameters.  |  player/particle  |  particle: particle<br/>first_corner: location<br/>second_corner: location<br/>spacing: number<br/>type: enum<br/>&nbsp;&nbsp;- SOLID<br/>&nbsp;&nbsp;- HOLLOW<br/>&nbsp;&nbsp;- WIREFRAME  |    |    |    |
|  player_display_particle_line  |  Display particle line  |  Displays a particle line to the player from start to end location with a given step.  |  player/particle  |  particle: particle<br/>start: location<br/>end: location<br/>divider: number<br/>unit_of_measurement: enum<br/>&nbsp;&nbsp;- POINTS<br/>&nbsp;&nbsp;- DISTANCE  |    |    |    |
|  player_display_particle_ray  |  Display particle beam  |  Displays a particle beam to the player from the start location along the given vector with a given step.  |  player/particle  |  particle: particle<br/>start: location<br/>ray: vector<br/>divider: number<br/>unit_of_measurement: enum<br/>&nbsp;&nbsp;- POINTS<br/>&nbsp;&nbsp;- DISTANCE  |    |    |    |
|  player_display_particle_sphere  |  Display particle sphere  |  Displays a particle sphere to the player with the given parameters.  |  player/particle  |  particle: particle<br/>center: location<br/>radius: number<br/>points: number  |    |    |    |
|  player_display_particle_spiral  |  Display particle spiral  |  Displays a particle spiral to the player with the given parameters.  |  player/particle  |  particle: particle<br/>center: location<br/>distance: number<br/>radius: number<br/>points: number<br/>rotations: number<br/>start_angle: number<br/>angle_unit: enum<br/>{DEG_RAD}  |    |    |    |
|  player_display_pick_up_animation  |  Play item pickup animation  |  Plays the item pickup animation to the player.  |  player/world  |  collected_name_or_uuid: text<br/>collector_name_or_uuid: text<br/>amount: number  |    |  Works with any entity, including players.  |    |
|  player_display_sign_text  |  Show sign text  |  Show a sign text change to the player without changing it for others.  |  player/world  |  location: location<br/>line_1: text<br/>line_2: text<br/>line_3: text<br/>line_4: text<br/>side: enum<br/>&nbsp;&nbsp;- FRONT<br/>&nbsp;&nbsp;- BACK<br/>&nbsp;&nbsp;- ALL  |    |    |    |
|  player_display_vibration  |  Display vibration particle  |  Displays a vibration particle to the player moving from one point to another.  |  player/particle  |  from: location<br/>to: location<br/>destination_time: number  |    |    |    |
|  player_expand_inventory_menu  |  Expand menu  |  Expands the player open inventory menu by the chosen number of rows and fills it with the given items.  |  player/inventory_menus  |  items: item<br/>size: number  |    |    |    |
|  player_face_location  |  Rotate to location  |  Rotates the player towards a location.  |  player/movement  |  location: location  |    |    |    |
|  player_get_attribute  |  Get player attribute value  |  Gets the given player attribute value and assigns the result to a variable.  |  player/parameters  |  variable: variable<br/>attribute_type: enum<br/>&nbsp;&nbsp;- GENERIC_MAX_HEALTH<br/>&nbsp;&nbsp;- GENERIC_MAX_ABSORPTION<br/>&nbsp;&nbsp;- GENERIC_FOLLOW_RANGE<br/>&nbsp;&nbsp;- GENERIC_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_SPEED<br/>&nbsp;&nbsp;- GENERIC_FLYING_SPEED<br/>&nbsp;&nbsp;- GENERIC_ATTACK_DAMAGE<br/>&nbsp;&nbsp;- GENERIC_ATTACK_KNOCKBACK<br/>&nbsp;&nbsp;- GENERIC_ATTACK_SPEED<br/>&nbsp;&nbsp;- GENERIC_ARMOR<br/>&nbsp;&nbsp;- GENERIC_ARMOR_TOUGHNESS<br/>&nbsp;&nbsp;- GENERIC_LUCK<br/>&nbsp;&nbsp;- GENERIC_JUMP_STRENGTH<br/>&nbsp;&nbsp;- ZOMBIE_SPAWN_REINFORCEMENTS<br/>&nbsp;&nbsp;- GENERIC_FALL_DAMAGE_MULTIPLIER<br/>&nbsp;&nbsp;- GENERIC_SAFE_FALL_DISTANCE<br/>&nbsp;&nbsp;- GENERIC_SCALE<br/>&nbsp;&nbsp;- GENERIC_STEP_HEIGHT<br/>&nbsp;&nbsp;- GENERIC_GRAVITY<br/>&nbsp;&nbsp;- PLAYER_BLOCK_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_ENTITY_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_BLOCK_BREAK_SPEED<br/>&nbsp;&nbsp;- GENERIC_BURNING_TIME<br/>&nbsp;&nbsp;- GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- GENERIC_OXYGEN_BONUS<br/>&nbsp;&nbsp;- GENERIC_WATER_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_MINING_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_SNEAKING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SUBMERGED_MINING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SWEEPING_DAMAGE_RATIO<br/>&nbsp;&nbsp;- TEMP_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_TRANSMIT_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_RECEIVE_RANGE<br/>&nbsp;&nbsp;- CAMERA_DISTANCE<br/>&nbsp;&nbsp;- BOUNCINESS<br/>&nbsp;&nbsp;- FRICTION_MODIFIER<br/>&nbsp;&nbsp;- AIR_DRAG_MODIFIER<br/>&nbsp;&nbsp;- NAME_TAG_DISTANCE<br/>&nbsp;&nbsp;- BELOW_NAME_DISTANCE<br/>return_value: enum<br/>&nbsp;&nbsp;- VALUE<br/>&nbsp;&nbsp;- BASE_VALUE<br/>&nbsp;&nbsp;- DEFAULT_VALUE  |    |    |    |
|  player_get_nbt  |  Get player NBT tags  |  Gets player NBT tags by the given path and assigns the result to a variable.  |  player/miscellaneous  |  variable: variable<br/>path: text<br/>value_type: enum<br/>&nbsp;&nbsp;- ANY_VALUE<br/>&nbsp;&nbsp;- NBT_STRING  |    |    |    |
|  player_give_experience  |  Add level  |  Adds a level to the player.  |  player/parameters  |  experience: number<br/>mode: enum<br/>&nbsp;&nbsp;- POINTS<br/>&nbsp;&nbsp;- LEVEL<br/>&nbsp;&nbsp;- LEVEL_PERCENTAGE  |    |    |    |
|  player_give_items  |  Give item  |  Gives chest items to the player.  |  player/item_management  |  items: item<br/>amount: number  |    |    |    |
|  player_give_potion_effect  |  Grant effect  |  Grants the chosen effects to the player.  |  player/parameters  |  potions: potion<br/>overwrite: enum<br/>{TF}<br/>show_icon: enum<br/>{TF}<br/>particle_mode: enum<br/>&nbsp;&nbsp;- REGULAR<br/>&nbsp;&nbsp;- AMBIENT<br/>&nbsp;&nbsp;- NONE  |    |    |    |
|  player_give_random_item  |  Give random item  |  Gives the player a random item or stack of chest items.  |  player/item_management  |  items: item  |    |    |    |
|  player_heal  |  Heal player  |  Heals the player.  |  player/parameters  |  heal: number  |    |    |    |
|  player_hide_custom_recipe  |  Hide custom recipe  |  Hides a recipe from the player.  |  player/miscellaneous  |  names: text<br/>is_vanilla_recipe: enum<br/>{TF}  |    |    |    |
|  player_hide_entity  |  Hide entity from player  |  Hides the given entity from the player.  |  player/world  |  name_or_uuid: text<br/>hide: enum<br/>{TF}  |    |    |    |
|  player_hide_scoreboard  |  Hide scoreboard  |  Hides the player current scoreboard.  |  player/miscellaneous  |    |    |    |    |
|  player_kick  |  Kick player  |  Kicks the player from the world.  |  player/miscellaneous  |    |    |    |    |
|  player_launch_forward  |  Launch forward  |  Launches the player forward or backward along their look direction depending on power.  |  player/movement  |  power: number<br/>increment: enum<br/>{TF}<br/>launch_axis: enum<br/>&nbsp;&nbsp;- YAW_AND_PITCH<br/>&nbsp;&nbsp;- YAW  |    |    |    |
|  player_launch_projectile  |  Launch projectile  |  Launch a projectile from the player location.  |  player/world  |  projectile: item<br/>location: location<br/>name: text<br/>speed: number<br/>inaccuracy: number<br/>trail: particle  |    |    |    |
|  player_launch_to_location  |  Launch to location  |  Launches the player towards the chosen location.  |  player/movement  |  location: location<br/>power: number<br/>increment: enum<br/>{TF}  |    |    |    |
|  player_launch_up  |  Toss up  |  Tosses the player up or down depending on power.  |  player/movement  |  power: number<br/>increment: enum<br/>{TF}  |    |    |    |
|  player_leave_vehicle  |  Eject from vehicle  |  Ejects the player from a vehicle or entity.  |  player/movement  |    |    |    |    |
|  player_load_inventory  |  Load saved inventory  |  Loads the chosen saved inventory.  |  player/item_management  |    |    |    |    |
|  player_mimic_disguise_from_entity  |  Disguise player as a world entity  |  Disguises the player as the given world entity.  |  player/appearance  |  name_or_uuid: text<br/>include_disguise: enum<br/>{TF}<br/>disguise: enum<br/>&nbsp;&nbsp;- ALL<br/>&nbsp;&nbsp;- EVERYONE_BUT_NOT_SELF<br/>&nbsp;&nbsp;- ONLY_SELF<br/>remove_original_entity: enum<br/>{TF}  |    |    |    |
|  player_open_book  |  Open book  |  Opens a book for the given player.  |  player/communication  |  book: item  |    |    |    |
|  player_open_container_inventory  |  Open block menu  |  Opens the block menu at the given location for the player.  |  player/inventory_menus  |  location: location  |    |    |    |
|  player_open_ender_chest  |  Open ender chest  |  Opens the ender chest for the player.  |  player/inventory_menus  |    |    |    |    |
|  player_open_working_menu  |  Open functional menu  |  Opens a functional menu for the player.  |  player/inventory_menus  |  title: text<br/>menu_type: enum<br/>&nbsp;&nbsp;- CRAFTING<br/>&nbsp;&nbsp;- ANVIL<br/>&nbsp;&nbsp;- SMITHING<br/>&nbsp;&nbsp;- CARTOGRAPHY_TABLE<br/>&nbsp;&nbsp;- LOOM<br/>&nbsp;&nbsp;- GRINDSTONE<br/>&nbsp;&nbsp;- STONECUTTER<br/>&nbsp;&nbsp;- ENCHANTMENT  |    |    |    |
|  player_play_animation_action  |  Play animation to player  |  Plays the given animation to the player.  |  player/appearance  |  animation: enum<br/>&nbsp;&nbsp;- DAMAGE<br/>&nbsp;&nbsp;- WAKE_UP<br/>&nbsp;&nbsp;- TOTEM<br/>&nbsp;&nbsp;- JUMPSCARE  |    |    |    |
|  player_play_hurt_animation  |  Play damage receiving animation  |  Plays the damage receiving animation to the player with a given tilt.  |  player/appearance  |  yaw: number  |    |    |    |
|  player_play_sound  |  Play sound  |  Plays a sound to the player.  |  player/communication  |  sound: sound<br/>location: location  |    |    |    |
|  player_play_sound_from_entity  |  Play sound from entity  |  Plays a sound to the player from the given entity.  |  player/communication  |  sounds: sound<br/>name_or_uuid: text  |    |  Stereo sounds will not play.  |    |
|  player_play_sound_sequence  |  Play sound sequence  |  Plays a sound sequence to the player with a delay between each sound.  |  player/communication  |  sounds: sound<br/>delay: number<br/>location: location  |    |    |    |
|  player_randomized_teleport  |  Random teleport  |  Teleports the player to a random location.  |  player/movement  |  locations: location<br/>keep_rotation: enum<br/>{TF}<br/>keep_velocity: enum<br/>{TF}<br/>dismount: enum<br/>{TF}  |    |    |    |
|  player_redirect_world  |  Move player to another world  |  Moves the player to the world with the given ID.  |  player/miscellaneous  |  world_id: text  |    |    |    |
|  player_remove_boss_bar  |  Remove boss bar  |  Removes the existing boss bar from the given player.  |  player/communication  |  id: text  |    |    |    |
|  player_remove_disguise  |  Remove disguise  |  Removes the player disguise.  |  player/appearance  |    |    |    |    |
|  player_remove_display_blocks  |  Hide displayed blocks  |  Hides all displayed blocks in the chosen space from the player without affecting others (max space size 500 blocks).  |  player/world  |  pos_1: location<br/>pos_2: location  |    |    |    |
|  player_remove_inventory_menu_row  |  Remove menu rows  |  Removes one or more rows in a "Chest" type inventory.  |  player/inventory_menus  |  size: number<br/>position: enum<br/>&nbsp;&nbsp;- TOP<br/>&nbsp;&nbsp;- BUTTON  |    |    |    |
|  player_remove_items  |  Remove items  |  Removes the given items from the player inventory.  |  player/item_management  |  items: item  |    |    |    |
|  player_remove_pose  |  Reset player pose  |  Resets the player pose.  |  player/appearance  |    |    |    |    |
|  player_remove_potion_effect  |  Remove effect  |  Removes the chosen effects from the player.  |  player/parameters  |  potions: potion  |    |    |    |
|  player_remove_self_disguise  |  Remove own disguise  |  Removes the player disguise visible only to them.  |  player/appearance  |    |    |    |    |
|  player_remove_skin  |  Remove skin  |  Restores the default skin of the event target.  |  player/appearance  |    |    |    |    |
|  player_remove_world_border  |  Reset world border  |  Reset the world border for the player to the default value.  |  player/world  |    |    |    |    |
|  player_replace_items  |  Replace items  |  Replaces the given inventory items with a specific item.  |  player/item_management  |  items: item<br/>replace: item<br/>count: number  |    |    |    |
|  player_reset_waypoint_color  |  Reset locator icon color  |  Resets the player locator icon color to default.  |  player/settings  |    |    |  The game rule "Locator visibility" must be enabled for this action to work.  |    |
|  player_reset_weather  |  Reset weather  |  Resets the weather for the player.  |  player/world  |    |    |    |    |
|  player_ride_entity  |  Mount onto entity  |  Mounts the player onto an entity or another player.  |  player/movement  |  name_or_uuid: text  |    |    |    |
|  player_save_inventory  |  Save current inventory  |  Saves the player current inventory. It can be loaded later with "Load saved inventory".  |  player/item_management  |    |    |    |    |
|  player_self_disguise_as_block  |  Disguise self as block  |  Disguises the player as a block, visible only to that player.  |  player/appearance  |  block: block  |    |    |    |
|  player_self_disguise_as_entity  |  Disguise self as entity  |  Disguises the player as an entity, visible only to that player.  |  player/appearance  |  entity_type: item  |    |    |    |
|  player_self_disguise_as_item  |  Disguise self as item  |  Disguises the player as an item, visible only to that player.  |  player/appearance  |  item: item  |    |    |    |
|  player_send_action_bar  |  Send action bar  |  Shows an action bar to the chosen player.  |  player/communication  |  messages: text<br/>merging: enum<br/>&nbsp;&nbsp;- SPACES<br/>&nbsp;&nbsp;- CONCATENATION  |    |    |    |
|  player_send_advancement  |  Send achievement to player  |  Shows a custom popup achievement to the player.  |  player/communication  |  frame: enum<br/>&nbsp;&nbsp;- TASK<br/>&nbsp;&nbsp;- CHALLENGE<br/>&nbsp;&nbsp;- GOAL<br/>name: text<br/>icon: item  |    |    |    |
|  player_send_break_animation  |  Play block breaking animation  |  Shows the block breaking animation (cracks) to the player without affecting others.  |  player/world  |  locations: location<br/>stage: number  |    |    |    |
|  player_send_dialogue  |  Dialog  |  Sends several chat messages to the chosen players with a delay after each message.  |  player/communication  |  messages: text<br/>delay: number  |    |    |    |
|  player_send_hover  |  Send hover message  |  Sends a message to the chosen player. When the player hovers over it, a second message appears.  |  player/communication  |  message: text<br/>hover: text  |    |    |  unused  |
|  player_send_message  |  Send message  |  Sends a chat message to the given players.  |  player/communication  |  messages: text<br/>merging: enum<br/>&nbsp;&nbsp;- SPACES<br/>&nbsp;&nbsp;- CONCATENATION<br/>&nbsp;&nbsp;- SEPARATE_LINES  |    |    |    |
|  player_send_minimessage  |  Send MiniMessage format message  |  Sends a MiniMessage format chat message to the player.  |  player/communication  |  minimessage: text  |    |    |  unused  |
|  player_send_title  |  Send title  |  Shows two on-screen texts to the chosen player - a title and subtitle.  |  player/communication  |  title: text<br/>subtitle: text<br/>fade_in: number<br/>stay: number<br/>fade_out: number  |    |    |    |
|  player_set_absorption_health  |  Set absorption health  |  Sets the player absorption health.  |  player/parameters  |  health: number  |    |    |    |
|  player_set_air_ticks  |  Set remaining air  |  Sets the player remaining air.  |  player/parameters  |  ticks: number  |    |    |    |
|  player_set_allow_flying  |  Set player flight permission  |  Sets the player flight permission.  |  player/settings  |  allow_flying: enum<br/>{TF}  |    |    |    |
|  player_set_armor  |  Set armor  |  Sets the player armor.  |  player/item_management  |  helmet: item<br/>chestplate: item<br/>leggings: item<br/>boots: item  |    |    |    |
|  player_set_arrows_in_body  |  Set arrows on player  |  Displays the given number of arrows on the player.  |  player/appearance  |  amount: number  |    |    |    |
|  player_set_attack_speed  |  Set attack speed  |  Sets the player attack speed.  |  player/parameters  |  speed: number  |    |    |    |
|  player_set_attribute  |  Set attribute  |  Sets the given attribute value for the player.  |  player/parameters  |  value: number<br/>attribute_type: enum<br/>&nbsp;&nbsp;- GENERIC_MAX_HEALTH<br/>&nbsp;&nbsp;- GENERIC_MAX_ABSORPTION<br/>&nbsp;&nbsp;- GENERIC_FOLLOW_RANGE<br/>&nbsp;&nbsp;- GENERIC_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_SPEED<br/>&nbsp;&nbsp;- GENERIC_FLYING_SPEED<br/>&nbsp;&nbsp;- GENERIC_ATTACK_DAMAGE<br/>&nbsp;&nbsp;- GENERIC_ATTACK_KNOCKBACK<br/>&nbsp;&nbsp;- GENERIC_ATTACK_SPEED<br/>&nbsp;&nbsp;- GENERIC_ARMOR<br/>&nbsp;&nbsp;- GENERIC_ARMOR_TOUGHNESS<br/>&nbsp;&nbsp;- GENERIC_LUCK<br/>&nbsp;&nbsp;- GENERIC_JUMP_STRENGTH<br/>&nbsp;&nbsp;- ZOMBIE_SPAWN_REINFORCEMENTS<br/>&nbsp;&nbsp;- GENERIC_FALL_DAMAGE_MULTIPLIER<br/>&nbsp;&nbsp;- GENERIC_SAFE_FALL_DISTANCE<br/>&nbsp;&nbsp;- GENERIC_SCALE<br/>&nbsp;&nbsp;- GENERIC_STEP_HEIGHT<br/>&nbsp;&nbsp;- GENERIC_GRAVITY<br/>&nbsp;&nbsp;- PLAYER_BLOCK_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_ENTITY_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_BLOCK_BREAK_SPEED<br/>&nbsp;&nbsp;- GENERIC_BURNING_TIME<br/>&nbsp;&nbsp;- GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- GENERIC_OXYGEN_BONUS<br/>&nbsp;&nbsp;- GENERIC_WATER_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_MINING_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_SNEAKING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SUBMERGED_MINING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SWEEPING_DAMAGE_RATIO<br/>&nbsp;&nbsp;- TEMP_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_TRANSMIT_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_RECEIVE_RANGE<br/>&nbsp;&nbsp;- CAMERA_DISTANCE<br/>&nbsp;&nbsp;- BOUNCINESS<br/>&nbsp;&nbsp;- FRICTION_MODIFIER<br/>&nbsp;&nbsp;- AIR_DRAG_MODIFIER<br/>&nbsp;&nbsp;- NAME_TAG_DISTANCE<br/>&nbsp;&nbsp;- BELOW_NAME_DISTANCE  |    |    |    |
|  player_set_bee_stingers_in_body  |  Set bee stinger on player  |  Displays the given number of bee stingers on the player.  |  player/appearance  |  amount: number  |    |    |    |
|  player_set_block_opened_state  |  Open/Close block  |  Show a block open/close to the player without changing the block state for others.  |  player/world  |  location: location<br/>is_opened: enum<br/>{TF}  |  Chests<br/>Trapped chests<br/>Ender chests<br/>Shulker boxes<br/>Barrels  |    |    |
|  player_set_boss_bar  |  Set boss bar  |  Sets a custom boss bar for the given player.  |  player/communication  |  id: text<br/>title: text<br/>progress: number<br/>color: enum<br/>&nbsp;&nbsp;- PINK<br/>&nbsp;&nbsp;- BLUE<br/>&nbsp;&nbsp;- RED<br/>&nbsp;&nbsp;- GREEN<br/>&nbsp;&nbsp;- YELLOW<br/>&nbsp;&nbsp;- PURPLE<br/>&nbsp;&nbsp;- WHITE<br/>style: enum<br/>&nbsp;&nbsp;- PROGRESS<br/>&nbsp;&nbsp;- NOTCHED_6<br/>&nbsp;&nbsp;- NOTCHED_10<br/>&nbsp;&nbsp;- NOTCHED_12<br/>&nbsp;&nbsp;- NOTCHED_20<br/>sky_effect: enum<br/>&nbsp;&nbsp;- NONE<br/>&nbsp;&nbsp;- FOG<br/>&nbsp;&nbsp;- DARK_SKY<br/>&nbsp;&nbsp;- FOG_AND_DARK_SKY  |    |    |    |
|  player_set_chat_completions  |  Chat tooltip update  |  Updates the chat input tooltips shown to the player.  |  player/communication  |  completions: text<br/>setting_mode: enum<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- REMOVE  |    |    |    |
|  player_set_collidable  |  Set collision mode  |  Sets the player collision mode with entities.  |  player/settings  |  collidable: enum<br/>{TF}  |    |    |    |
|  player_set_compass_target  |  Set compass target  |  Set the player compass target the needle points to.  |  player/world  |  location: location  |    |    |    |
|  player_set_cursor_item  |  Set cursor item  |  Sets the item on the player cursor.  |  player/item_management  |  item: item  |    |    |    |
|  player_set_death_drops  |  Set item drops  |  Sets whether items drop from the player on death.  |  player/settings  |  death_drops: enum<br/>{TF}  |    |    |    |
|  player_set_death_screen_score  |  Set score amount  |  Sets the score amount shown on the player death screen.  |  player/parameters  |  score: number  |    |  After setting the value, the score still changes when the player gains experience.  |    |
|  player_set_default_visible  |  Set visibility  |  Sets the player visibility.  |  player/settings  |  default_visible: enum<br/>{TF}  |    |    |    |
|  player_set_enchantment_seed  |  Set enchantment seed  |  Sets the player enchantment seed determining the enchantments in the enchanting table.  |  player/parameters  |  seed: number  |    |    |    |
|  player_set_ender_chest_contents  |  Set ender chest contents  |  Sets items in the player ender chest.  |  player/item_management  |  items: item  |    |    |    |
|  player_set_entity_glowing  |  Set entity glow  |  Toggles the entity glow for this player.  |  player/world  |  name_or_uuid: text<br/>color: enum<br/>&nbsp;&nbsp;- WHITE<br/>&nbsp;&nbsp;- GRAY<br/>&nbsp;&nbsp;- DARK_GRAY<br/>&nbsp;&nbsp;- BLACK<br/>&nbsp;&nbsp;- DARK_RED<br/>&nbsp;&nbsp;- RED<br/>&nbsp;&nbsp;- GOLD<br/>&nbsp;&nbsp;- YELLOW<br/>&nbsp;&nbsp;- GREEN<br/>&nbsp;&nbsp;- DARK_GREEN<br/>&nbsp;&nbsp;- DARK_AQUA<br/>&nbsp;&nbsp;- AQUA<br/>&nbsp;&nbsp;- BLUE<br/>&nbsp;&nbsp;- DARK_BLUE<br/>&nbsp;&nbsp;- DARK_PURPLE<br/>&nbsp;&nbsp;- PURPLE<br/>glow: enum<br/>{TF}  |    |    |    |
|  player_set_equipment  |  Set equipment  |  Sets items in one of the player equipment slots (armor and hand items).  |  player/item_management  |  item: item<br/>slot: enum<br/>&nbsp;&nbsp;- CHEST<br/>&nbsp;&nbsp;- FEET<br/>&nbsp;&nbsp;- HAND<br/>&nbsp;&nbsp;- HEAD<br/>&nbsp;&nbsp;- LEGS<br/>&nbsp;&nbsp;- OFF_HAND<br/>&nbsp;&nbsp;- BODY<br/>&nbsp;&nbsp;- SADDLE  |    |    |    |
|  player_set_exhaustion  |  Set exhaustion level  |  Sets the player exhaustion level.  |  player/parameters  |  exhaustion: number<br/>mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD  |    |    |    |
|  player_set_experience  |  Set level  |  Sets the player level.  |  player/parameters  |  experience: number<br/>mode: enum<br/>&nbsp;&nbsp;- POINTS<br/>&nbsp;&nbsp;- LEVEL<br/>&nbsp;&nbsp;- LEVEL_PERCENTAGE  |    |    |    |
|  player_set_fall_distance  |  Set fall distance  |  Sets the player fall distance.  |  player/parameters  |  distance: number  |    |    |    |
|  player_set_fire_ticks  |  Ignite player  |  Sets the player on fire for the chosen time.  |  player/parameters  |  ticks: number  |    |    |    |
|  player_set_flying  |  Set flying  |  Sets the player flying state.  |  player/movement  |  is_flying: enum<br/>{TF}  |    |    |    |
|  player_set_fog_distance  |  Set render distance  |  Sets the player chunk render distance. Value "-1" resets it to the default.  |  player/world  |  distance: number  |    |    |    |
|  player_set_food  |  Set hunger  |  Sets the player hunger level.  |  player/parameters  |  food: number<br/>mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD  |    |    |    |
|  player_set_freeze_ticks  |  Set freeze time  |  Sets the player freeze time (number of ticks the player spent in powder snow).  |  player/parameters  |  ticks: number<br/>ticking_locked: enum<br/>{TF}  |    |    |    |
|  player_set_gamemode  |  Set game mode  |  Sets the game mode for the player.  |  player/settings  |  gamemode: enum<br/>&nbsp;&nbsp;- SURVIVAL<br/>&nbsp;&nbsp;- CREATIVE<br/>&nbsp;&nbsp;- ADVENTURE<br/>&nbsp;&nbsp;- SPECTATOR<br/>flight_mode: enum<br/>&nbsp;&nbsp;- RESPECT_GAMEMODE<br/>&nbsp;&nbsp;- KEEP_ORIGINAL  |    |    |    |
|  player_set_gliding  |  Set elytra flight  |  Sets the player elytra gliding state.  |  player/movement  |  is_gliding: enum<br/>{TF}  |    |    |    |
|  player_set_health  |  Set player health  |  Sets the player health to the chosen amount.  |  player/parameters  |  health: number  |    |    |    |
|  player_set_hotbar_slot  |  Set slot  |  Sets the chosen slot for the player.  |  player/parameters  |  slot: number  |    |    |    |
|  player_set_instant_respawn  |  Set instant respawn  |  Sets instant respawn for the player.  |  player/settings  |  instant_respawn: enum<br/>{TF}  |    |    |    |
|  player_set_inventory_kept  |  Set keep inventory  |  Sets whether the player keeps the inventory on death.  |  player/settings  |  kept: enum<br/>{TF}  |    |    |    |
|  player_set_inventory_menu_custom_id  |  Set open inventory custom ID  |  Sets a custom ID for the player open menu.  |  player/inventory_menus  |  custom_id: text  |    |    |    |
|  player_set_inventory_menu_item  |  Set item into slot  |  Sets the item into the given slot of the player open inventory menu.  |  player/inventory_menus  |  item: item<br/>slot: number  |    |    |    |
|  player_set_inventory_menu_name  |  Set menu title  |  Sets a new title for the player open inventory menu.  |  player/inventory_menus  |  text: text  |    |    |    |
|  player_set_invulnerability_ticks  |  Set invulnerability duration  |  Sets the invulnerability duration for the player.  |  player/parameters  |  ticks: number  |    |    |    |
|  player_set_item_cooldown  |  Set item cooldown  |  Applies the cooldown bar visual effect for all items of the chosen type.  |  player/item_management  |  item: item<br/>cooldown: number<br/>sound: sound  |    |    |    |
|  player_set_item_group_cooldown  |  Set item group cooldown  |  Applies the cooldown bar visual effect for all items of the given group.  |  player/item_management  |  key: text<br/>cooldown: number  |    |    |    |
|  player_set_items  |  Set items  |  Sets the items from the chest into the player inventory respectively.  |  player/item_management  |  items: item  |    |    |    |
|  player_set_max_health  |  Set player max health  |  Sets the maximum health for the player.  |  player/parameters  |  health: number<br/>heal: enum<br/>{TF}  |    |    |    |
|  player_set_max_invulnerability_ticks  |  Set maximum invulnerability duration  |  Sets the maximum invulnerability duration for the player.  |  player/parameters  |  ticks: number  |    |    |    |
|  player_set_movement_speed  |  Set movement speed  |  Sets the player movement speed.  |  player/parameters  |  distance: number<br/>movement_type: enum<br/>&nbsp;&nbsp;- WALK<br/>&nbsp;&nbsp;- FLY  |    |    |    |
|  player_set_nametag_visible  |  Player name tag display  |  Shows or hides the nametag above the head.  |  player/settings  |  visible: enum<br/>{TF}  |    |    |    |
|  player_set_player_list_info  |  Set text in player list  |  Sets the text above or below the player list for the player.  |  player/communication  |  text: text<br/>position: enum<br/>&nbsp;&nbsp;- HEADER<br/>&nbsp;&nbsp;- FOOTER<br/>merging: enum<br/>&nbsp;&nbsp;- SPACES<br/>&nbsp;&nbsp;- CONCATENATION<br/>&nbsp;&nbsp;- SEPARATE_LINES  |    |    |    |
|  player_set_pose  |  Set player pose  |  Sets the given pose for the player.  |  player/appearance  |  pose: enum<br/>&nbsp;&nbsp;- CROAKING<br/>&nbsp;&nbsp;- CROUCHING<br/>&nbsp;&nbsp;- DIGGING<br/>&nbsp;&nbsp;- DYING<br/>&nbsp;&nbsp;- EMERGING<br/>&nbsp;&nbsp;- FALL_FLYING<br/>&nbsp;&nbsp;- INHALING<br/>&nbsp;&nbsp;- LONG_JUMPING<br/>&nbsp;&nbsp;- ROARING<br/>&nbsp;&nbsp;- SITTING<br/>&nbsp;&nbsp;- SLEEPING<br/>&nbsp;&nbsp;- SNIFFING<br/>&nbsp;&nbsp;- SHOOTING<br/>&nbsp;&nbsp;- SLIDING<br/>&nbsp;&nbsp;- SPIN_ATTACK<br/>&nbsp;&nbsp;- STANDING<br/>&nbsp;&nbsp;- SWIMMING<br/>&nbsp;&nbsp;- USING_TONGUE<br/>locked: enum<br/>{TF}  |    |    |    |
|  player_set_pvp  |  Set allow attacking players  |  Sets whether the player is allowed to attack other players and damage them.  |  player/settings  |  pvp: enum<br/>{TF}  |    |    |    |
|  player_set_rain_level  |  Set rain level  |  Sets the player rain level.  |  player/world  |  rain_level: number  |    |    |    |
|  player_set_rotation  |  Set rotation  |  Rotates the player.  |  player/movement  |  yaw: number<br/>pitch: number  |    |    |    |
|  player_set_rotation_by_vector  |  Set rotation by vector  |  Rotates the player by a vector.  |  player/movement  |  vector: vector  |    |    |    |
|  player_set_saturated_regen_rate  |  Set saturated regeneration rate  |  Sets the player saturated regeneration rate.  |  player/parameters  |  rate: number  |    |  The default value is 10.  |    |
|  player_set_saturation  |  Set saturation  |  Sets the player secondary hunger level (saturation).  |  player/parameters  |  saturation: number<br/>mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD  |    |    |    |
|  player_set_simulation_distance  |  Set simulation distance  |  Sets the player chunk simulation distance.  |  player/world  |  distance: number  |    |    |    |
|  player_set_skin  |  Set skin  |  Sets the given player skin for the event target.  |  player/appearance  |  name_or_uuid: text<br/>server_type: enum<br/>&nbsp;&nbsp;- MOJANG<br/>&nbsp;&nbsp;- SERVER<br/>&nbsp;&nbsp;- SERVER_DEFAULT  |    |    |    |
|  player_set_slot_item  |  Set item into slot  |  Sets the item into a slot in the player inventory.  |  player/item_management  |  item: item<br/>slot: number  |    |    |    |
|  player_set_spawn_point  |  Set respawn location  |  Sets the player new respawn location.  |  player/settings  |  spawn_point: location  |    |    |    |
|  player_set_starvation_rate  |  Set starvation rate  |  Sets the player starvation rate.  |  player/parameters  |  rate: number  |    |  The default value is 80.  |    |
|  player_set_thunder_level  |  Set thunder level  |  Sets the player thunder level.  |  player/world  |  thunder_level: number  |    |  Rainy weather is required to set this.  |    |
|  player_set_tick_rate  |  Set tick rate  |  Sets the player tick rate without affecting other players.  |  player/world  |  tick_rate: number  |    |    |    |
|  player_set_time  |  Set player time  |  Set the time for the player without changing it for other players.  |  player/world  |  time: number  |    |    |    |
|  player_set_unsaturated_regen_rate  |  Set unsaturated regeneration rate  |  Sets the player unsaturated regeneration rate.  |  player/parameters  |  rate: number  |    |  The default value is 80.  |    |
|  player_set_velocity  |  Launch along vector  |  Launches the player along the given vector.  |  player/movement  |  velocity: vector<br/>increment: enum<br/>{TF}  |    |    |    |
|  player_set_visual_fire  |  Set visual fire  |  Sets the player burning effect.  |  player/appearance  |  visual_fire: enum<br/>{TFN}  |    |    |    |
|  player_set_waypoint_color  |  Set locator icon color  |  Sets the color of the icon shown on the locator for the player.  |  player/settings  |  red: number<br/>green: number<br/>blue: number  |    |  The game rule "Locator visibility" must be enabled for this action to work.  |    |
|  player_set_waypoint_style  |  Set locator icon style  |  Sets the style of the icon shown on the locator for the player.  |  player/settings  |  style: text  |    |    |    |
|  player_set_weather  |  Set weather  |  Set the weather for the player without affecting other players.  |  player/world  |  weather_type: enum<br/>&nbsp;&nbsp;- DOWNFALL<br/>&nbsp;&nbsp;- CLEAR  |    |    |    |
|  player_set_world_border  |  Set player world border  |  Set the world border for the player without changing it for other players.  |  player/world  |  center: location<br/>size: number<br/>warning: number  |    |    |    |
|  player_shift_world_border  |  Move world border  |  Moves the world border for the player without changing it for other players.  |  player/world  |  old_size: number<br/>size: number<br/>time: number  |    |    |    |
|  player_show_custom_recipe  |  Show custom recipe  |  Shows a new recipe to the player in the recipe book.  |  player/miscellaneous  |  names: text<br/>is_vanilla_recipe: enum<br/>{TF}  |    |    |    |
|  player_show_debug_marker  |  Show debug marker  |  Shows the player a debug marker at the location for the given time. Red and blue colors work for players on 1.19.4 and above.  |  player/world  |  location: location<br/>name: text<br/>duration: number<br/>red: number<br/>green: number<br/>blue: number<br/>alpha: number  |    |  Leave the "Display name" argument empty to hide the name completely.  |    |
|  player_show_demo_screen  |  Show demo mode screen  |  Shows the player the demo mode screen.  |  player/communication  |    |    |    |    |
|  player_show_dialog_menu_from_nbt  |  Show dialog window  |  Shows the player a dialog window from NBT tags.  |  player/communication  |  dialog_nbt: text  |    |    |    |
|  player_show_inventory_menu  |  Show menu  |  Shows the player an inventory menu with the chosen items and title.  |  player/inventory_menus  |  items: item<br/>name: text<br/>custom_id: text<br/>inventory_type: enum<br/>&nbsp;&nbsp;- CHEST<br/>&nbsp;&nbsp;- DISPENSER<br/>&nbsp;&nbsp;- DROPPER<br/>&nbsp;&nbsp;- FURNACE<br/>&nbsp;&nbsp;- WORKBENCH<br/>&nbsp;&nbsp;- ENCHANTING<br/>&nbsp;&nbsp;- BREWING<br/>&nbsp;&nbsp;- ANVIL<br/>&nbsp;&nbsp;- SMITHING<br/>&nbsp;&nbsp;- BEACON<br/>&nbsp;&nbsp;- HOPPER<br/>&nbsp;&nbsp;- BLAST_FURNACE<br/>&nbsp;&nbsp;- SMOKER<br/>&nbsp;&nbsp;- CARTOGRAPHY<br/>&nbsp;&nbsp;- GRINDSTONE<br/>&nbsp;&nbsp;- STONECUTTER<br/>&nbsp;&nbsp;- CRAFTER  |    |    |    |
|  player_show_scoreboard  |  Show scoreboard  |  Shows the given scoreboard to the player. The scoreboard must have at least one value to be shown.  |  player/miscellaneous  |  id: text  |    |    |    |
|  player_show_win_screen  |  Show credits screen  |  Shows the player the credits screen.  |  player/communication  |    |    |    |    |
|  player_spectate_target  |  Spectate target  |  Sets the player spectator camera target.  |  player/movement  |  name_or_uuid: text  |    |    |    |
|  player_start_using_item  |  Start using item  |  Starts using the item in the given hand.  |  player/item_management  |  equipment: enum<br/>&nbsp;&nbsp;- MAIN_HAND<br/>&nbsp;&nbsp;- OFF_HAND  |    |    |    |
|  player_stop_sound  |  Stop sound  |  Stops all or the given sounds for the player.  |  player/communication  |  sounds: sound  |    |    |    |
|  player_stop_sounds_by_source  |  Stop sounds by source  |  Stops all sounds from the given source.  |  player/communication  |  source: enum<br/>&nbsp;&nbsp;- AMBIENT<br/>&nbsp;&nbsp;- BLOCK<br/>&nbsp;&nbsp;- HOSTILE<br/>&nbsp;&nbsp;- MASTER<br/>&nbsp;&nbsp;- MUSIC<br/>&nbsp;&nbsp;- NEUTRAL<br/>&nbsp;&nbsp;- PLAYER<br/>&nbsp;&nbsp;- RECORD<br/>&nbsp;&nbsp;- VOICE<br/>&nbsp;&nbsp;- WEATHER<br/>&nbsp;&nbsp;- UI  |    |    |    |
|  player_swing_hand  |  Play arm swing animation  |  Plays the arm swing animation for the player.  |  player/appearance  |  hand_type: enum<br/>&nbsp;&nbsp;- MAIN<br/>&nbsp;&nbsp;- OFF  |    |    |    |
|  player_teleport  |  Teleportation  |  Teleports the player to the chosen location.  |  player/movement  |  location: location<br/>keep_rotation: enum<br/>{TF}<br/>keep_velocity: enum<br/>{TF}<br/>dismount: enum<br/>{TF}  |    |  Closes the open inventory menu.  |    |
|  player_teleport_sequence  |  Teleport sequence  |  Teleports the player between locations with a given delay.  |  player/movement  |  delay: number<br/>locations: location  |    |    |    |
|  player_transfer_to_other_server  |  Transfer to another server  |  Transfers the player to the given server.  |  player/miscellaneous  |  domain: text<br/>port: number  |    |  If the "Server port" argument is left empty, the default port (25565) is used.  |    |
|  send_currency_transaction  |  Request transaction  |  Sends the player a request to make an emerald transaction.  |  player/miscellaneous  |  amount: number<br/>description: text<br/>reason: text  |    |    |    |

## Quick ref
> Argument **names and types only**, one line per action/condition — scan this first. Exact enum values and extra info: see the full table row above. ⚠ deprecated = do not use.

- `if_player_chat_colors_enabled` — (no arguments)
- `if_player_chat_message_equals` — chat_messages: text, ignore_case: enum{TF}
- `if_player_collides_at_location` — location: location
- `if_player_collides_using_hitbox` — min: location, max: location
- `if_player_collides_with_entity` — name_or_uuid: text, check_type: enum
- `if_player_cursor_item_equals` — items: item, comparison_mode: enum{CMP}
- `if_player_gamemode_equals` — gamemode: enum
- `if_player_has_custom_recipe_discovered` — names: text, is_vanilla_recipe: enum{TF}, compare_type: enum{ANY_ALL}
- `if_player_has_input` — input_type: enum
- `if_player_has_item` — items: item, check_mode: enum{ANY_ALL}, comparison_mode: enum{CMP}
- `if_player_has_item_at_least` — item: item, count: number, comparison_mode: enum
- `if_player_has_item_in_slot` — items: item, slots: number, comparison_mode: enum{CMP}
- `if_player_has_potion_effect` — potions: potion, check_mode: enum{ANY_ALL}
- `if_player_has_privilege` — privilege: enum, exact: enum{TF}
- `if_player_has_room_for_item` — items: item, check_mode: enum{ANY_ALL}, checked_slots: enum
- `if_player_hotbar_slot_equals` — slot: number
- `if_player_in_area` — location_1: location, location_2: location, ignore_y_axis: enum{TF}, intersect_type: enum, check_type: enum
- `if_player_inventory_menu_slot_equals` — items: item, slots: number, comparison_mode: enum{CMP}
- `if_player_inventory_type_open` — inventory_type: enum
- `if_player_is_allow_server_listing` — (no arguments)
- `if_player_is_blocking` — (no arguments)
- `if_player_is_disguised` — (no arguments)
- `if_player_is_flying` — (no arguments)
- `if_player_is_gliding` — (no arguments)
- `if_player_is_holding` — items: item, hand_slot: enum, comparison_mode: enum{CMP}
- `if_player_is_looking_at_block` — blocks: block, locations: location, distance: number, fluid_mode: enum
- `if_player_is_near` — ignore_y_axis: enum{TF}, location: location, range: number
- `if_player_is_on_ground` — (no arguments)
- `if_player_is_online_mode` — (no arguments)
- `if_player_is_riding_entity` — entity_ids: text, compare_mode: enum
- `if_player_is_self_disguised` — (no arguments)
- `if_player_is_sleeping` — (no arguments)
- `if_player_is_sneaking` — (no arguments)
- `if_player_is_sprinting` — (no arguments)
- `if_player_is_standing_on_block` — blocks: block, locations: location, only_solid: enum{TF}
- `if_player_is_swimming` — (no arguments)
- `if_player_is_transferred` — (no arguments)
- `if_player_is_using_item` — items: item, comparison_mode: enum{CMP}
- `if_player_is_wearing_item` — items: item, check_mode: enum{ANY_ALL}, comparison_mode: enum{CMP}
- `if_player_item_group_is_not_on_cooldown` — item_keys: text, check_mode: enum{ANY_ALL}
- `if_player_item_is_not_on_cooldown` — items: item, check_mode: enum{ANY_ALL}
- `if_player_name_equals` — names_or_uuids: text
- `if_player_text_filtering_enabled` — (no arguments)
- `player_add_inventory_menu_row` — items: item, position: enum
- `player_allow_placing_breaking_blocks` — allow: enum{TF}, blocks: block
- `player_boost_elytra` — firework: item
- `player_clear_active_item` — (no arguments)
- `player_clear_chat` — (no arguments)
- `player_clear_debug_markers` — (no arguments)
- `player_clear_ender_chest_contents` — (no arguments)
- `player_clear_inventory` — clear_mode: enum
- `player_clear_items` — items: item
- `player_clear_potion_effects` — (no arguments)
- `player_close_dialog_menu` — (no arguments)
- `player_close_inventory` — (no arguments)
- `player_complete_using_active_item` — (no arguments)
- `player_connect_to_server` — server_name: text
- `player_damage` — damage: number, source: text
- `player_disguise_as_block` — block: block, visible_to_self: enum{TF}
- `player_disguise_as_entity` — entity_type: item, visible_to_self: enum{TF}
- `player_disguise_as_item` — item: item, visible_to_self: enum{TF}
- `player_display_bell_ring` — location: location, direction: enum
- `player_display_block` — location: location, block: block
- `player_display_end_gateway_beam` — location: location, color: enum
- `player_display_hologram` — location: location, text: text
- `player_display_lightning` — location: location
- `player_display_particle` — particle: particle, location: location
- `player_display_particle_circle` — particle: particle, center: location, radius: number, points: number, start_angle: number, perpendicular: vector, angle_unit: enum{DEG_RAD}
- `player_display_particle_cube` — particle: particle, first_corner: location, second_corner: location, spacing: number, type: enum
- `player_display_particle_line` — particle: particle, start: location, end: location, divider: number, unit_of_measurement: enum
- `player_display_particle_ray` — particle: particle, start: location, ray: vector, divider: number, unit_of_measurement: enum
- `player_display_particle_sphere` — particle: particle, center: location, radius: number, points: number
- `player_display_particle_spiral` — particle: particle, center: location, distance: number, radius: number, points: number, rotations: number, start_angle: number, angle_unit: enum{DEG_RAD}
- `player_display_pick_up_animation` — collected_name_or_uuid: text, collector_name_or_uuid: text, amount: number
- `player_display_sign_text` — location: location, line_1: text, line_2: text, line_3: text, line_4: text, side: enum
- `player_display_vibration` — from: location, to: location, destination_time: number
- `player_expand_inventory_menu` — items: item, size: number
- `player_face_location` — location: location
- `player_get_attribute` — variable: variable, attribute_type: enum, return_value: enum
- `player_get_nbt` — variable: variable, path: text, value_type: enum
- `player_give_experience` — experience: number, mode: enum
- `player_give_items` — items: item, amount: number
- `player_give_potion_effect` — potions: potion, overwrite: enum{TF}, show_icon: enum{TF}, particle_mode: enum
- `player_give_random_item` — items: item
- `player_heal` — heal: number
- `player_hide_custom_recipe` — names: text, is_vanilla_recipe: enum{TF}
- `player_hide_entity` — name_or_uuid: text, hide: enum{TF}
- `player_hide_scoreboard` — (no arguments)
- `player_kick` — (no arguments)
- `player_launch_forward` — power: number, increment: enum{TF}, launch_axis: enum
- `player_launch_projectile` — projectile: item, location: location, name: text, speed: number, inaccuracy: number, trail: particle
- `player_launch_to_location` — location: location, power: number, increment: enum{TF}
- `player_launch_up` — power: number, increment: enum{TF}
- `player_leave_vehicle` — (no arguments)
- `player_load_inventory` — (no arguments)
- `player_mimic_disguise_from_entity` — name_or_uuid: text, include_disguise: enum{TF}, disguise: enum, remove_original_entity: enum{TF}
- `player_open_book` — book: item
- `player_open_container_inventory` — location: location
- `player_open_ender_chest` — (no arguments)
- `player_open_working_menu` — title: text, menu_type: enum
- `player_play_animation_action` — animation: enum
- `player_play_hurt_animation` — yaw: number
- `player_play_sound` — sound: sound, location: location
- `player_play_sound_from_entity` — sounds: sound, name_or_uuid: text
- `player_play_sound_sequence` — sounds: sound, delay: number, location: location
- `player_randomized_teleport` — locations: location, keep_rotation: enum{TF}, keep_velocity: enum{TF}, dismount: enum{TF}
- `player_redirect_world` — world_id: text
- `player_remove_boss_bar` — id: text
- `player_remove_disguise` — (no arguments)
- `player_remove_display_blocks` — pos_1: location, pos_2: location
- `player_remove_inventory_menu_row` — size: number, position: enum
- `player_remove_items` — items: item
- `player_remove_pose` — (no arguments)
- `player_remove_potion_effect` — potions: potion
- `player_remove_self_disguise` — (no arguments)
- `player_remove_skin` — (no arguments)
- `player_remove_world_border` — (no arguments)
- `player_replace_items` — items: item, replace: item, count: number
- `player_reset_waypoint_color` — (no arguments)
- `player_reset_weather` — (no arguments)
- `player_ride_entity` — name_or_uuid: text
- `player_save_inventory` — (no arguments)
- `player_self_disguise_as_block` — block: block
- `player_self_disguise_as_entity` — entity_type: item
- `player_self_disguise_as_item` — item: item
- `player_send_action_bar` — messages: text, merging: enum
- `player_send_advancement` — frame: enum, name: text, icon: item
- `player_send_break_animation` — locations: location, stage: number
- `player_send_dialogue` — messages: text, delay: number
- `player_send_hover` — message: text, hover: text
- `player_send_message` — messages: text, merging: enum
- `player_send_minimessage` — minimessage: text
- `player_send_title` — title: text, subtitle: text, fade_in: number, stay: number, fade_out: number
- `player_set_absorption_health` — health: number
- `player_set_air_ticks` — ticks: number
- `player_set_allow_flying` — allow_flying: enum{TF}
- `player_set_armor` — helmet: item, chestplate: item, leggings: item, boots: item
- `player_set_arrows_in_body` — amount: number
- `player_set_attack_speed` — speed: number
- `player_set_attribute` — value: number, attribute_type: enum
- `player_set_bee_stingers_in_body` — amount: number
- `player_set_block_opened_state` — location: location, is_opened: enum{TF}
- `player_set_boss_bar` — id: text, title: text, progress: number, color: enum, style: enum, sky_effect: enum
- `player_set_chat_completions` — completions: text, setting_mode: enum
- `player_set_collidable` — collidable: enum{TF}
- `player_set_compass_target` — location: location
- `player_set_cursor_item` — item: item
- `player_set_death_drops` — death_drops: enum{TF}
- `player_set_death_screen_score` — score: number
- `player_set_default_visible` — default_visible: enum{TF}
- `player_set_enchantment_seed` — seed: number
- `player_set_ender_chest_contents` — items: item
- `player_set_entity_glowing` — name_or_uuid: text, color: enum, glow: enum{TF}
- `player_set_equipment` — item: item, slot: enum
- `player_set_exhaustion` — exhaustion: number, mode: enum
- `player_set_experience` — experience: number, mode: enum
- `player_set_fall_distance` — distance: number
- `player_set_fire_ticks` — ticks: number
- `player_set_flying` — is_flying: enum{TF}
- `player_set_fog_distance` — distance: number
- `player_set_food` — food: number, mode: enum
- `player_set_freeze_ticks` — ticks: number, ticking_locked: enum{TF}
- `player_set_gamemode` — gamemode: enum, flight_mode: enum
- `player_set_gliding` — is_gliding: enum{TF}
- `player_set_health` — health: number
- `player_set_hotbar_slot` — slot: number
- `player_set_instant_respawn` — instant_respawn: enum{TF}
- `player_set_inventory_kept` — kept: enum{TF}
- `player_set_inventory_menu_custom_id` — custom_id: text
- `player_set_inventory_menu_item` — item: item, slot: number
- `player_set_inventory_menu_name` — text: text
- `player_set_invulnerability_ticks` — ticks: number
- `player_set_item_cooldown` — item: item, cooldown: number, sound: sound
- `player_set_item_group_cooldown` — key: text, cooldown: number
- `player_set_items` — items: item
- `player_set_max_health` — health: number, heal: enum{TF}
- `player_set_max_invulnerability_ticks` — ticks: number
- `player_set_movement_speed` — distance: number, movement_type: enum
- `player_set_nametag_visible` — visible: enum{TF}
- `player_set_player_list_info` — text: text, position: enum, merging: enum
- `player_set_pose` — pose: enum, locked: enum{TF}
- `player_set_pvp` — pvp: enum{TF}
- `player_set_rain_level` — rain_level: number
- `player_set_rotation` — yaw: number, pitch: number
- `player_set_rotation_by_vector` — vector: vector
- `player_set_saturated_regen_rate` — rate: number
- `player_set_saturation` — saturation: number, mode: enum
- `player_set_simulation_distance` — distance: number
- `player_set_skin` — name_or_uuid: text, server_type: enum
- `player_set_slot_item` — item: item, slot: number
- `player_set_spawn_point` — spawn_point: location
- `player_set_starvation_rate` — rate: number
- `player_set_thunder_level` — thunder_level: number
- `player_set_tick_rate` — tick_rate: number
- `player_set_time` — time: number
- `player_set_unsaturated_regen_rate` — rate: number
- `player_set_velocity` — velocity: vector, increment: enum{TF}
- `player_set_visual_fire` — visual_fire: enum{TFN}
- `player_set_waypoint_color` — red: number, green: number, blue: number
- `player_set_waypoint_style` — style: text
- `player_set_weather` — weather_type: enum
- `player_set_world_border` — center: location, size: number, warning: number
- `player_shift_world_border` — old_size: number, size: number, time: number
- `player_show_custom_recipe` — names: text, is_vanilla_recipe: enum{TF}
- `player_show_debug_marker` — location: location, name: text, duration: number, red: number, green: number, blue: number, alpha: number
- `player_show_demo_screen` — (no arguments)
- `player_show_dialog_menu_from_nbt` — dialog_nbt: text
- `player_show_inventory_menu` — items: item, name: text, custom_id: text, inventory_type: enum
- `player_show_scoreboard` — id: text
- `player_show_win_screen` — (no arguments)
- `player_spectate_target` — name_or_uuid: text
- `player_start_using_item` — equipment: enum
- `player_stop_sound` — sounds: sound
- `player_stop_sounds_by_source` — source: enum
- `player_swing_hand` — hand_type: enum
- `player_teleport` — location: location, keep_rotation: enum{TF}, keep_velocity: enum{TF}, dismount: enum{TF}
- `player_teleport_sequence` — delay: number, locations: location
- `player_transfer_to_other_server` — domain: text, port: number
- `send_currency_transaction` — amount: number, description: text, reason: text
