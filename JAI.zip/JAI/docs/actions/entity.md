# Entity actions
> **Enum macros:** {TF} = TRUE / FALSE; {TFN} = TRUE / FALSE / NOT_SET; {ANY_ALL} = ANY / ALL; {ITEM_MATCH} = EXACT / IGNORE_NAME_DURABILITY / IGNORE_NAME_DURABILITY_ENCHANTMENTS / CUSTOM_TAGS_CONTAINS / MINECRAFT_TAG / ITEM_TYPE; {DEG_RAD} = DEGREES / RADIANS; {CMP} = EXACTLY / IGNORE_STACK_SIZE / IGNORE_DURABILITY_AND_STACK_SIZE / TYPE_ONLY. Icon column omitted.


|  ID  |  Name  |  Description  |  Category/Subcategory  |  Arguments  |  Works with  |  Additional info  |  Status  |
|  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |  ---  |
|  entity_attach_lead  |  Attach lead  |  Leashes an entity to a fence or an entity.  |  entity/movement  |  name_or_uuid: text<br/>location: location  |    |    |    |
|  entity_celar_potion_effects  |  Clear effects  |  Clears all effects from an entity.  |  entity/parameters  |    |    |    |    |
|  entity_clear_merchant_recipes  |  Clear villager trades  |  Clears all villager trades.  |  entity/settings  |    |  Villagers<br/>Wandering traders  |    |    |
|  entity_complete_using_active_item  |  Finish using item  |  Finishes using the current item in hand with a result.  |  entity/goals  |    |  Mobs  |    |    |
|  entity_damage  |  Deal damage  |  Deals damage to an entity.  |  entity/parameters  |  damage: number<br/>source: text  |    |    |    |
|  entity_disguise_as_block  |  Disguise entity as block  |  Disguises an entity as a block.  |  entity/appearance  |  block: block  |    |    |    |
|  entity_disguise_as_entity  |  Disguise as entity  |  Disguise an entity as an entity.  |  entity/appearance  |  entity_type: item  |    |    |    |
|  entity_disguise_as_item  |  Disguise entity as item  |  Disguises an entity as an item.  |  entity/appearance  |  item: item  |    |    |    |
|  entity_disguise_as_player  |  Disguise entity as player  |  Disguises an entity as a player.  |  entity/appearance  |  name_or_uuid: text<br/>display_name: text<br/>server_type: enum<br/>&nbsp;&nbsp;- MOJANG<br/>&nbsp;&nbsp;- SERVER<br/>&nbsp;&nbsp;- SERVER_DEFAULT  |    |    |    |
|  entity_eat_grass  |  Has grass  |  Makes a sheep eat grass.  |  entity/goals  |    |  Sheep  |    |    |
|  entity_eat_target  |  Set eating target  |  Sets an eating target for an entity.  |  entity/goals  |  name_or_uuid: text  |  Frogs  |    |    |
|  entity_explode  |  Explode  |  Makes an entity explode.  |  entity/goals  |    |  Creepers<br/>TNT<br/>TNT minecarts<br/>Firework rockets<br/>Sulfur slimes  |    |    |
|  entity_face_location  |  Rotate to location  |  Rotates an entity towards a location.  |  entity/movement  |  location: location  |    |    |    |
|  entity_get_attribute  |  Get entity attribute value  |  Gets the given entity attribute value and assigns the result to a variable.  |  entity/parameters  |  variable: variable<br/>attribute_type: enum<br/>&nbsp;&nbsp;- GENERIC_MAX_HEALTH<br/>&nbsp;&nbsp;- GENERIC_MAX_ABSORPTION<br/>&nbsp;&nbsp;- GENERIC_FOLLOW_RANGE<br/>&nbsp;&nbsp;- GENERIC_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_SPEED<br/>&nbsp;&nbsp;- GENERIC_FLYING_SPEED<br/>&nbsp;&nbsp;- GENERIC_ATTACK_DAMAGE<br/>&nbsp;&nbsp;- GENERIC_ATTACK_KNOCKBACK<br/>&nbsp;&nbsp;- GENERIC_ATTACK_SPEED<br/>&nbsp;&nbsp;- GENERIC_ARMOR<br/>&nbsp;&nbsp;- GENERIC_ARMOR_TOUGHNESS<br/>&nbsp;&nbsp;- GENERIC_LUCK<br/>&nbsp;&nbsp;- GENERIC_JUMP_STRENGTH<br/>&nbsp;&nbsp;- ZOMBIE_SPAWN_REINFORCEMENTS<br/>&nbsp;&nbsp;- GENERIC_FALL_DAMAGE_MULTIPLIER<br/>&nbsp;&nbsp;- GENERIC_SAFE_FALL_DISTANCE<br/>&nbsp;&nbsp;- GENERIC_SCALE<br/>&nbsp;&nbsp;- GENERIC_STEP_HEIGHT<br/>&nbsp;&nbsp;- GENERIC_GRAVITY<br/>&nbsp;&nbsp;- PLAYER_BLOCK_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_ENTITY_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_BLOCK_BREAK_SPEED<br/>&nbsp;&nbsp;- GENERIC_BURNING_TIME<br/>&nbsp;&nbsp;- GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- GENERIC_OXYGEN_BONUS<br/>&nbsp;&nbsp;- GENERIC_WATER_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_MINING_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_SNEAKING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SUBMERGED_MINING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SWEEPING_DAMAGE_RATIO<br/>&nbsp;&nbsp;- TEMP_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_TRANSMIT_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_RECEIVE_RANGE<br/>&nbsp;&nbsp;- CAMERA_DISTANCE<br/>&nbsp;&nbsp;- BOUNCINESS<br/>&nbsp;&nbsp;- FRICTION_MODIFIER<br/>&nbsp;&nbsp;- AIR_DRAG_MODIFIER<br/>&nbsp;&nbsp;- NAME_TAG_DISTANCE<br/>&nbsp;&nbsp;- BELOW_NAME_DISTANCE<br/>return_value: enum<br/>&nbsp;&nbsp;- VALUE<br/>&nbsp;&nbsp;- BASE_VALUE<br/>&nbsp;&nbsp;- DEFAULT_VALUE  |    |    |    |
|  entity_get_custom_tag  |  Get custom tag  |  Gets a custom NBT tag of an entity.  |  entity/miscellaneous  |  variable: variable<br/>name: text<br/>default: any  |    |    |    |
|  entity_get_custom_tags  |  Get custom tags  |  Gets an entity custom tags and assigns the result to a variable.  |  entity/miscellaneous  |  variable: variable  |    |    |    |
|  entity_get_equipment_item  |  Get entity equipment  |  Gets entity equipment from the given slot and assigns the result to a variable.  |  entity/miscellaneous  |  variable: variable<br/>slot: enum<br/>&nbsp;&nbsp;- CHEST<br/>&nbsp;&nbsp;- FEET<br/>&nbsp;&nbsp;- HAND<br/>&nbsp;&nbsp;- HEAD<br/>&nbsp;&nbsp;- LEGS<br/>&nbsp;&nbsp;- OFF_HAND<br/>&nbsp;&nbsp;- BODY<br/>&nbsp;&nbsp;- SADDLE  |    |    |    |
|  entity_get_nbt  |  Get entity NBT tags  |  Gets entity NBT tags by the given path and assigns the result to a variable.  |  entity/miscellaneous  |  variable: variable<br/>path: text<br/>value_type: enum<br/>&nbsp;&nbsp;- ANY_VALUE<br/>&nbsp;&nbsp;- NBT_STRING  |    |    |    |
|  entity_give_potion_effects  |  Grant effects  |  Grants the chosen effects to an entity.  |  entity/parameters  |  potions: potion<br/>overwrite: enum<br/>{TF}<br/>show_icon: enum<br/>{TF}<br/>particle_mode: enum<br/>&nbsp;&nbsp;- REGULAR<br/>&nbsp;&nbsp;- AMBIENT<br/>&nbsp;&nbsp;- NONE  |    |    |    |
|  entity_heal  |  Heal entity  |  Heals an entity.  |  entity/parameters  |  heal: number  |    |    |    |
|  entity_ignite_creeper  |  Ignite creeper  |  Ignites a creeper, making it explode after a set period.  |  entity/goals  |    |  Creepers<br/>TNT minecarts<br/>Sulfur slimes  |    |    |
|  entity_jump  |  Jump  |  Makes an entity jump.  |  entity/goals  |    |  Mobs  |    |    |
|  entity_launch_forward  |  Launch forward  |  Launches an entity forward or backward along its look direction depending on power.  |  entity/movement  |  power: number<br/>increment: enum<br/>{TF}<br/>launch_axis: enum<br/>&nbsp;&nbsp;- YAW_AND_PITCH<br/>&nbsp;&nbsp;- YAW  |    |    |    |
|  entity_launch_projectile  |  Launch projectile  |  Launch a projectile from the entity location.  |  entity/miscellaneous  |  projectile: item<br/>location: location<br/>name: text<br/>speed: number<br/>inaccuracy: number<br/>trail: particle  |    |    |    |
|  entity_launch_to_location  |  Launch to location  |  Launches entities towards the chosen location.  |  entity/movement  |  location: location<br/>power: number<br/>increment: enum<br/>{TF}  |    |    |    |
|  entity_launch_up  |  Toss up  |  Tosses an entity up or down depending on power.  |  entity/movement  |  power: number<br/>increment: enum<br/>{TF}  |    |    |    |
|  entity_leave_vehicle  |  Eject from vehicle  |  Ejects an entity from a vehicle or entity.  |  entity/movement  |    |    |    |    |
|  entity_mimic_disguise_from_entity  |  Disguise entity as a world entity  |  Disguises an entity as the given world entity.  |  entity/appearance  |  name_or_uuid: text<br/>include_disguise: enum<br/>{TF}<br/>remove_original_entity: enum<br/>{TF}  |    |    |    |
|  entity_modify_piglin_barter_materials  |  Edit piglin trades  |  Changes the items a piglin can give in a trade.  |  entity/settings  |  materials: item<br/>modification_mode: enum<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- REMOVE  |  Piglins  |  Cannot change the items the piglin sells by default.  |    |
|  entity_modify_piglin_interested_materials  |  Edit piglin trade items  |  Changes the items required for a piglin trade.  |  entity/settings  |  materials: item<br/>modification_mode: enum<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- REMOVE  |  Piglins  |  Cannot change the items the piglin demands by default.  |    |
|  entity_move_to_location  |  Set movement to location  |  Instructs the entity AI to always pathfind to a given location at a given speed.  |  entity/goals  |  location: location<br/>speed: number  |  Mobs  |    |    |
|  entity_move_to_location_stop  |  Stop movement to location  |  Stops an entity walking to a location.  |  entity/goals  |    |  Mobs  |    |    |
|  entity_play_damage_animation  |  Play hurt animation  |  Plays the hurt animation on an entity.  |  entity/appearance  |  damage_type: enum<br/>&nbsp;&nbsp;- DAMAGE<br/>&nbsp;&nbsp;- CRITICAL_DAMAGE<br/>&nbsp;&nbsp;- MAGICAL_DAMAGE  |    |    |    |
|  entity_play_hurt_animation  |  Play damage receiving animation  |  Plays the damage receiving animation on an entity with a given tilt.  |  entity/appearance  |  yaw: number  |    |    |    |
|  entity_ram_target  |  Ram entity  |  Makes goats ram the given entity.  |  entity/goals  |  name_or_uuid: text  |  Goats  |    |    |
|  entity_remove  |  Remove entity  |  Removes an entity from the world.  |  entity/miscellaneous  |    |    |    |    |
|  entity_remove_custom_tag  |  Remove custom tag  |  Removes a custom NBT tag from an entity.  |  entity/miscellaneous  |  name: text  |    |    |    |
|  entity_remove_custom_tags  |  Remove custom tags  |  Removes all custom tags from an entity.  |  entity/miscellaneous  |    |    |    |    |
|  entity_remove_disguise  |  Remove disguise  |  Removes an entity disguise.  |  entity/appearance  |    |    |    |    |
|  entity_remove_merchant_recipe  |  Remove villager trade  |  Removes a villager trade at the given index.  |  entity/settings  |  recipe_index: number  |  Villagers<br/>Wandering traders  |    |    |
|  entity_remove_potion_effect  |  Remove effect  |  Removes the chosen effects from an entity.  |  entity/parameters  |  effects: potion  |    |    |    |
|  entity_reset_display_brightness  |  Reset brightness  |  Reset display entity brightness.  |  entity/display_entity  |    |  Any display entity  |    |    |
|  entity_reset_display_glow_color  |  Reset glow color  |  Reset display entity glow color.  |  entity/display_entity  |    |  Item displays<br/>Block displays  |    |    |
|  entity_reset_mannequin_description  |  Clear mannequin description  |  Clears the mannequin description.  |  entity/appearance  |    |  Mannequins  |    |    |
|  entity_reset_text_display_background  |  Reset background color  |  Reset text display background color and opacity.  |  entity/display_entity  |    |  Text displays  |    |    |
|  entity_reset_waypoint_color  |  Reset locator icon color  |  Resets the entity locator icon color to default.  |  entity/settings  |    |  Mobs  |  The game rule "Locator visibility" must be enabled for this action to work.  |    |
|  entity_retrieve_fishing_hook  |  Return fishing bobber  |  Retracts the cast fishing bobber of the rod in the given entity hand.  |  entity/goals  |  slot: enum<br/>&nbsp;&nbsp;- MAIN_HAND<br/>&nbsp;&nbsp;- OFF_HAND  |  Fishing rods  |    |    |
|  entity_ride_entity  |  Mount onto entity  |  Mounts an entity onto another entity or a player.  |  entity/movement  |  name_or_uuid: text  |    |    |    |
|  entity_roll_armadillo  |  Set armadillo defense state  |  Sets the armadillo defense state (whether it is rolled up).  |  entity/goals  |  roll: enum<br/>&nbsp;&nbsp;- ROLL_OUT<br/>&nbsp;&nbsp;- ROLL_UP  |  Armadillos  |    |    |
|  entity_set_absorption_health  |  Set absorption health  |  Sets the entity absorption health.  |  entity/parameters  |  health: number  |    |    |    |
|  entity_set_age_lock  |  Set growth lock  |  Sets the entity growth lock.  |  entity/settings  |  age_lock: enum<br/>{TF}  |  Aging mobs  |    |    |
|  entity_set_ai  |  Set entity intelligence  |  Sets the entity intelligence.  |  entity/settings  |  ai: enum<br/>{TF}  |    |    |    |
|  entity_set_allay_dancing  |  Make Allay dance  |  Makes the Allay play the dance animation.  |  entity/goals  |  dance: enum<br/>{TF}  |  Allays  |    |    |
|  entity_set_angry  |  Set anger mode  |  Sets the entity anger mode towards a given target.  |  entity/settings  |  angry: enum<br/>{TF}<br/>target: text  |  Bees<br/>Wolves<br/>Zombified piglins<br/>Endermen<br/>Mobs  |  The entity needs a target to work correctly.  |    |
|  entity_set_animal_age  |  Set animal age  |  Sets the animal age.  |  entity/parameters  |  age: number<br/>lock: enum<br/>&nbsp;&nbsp;- ENABLE<br/>&nbsp;&nbsp;- DISABLE<br/>&nbsp;&nbsp;- DONT_CHANGE  |    |    |    |
|  entity_set_armor_items  |  Set armor  |  Sets the entity armor.  |  entity/miscellaneous  |  helmet: item<br/>chestplate: item<br/>leggings: item<br/>boots: item<br/>silent: enum<br/>{TF}  |    |  Any item or block shows on the head when placed in the helmet slot.  |    |
|  entity_set_armor_stand_parts  |  Set armor stand details  |  Set armor stand details.  |  entity/appearance  |  arms: enum<br/>&nbsp;&nbsp;- ENABLE<br/>&nbsp;&nbsp;- DISABLE<br/>&nbsp;&nbsp;- DONT_CHANGE<br/>base_plate: enum<br/>&nbsp;&nbsp;- ENABLE<br/>&nbsp;&nbsp;- DISABLE<br/>&nbsp;&nbsp;- DONT_CHANGE  |  Armor stands  |    |    |
|  entity_set_armor_stand_pose  |  Set armor stand pose  |  Sets the armor stand pose.  |  entity/appearance  |  x_rotation: number<br/>y_rotation: number<br/>z_rotation: number<br/>body_part: enum<br/>&nbsp;&nbsp;- HEAD<br/>&nbsp;&nbsp;- BODY<br/>&nbsp;&nbsp;- LEFT_ARM<br/>&nbsp;&nbsp;- RIGHT_ARM<br/>&nbsp;&nbsp;- LEFT_LEG<br/>&nbsp;&nbsp;- RIGHT_LEG  |  Armor stands  |    |    |
|  entity_set_arrow_hit_sound  |  Set projectile hit sound  |  Sets the sound a projectile makes when hitting an entity.  |  entity/miscellaneous  |  sound: sound  |  Arrows<br/>Tridents  |    |    |
|  entity_set_arrow_pierce  |  Set arrow pierce count  |  Sets how many times an arrow can pierce entities (0 to 127).  |  entity/parameters  |  pierce: number  |    |    |    |
|  entity_set_attribute  |  Set attribute  |  Sets the given entity attribute to the given value.  |  entity/parameters  |  value: number<br/>attribute_type: enum<br/>&nbsp;&nbsp;- GENERIC_MAX_HEALTH<br/>&nbsp;&nbsp;- GENERIC_MAX_ABSORPTION<br/>&nbsp;&nbsp;- GENERIC_FOLLOW_RANGE<br/>&nbsp;&nbsp;- GENERIC_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_SPEED<br/>&nbsp;&nbsp;- GENERIC_FLYING_SPEED<br/>&nbsp;&nbsp;- GENERIC_ATTACK_DAMAGE<br/>&nbsp;&nbsp;- GENERIC_ATTACK_KNOCKBACK<br/>&nbsp;&nbsp;- GENERIC_ATTACK_SPEED<br/>&nbsp;&nbsp;- GENERIC_ARMOR<br/>&nbsp;&nbsp;- GENERIC_ARMOR_TOUGHNESS<br/>&nbsp;&nbsp;- GENERIC_LUCK<br/>&nbsp;&nbsp;- GENERIC_JUMP_STRENGTH<br/>&nbsp;&nbsp;- ZOMBIE_SPAWN_REINFORCEMENTS<br/>&nbsp;&nbsp;- GENERIC_FALL_DAMAGE_MULTIPLIER<br/>&nbsp;&nbsp;- GENERIC_SAFE_FALL_DISTANCE<br/>&nbsp;&nbsp;- GENERIC_SCALE<br/>&nbsp;&nbsp;- GENERIC_STEP_HEIGHT<br/>&nbsp;&nbsp;- GENERIC_GRAVITY<br/>&nbsp;&nbsp;- PLAYER_BLOCK_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_ENTITY_INTERACTION_RANGE<br/>&nbsp;&nbsp;- PLAYER_BLOCK_BREAK_SPEED<br/>&nbsp;&nbsp;- GENERIC_BURNING_TIME<br/>&nbsp;&nbsp;- GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE<br/>&nbsp;&nbsp;- GENERIC_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- GENERIC_OXYGEN_BONUS<br/>&nbsp;&nbsp;- GENERIC_WATER_MOVEMENT_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_MINING_EFFICIENCY<br/>&nbsp;&nbsp;- PLAYER_SNEAKING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SUBMERGED_MINING_SPEED<br/>&nbsp;&nbsp;- PLAYER_SWEEPING_DAMAGE_RATIO<br/>&nbsp;&nbsp;- TEMP_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_TRANSMIT_RANGE<br/>&nbsp;&nbsp;- WAYPOINT_RECEIVE_RANGE<br/>&nbsp;&nbsp;- CAMERA_DISTANCE<br/>&nbsp;&nbsp;- BOUNCINESS<br/>&nbsp;&nbsp;- FRICTION_MODIFIER<br/>&nbsp;&nbsp;- AIR_DRAG_MODIFIER<br/>&nbsp;&nbsp;- NAME_TAG_DISTANCE<br/>&nbsp;&nbsp;- BELOW_NAME_DISTANCE  |    |    |    |
|  entity_set_aware  |  Set mob awareness  |  When off, disables the mob AI but keeps gravity, pushing, etc.  |  entity/goals  |  aware: enum<br/>{TF}  |  Mobs  |    |    |
|  entity_set_axolotl_type  |  Set axolotl type  |  Sets the axolotl type.  |  entity/appearance  |  axolotl_type: enum<br/>&nbsp;&nbsp;- BLUE<br/>&nbsp;&nbsp;- CYAN<br/>&nbsp;&nbsp;- GOLD<br/>&nbsp;&nbsp;- LUCY<br/>&nbsp;&nbsp;- WILD  |  Axolotls  |    |    |
|  entity_set_baby  |  Set baby mode  |  Sets the entity baby mode.  |  entity/settings  |  baby: enum<br/>{TF}  |    |    |    |
|  entity_set_base_arrow_damage  |  Set projectile base damage  |  Sets the projectile base damage used in the projectile damage formula on hit.  |  entity/parameters  |  damage: number  |  Arrows<br/>Tridents  |  Formula for arrows: base_damage * projectile_speed = damage dealt<br/>Formula for tridents: base_damage = damage dealt  |    |
|  entity_set_bee_has_stinger  |  Set bee stinger  |  Sets the bee stinger state.  |  entity/settings  |  stinger: enum<br/>{TF}  |  Bees  |    |    |
|  entity_set_bee_nectar  |  Set bee pollen  |  Sets the bee pollen visibility.  |  entity/appearance  |  nectar: enum<br/>{TF}  |  Bees  |    |    |
|  entity_set_block_display_block  |  Set displayed block  |  Sets the block display displayed block.  |  entity/display_entity  |  displayed_block: block  |  Block displays  |    |    |
|  entity_set_camel_dashing  |  Set camel dash animation  |  Sets the camel dash animation.  |  entity/settings  |  dashing: enum<br/>{TF}  |  Camels  |    |    |
|  entity_set_carrying_chest  |  Set chest visibility  |  Sets chest visibility on an entity.  |  entity/settings  |  carrying: enum<br/>{TF}  |  Donkeys<br/>Mules<br/>Llamas  |    |    |
|  entity_set_cat_lying_down  |  Set cat lying mode  |  Sets the cat lying mode.  |  entity/appearance  |  lying_down: enum<br/>{TF}  |  Cats  |    |    |
|  entity_set_cat_type  |  Set cat type  |  Sets the cat type.  |  entity/appearance  |  cat_type: enum<br/>&nbsp;&nbsp;- TABBY<br/>&nbsp;&nbsp;- BLACK<br/>&nbsp;&nbsp;- RED<br/>&nbsp;&nbsp;- SIAMESE<br/>&nbsp;&nbsp;- BRITISH_SHORTHAIR<br/>&nbsp;&nbsp;- CALICO<br/>&nbsp;&nbsp;- PERSIAN<br/>&nbsp;&nbsp;- RAGDOLL<br/>&nbsp;&nbsp;- WHITE<br/>&nbsp;&nbsp;- JELLIE<br/>&nbsp;&nbsp;- ALL_BLACK  |  Cats  |    |    |
|  entity_set_celebrating  |  Set celebration mode  |  Sets the entity celebration mode.  |  entity/goals  |  celebrating: enum<br/>{TF}  |  Piglins<br/>Raiders  |    |    |
|  entity_set_chicken_type  |  Set chicken type  |  Sets the chicken color type.  |  entity/appearance  |  variant: enum<br/>&nbsp;&nbsp;- COLD<br/>&nbsp;&nbsp;- WARM<br/>&nbsp;&nbsp;- TEMPERATE  |  Chickens  |    |    |
|  entity_set_collidable  |  Set collision mode  |  Sets the entity collision mode with other entities.  |  entity/settings  |  collidable: enum<br/>{TF}  |    |    |    |
|  entity_set_copper_golem_oxidizing  |  Set copper golem wax state  |  Sets the copper golem wax state.  |  entity/settings  |  oxidizing_state: enum<br/>&nbsp;&nbsp;- WAXED<br/>&nbsp;&nbsp;- UNSET  |  Copper golems  |    |    |
|  entity_set_copper_golem_oxidizing_at_time  |  Set copper golem oxidation time  |  Sets the time it takes a copper golem to oxidize one level in the rain.  |  entity/settings  |  time: number  |  Copper golems  |    |    |
|  entity_set_copper_golem_weathering  |  Set copper golem oxidation  |  Sets the copper golem oxidation level.  |  entity/settings  |  weathering_state: enum<br/>&nbsp;&nbsp;- UNAFFECTED<br/>&nbsp;&nbsp;- EXPOSED<br/>&nbsp;&nbsp;- WEATHERED<br/>&nbsp;&nbsp;- OXIDIZED  |  Copper golems  |    |    |
|  entity_set_cow_type  |  Set cow type  |  Sets the cow color type.  |  entity/appearance  |  variant: enum<br/>&nbsp;&nbsp;- COLD<br/>&nbsp;&nbsp;- WARM<br/>&nbsp;&nbsp;- TEMPERATE  |  Cows  |    |    |
|  entity_set_creeper_charge  |  Set creeper charge  |  Sets whether the creeper is charged.  |  entity/settings  |  charged: enum<br/>{TF}  |  Creepers  |    |    |
|  entity_set_creeper_fuse  |  Set creeper max fuse time  |  Sets the creeper max fuse time.  |  entity/parameters  |  fuse_ticks: number  |  Creepers  |    |    |
|  entity_set_current_health  |  Set entity health  |  Sets the entity health to the chosen amount.  |  entity/parameters  |  health: number  |    |    |    |
|  entity_set_custom_name  |  Set name  |  Sets the entity name.  |  entity/settings  |  custom_name: text  |    |    |    |
|  entity_set_custom_name_visibility  |  Set name visibility  |  Sets the entity name visibility.  |  entity/settings  |  visibility: enum<br/>{TF}  |    |    |    |
|  entity_set_custom_tag  |  Set custom tag  |  Sets a custom NBT tag on an entity.  |  entity/miscellaneous  |  name: text<br/>value: text  |    |    |    |
|  entity_set_death_drops  |  Set item drops  |  Sets whether loot drops from the entity.  |  entity/settings  |  drops: enum<br/>{TF}  |    |    |    |
|  entity_set_death_time  |  Set death duration  |  Sets the entity death duration.  |  entity/parameters  |  death_time: number  |    |    |    |
|  entity_set_default_visible  |  Set visibility  |  Sets the entity visibility.  |  entity/settings  |  default_visible: enum<br/>{TF}  |    |    |    |
|  entity_set_despawning  |  Set entity despawn  |  Sets whether the entity despawns.  |  entity/settings  |  despawning: enum<br/>{TF}  |    |    |    |
|  entity_set_display_billboard  |  Set display mode  |  Sets the display entity render mode.  |  entity/display_entity  |  billboard_type: enum<br/>&nbsp;&nbsp;- CENTER<br/>&nbsp;&nbsp;- FIXED<br/>&nbsp;&nbsp;- HORIZONTAL<br/>&nbsp;&nbsp;- VERTICAL  |  Any display entity  |    |    |
|  entity_set_display_brightness  |  Set brightness  |  Sets the display entity brightness.  |  entity/display_entity  |  block_light_level: number<br/>sky_light_level: number  |  Any display entity  |    |    |
|  entity_set_display_correct_transformation_matrix  |  Set transformation matrix  |  Sets the display entity transformation matrix.  |  entity/display_entity  |  matrix: number  |  Any display entity  |    |    |
|  entity_set_display_culling_suze  |  Set view range size  |  Sets the display entity model view range size.  |  entity/display_entity  |  width: number<br/>height: number  |  Any display entity  |    |    |
|  entity_set_display_glow_color  |  Set glow color  |  Sets the display entity glow color.  |  entity/display_entity  |  color_hexadecimal: text  |  Item displays<br/>Block displays  |    |    |
|  entity_set_display_interpolation  |  Set interpolation  |  Sets the display entity interpolation duration.  |  entity/display_entity  |  interpolation_duration: number<br/>interpolation_delay: number  |  Any display entity  |    |    |
|  entity_set_display_rotation_from_axis_angle  |  Set rotation by axis vector  |  Sets the display entity left or right rotation by axis vector and angle.  |  entity/display_entity  |  axis_vector: vector<br/>angle: number<br/>mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- ADD_LOCAL<br/>input: enum<br/>{DEG_RAD}<br/>rotation: enum<br/>&nbsp;&nbsp;- LEFT_ROTATION<br/>&nbsp;&nbsp;- RIGHT_ROTATION  |  Any display entity  |    |    |
|  entity_set_display_rotation_from_euler_angles  |  Set rotation by Euler angles  |  Sets the display entity left or right rotation by Euler angles.  |  entity/display_entity  |  yaw: number<br/>pitch: number<br/>roll: number<br/>mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD<br/>&nbsp;&nbsp;- ADD_LOCAL<br/>input: enum<br/>{DEG_RAD}<br/>rotation: enum<br/>&nbsp;&nbsp;- LEFT_ROTATION<br/>&nbsp;&nbsp;- RIGHT_ROTATION  |  Any display entity  |    |    |
|  entity_set_display_rotation_from_vector  |  Set rotation by vector  |  Sets the display rotation by the given direction vector and "Up" vector.  |  entity/display_entity  |  direction: vector<br/>up: vector<br/>rotation: enum<br/>&nbsp;&nbsp;- LEFT_ROTATION<br/>&nbsp;&nbsp;- RIGHT_ROTATION  |  Any display entity  |    |    |
|  entity_set_display_scale  |  Set size  |  Sets the display entity size.  |  entity/display_entity  |  scale_vector: vector<br/>mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD  |  Any display entity  |    |    |
|  entity_set_display_shadow  |  Set shadow settings  |  Sets the display entity shadow size and opacity.  |  entity/display_entity  |  shadow_radius: number<br/>shadow_opacity_percentage: number  |  Any display entity  |    |    |
|  entity_set_display_teleport_duration  |  Set display teleport duration  |  Sets the display teleport duration.  |  entity/display_entity  |  duration: number  |  Any display entity  |    |    |
|  entity_set_display_transformation_matrix  |  Set transformation matrix  |  Sets the display entity transformation matrix (row-column).  |  entity  |  row_major_matrix: number  |    |    |  deprecated  |
|  entity_set_display_translation  |  Set offset  |  Sets the display entity offset.  |  entity/display_entity  |  translation_vector: vector<br/>mode: enum<br/>&nbsp;&nbsp;- SET<br/>&nbsp;&nbsp;- ADD  |  Any display entity  |    |    |
|  entity_set_display_view_range  |  Set view distance  |  Sets the display entity view distance.  |  entity/display_entity  |  view_range: number  |  Any display entity  |    |    |
|  entity_set_dragon_phase  |  Set Ender dragon phase  |  Sets the Ender dragon phase.  |  entity/goals  |  phase: enum<br/>&nbsp;&nbsp;- BREATH_ATTACK<br/>&nbsp;&nbsp;- CHARGE_PLAYER<br/>&nbsp;&nbsp;- CIRCLING<br/>&nbsp;&nbsp;- DYING<br/>&nbsp;&nbsp;- FLY_TO_PORTAL<br/>&nbsp;&nbsp;- HOVER<br/>&nbsp;&nbsp;- LAND_ON_PORTAL<br/>&nbsp;&nbsp;- LEAVE_PORTAL<br/>&nbsp;&nbsp;- ROAR_BEFORE_ATTACK<br/>&nbsp;&nbsp;- SEARCH_FOR_BREATH_ATTACK_TARGET<br/>&nbsp;&nbsp;- STRAFING  |  Ender dragons  |    |    |
|  entity_set_dye_color  |  Set entity color  |  Sets the entity color.  |  entity/appearance  |  color: enum<br/>&nbsp;&nbsp;- BLACK<br/>&nbsp;&nbsp;- BLUE<br/>&nbsp;&nbsp;- BROWN<br/>&nbsp;&nbsp;- CYAN<br/>&nbsp;&nbsp;- GRAY<br/>&nbsp;&nbsp;- GREEN<br/>&nbsp;&nbsp;- LIGHT_BLUE<br/>&nbsp;&nbsp;- LIGHT_GRAY<br/>&nbsp;&nbsp;- LIME<br/>&nbsp;&nbsp;- MAGENTA<br/>&nbsp;&nbsp;- ORANGE<br/>&nbsp;&nbsp;- PINK<br/>&nbsp;&nbsp;- PURPLE<br/>&nbsp;&nbsp;- RED<br/>&nbsp;&nbsp;- WHITE<br/>&nbsp;&nbsp;- YELLOW  |  Sheep<br/>Shulkers<br/>Wolf collars<br/>Cat collars  |    |    |
|  entity_set_end_crystal_beam  |  Point End crystal beam  |  Points the End crystal beam at the given location.  |  entity/settings  |  beam: location  |  End crystals  |    |    |
|  entity_set_enderman_block  |  Set Enderman block  |  Sets the Enderman displayed block.  |  entity/appearance  |  block: block  |  Endermen  |    |    |
|  entity_set_equipment_item  |  Set equipment  |  Sets items in one of the entity equipment slots (armor and hand items).  |  entity/miscellaneous  |  item: item<br/>slot: enum<br/>&nbsp;&nbsp;- CHEST<br/>&nbsp;&nbsp;- FEET<br/>&nbsp;&nbsp;- HAND<br/>&nbsp;&nbsp;- HEAD<br/>&nbsp;&nbsp;- LEGS<br/>&nbsp;&nbsp;- OFF_HAND<br/>&nbsp;&nbsp;- BODY<br/>&nbsp;&nbsp;- SADDLE  |    |    |    |
|  entity_set_explosive_power  |  Set explosion power  |  Sets the entity explosion power.  |  entity/parameters  |  power: number  |  Creepers<br/>TNT<br/>Fireballs  |    |    |
|  entity_set_fall_distance  |  Set fall distance  |  Sets the entity fall distance.  |  entity/parameters  |  fall_distance: number  |    |    |    |
|  entity_set_falling_block_type  |  Set Falling Block entity type  |  Sets a new block type for the Falling Block entity.  |  entity/miscellaneous  |  block: block  |  Falling blocks  |    |    |
|  entity_set_fire_ticks  |  Set entity on fire  |  Sets an entity on fire for the chosen time.  |  entity/parameters  |  ticks: number  |    |    |    |
|  entity_set_fishing_wait  |  Set fishing delay  |  Sets the entity fishing delay in ticks.  |  entity/parameters  |  time: number<br/>wait_type: enum<br/>&nbsp;&nbsp;- MIN_MAX_WAIT<br/>&nbsp;&nbsp;- WAIT<br/>&nbsp;&nbsp;- MIN_WAIT<br/>&nbsp;&nbsp;- MAX_WAIT  |  Fishing rod bobber  |    |    |
|  entity_set_fox_leaping  |  Set fox jump animation  |  Sets the fox jump animation.  |  entity/appearance  |  leaping: enum<br/>{TF}  |  Foxes  |    |    |
|  entity_set_fox_type  |  Set fox type  |  Sets the fox type.  |  entity/appearance  |  fox_type: enum<br/>&nbsp;&nbsp;- RED<br/>&nbsp;&nbsp;- SNOW  |  Foxes  |    |    |
|  entity_set_freeze_ticks  |  Set freeze time  |  Sets the entity freeze time (ticks spent in powder snow).  |  entity/parameters  |  ticks: number<br/>ticking_locked: enum<br/>{TF}  |    |    |    |
|  entity_set_friction  |  Set friction  |  Sets whether the entity experiences friction.  |  entity/movement  |  friction: enum<br/>{TFN}  |    |    |    |
|  entity_set_frog_type  |  Set frog type  |  Sets the frog color.  |  entity/appearance  |  frog_variant: enum<br/>&nbsp;&nbsp;- TEMPERATE<br/>&nbsp;&nbsp;- WARM<br/>&nbsp;&nbsp;- COLD  |  Frogs  |    |    |
|  entity_set_fuse_ticks  |  Set fuse time  |  Sets the entity fuse time.  |  entity/parameters  |  fuse_ticks: number  |  Creepers<br/>TNT<br/>TNT minecarts<br/>Firework rockets<br/>Sulfur slimes  |    |    |
|  entity_set_gliding  |  Set elytra flight  |  Sets the entity elytra flight state.  |  entity/movement  |  is_gliding: enum<br/>{TF}  |    |    |    |
|  entity_set_glow_squid_dark  |  Set squid dark time  |  Sets the glow squid dark time in ticks.  |  entity/appearance  |  dark_ticks: number  |  Glow squids  |    |    |
|  entity_set_glowing  |  Set entity glow  |  Sets the entity glowing effect.  |  entity/appearance  |  glowing: enum<br/>{TF}  |    |    |    |
|  entity_set_goat_screaming  |  Set goat screaming  |  Sets the goat screaming flag.  |  entity/settings  |  screams: enum<br/>{TF}  |  Goats  |    |    |
|  entity_set_gravity  |  Set gravity  |  Sets whether the entity obeys gravity.  |  entity/movement  |  gravity: enum<br/>{TF}  |    |    |    |
|  entity_set_hanging_facing_location  |  Set hanging entity block face  |  Sets the block face a hanging entity is on.  |  entity/settings  |  facing: enum<br/>&nbsp;&nbsp;- NORTH<br/>&nbsp;&nbsp;- EAST<br/>&nbsp;&nbsp;- SOUTH<br/>&nbsp;&nbsp;- WEST<br/>&nbsp;&nbsp;- UP<br/>&nbsp;&nbsp;- DOWN<br/>force: enum<br/>{TF}  |  Item frames<br/>Glow item frames<br/>Paintings  |  Paintings cannot be placed on the top or bottom of a block.  |    |
|  entity_set_horse_jump  |  Set horse jump strength  |  Sets the horse jump strength.  |  entity/parameters  |  power: number  |  Horses<br/>Donkeys<br/>Mules<br/>Llamas  |    |    |
|  entity_set_horse_pattern  |  Set horse variant  |  Sets the horse color and variant.  |  entity/appearance  |  horse_color: enum<br/>&nbsp;&nbsp;- WHITE<br/>&nbsp;&nbsp;- CREAMY<br/>&nbsp;&nbsp;- CHESTNUT<br/>&nbsp;&nbsp;- BROWN<br/>&nbsp;&nbsp;- DARK_BROWN<br/>&nbsp;&nbsp;- GRAY<br/>&nbsp;&nbsp;- BLACK<br/>&nbsp;&nbsp;- DO_NOT_CHANGE<br/>horse_style: enum<br/>&nbsp;&nbsp;- NONE<br/>&nbsp;&nbsp;- WHITE<br/>&nbsp;&nbsp;- WHITEFIELD<br/>&nbsp;&nbsp;- WHITE_DOTS<br/>&nbsp;&nbsp;- BLACK_DOTS<br/>&nbsp;&nbsp;- DO_NOT_CHANGE  |  Horses  |    |    |
|  entity_set_immune_to_zombification  |  Set zombification immunity  |  Sets the entity zombification immunity.  |  entity/settings  |  is_immune: enum<br/>{TF}  |  Piglins<br/>Piglin brutes<br/>Hoglins  |    |    |
|  entity_set_interaction_responsive  |  Set interaction entity response  |  Sets whether the interaction entity responds to interactions.  |  entity/settings  |  responsive: enum<br/>{TF}  |    |    |    |
|  entity_set_interaction_size  |  Set interaction entity size  |  Sets the interaction entity horizontal and vertical size.  |  entity/settings  |  width: number<br/>height: number  |    |    |    |
|  entity_set_invisible  |  Set invisibility mode  |  Sets the entity invisibility mode.  |  entity/settings  |  invisible: enum<br/>{TF}  |    |    |    |
|  entity_set_invulnerability_ticks  |  Set invulnerability duration  |  Sets the entity invulnerability duration.  |  entity/parameters  |  ticks: number  |    |    |    |
|  entity_set_invulnerable  |  Set entity invulnerability  |  Makes the entity invulnerable, but in creative mode damage is still possible.  |  entity/settings  |  invulnerable: enum<br/>{TF}  |    |    |    |
|  entity_set_item  |  Set Item entity type  |  Sets the given type (ID) for the Item entity.  |  entity/miscellaneous  |  item: item  |  Items  |    |    |
|  entity_set_item_display_item  |  Set displayed item  |  Sets the item display displayed item.  |  entity/display_entity  |  displayed_item: item  |  Item displays  |    |    |
|  entity_set_item_display_model_type  |  Set item model type  |  Sets the item display displayed item model type.  |  entity/display_entity  |  display_model_type: enum<br/>&nbsp;&nbsp;- FIRSTPERSON_LEFTHAND<br/>&nbsp;&nbsp;- FIRSTPERSON_RIGHTHAND<br/>&nbsp;&nbsp;- FIXED<br/>&nbsp;&nbsp;- GROUND<br/>&nbsp;&nbsp;- GUI<br/>&nbsp;&nbsp;- HEAD<br/>&nbsp;&nbsp;- NONE<br/>&nbsp;&nbsp;- THIRDPERSON_LEFTHAND<br/>&nbsp;&nbsp;- THIRDPERSON_RIGHTHAND  |  Item displays  |    |    |
|  entity_set_item_frame_item_drop_chance  |  Set item frame drop chance  |  Sets the chance the item drops from the frame on destruction.  |  entity/miscellaneous  |  drop_chance: number  |  Item frames<br/>Glow item frames  |    |    |
|  entity_set_item_in_frame  |  Set item in frame  |  Sets the given item in the item frame.  |  entity/appearance  |  item: item<br/>play_sound: enum<br/>{TF}  |  Item frames  |    |    |
|  entity_set_item_owner  |  Set item owner  |  Sets the item entity owner.  |  entity/settings  |  name_or_uuid: text  |  Items  |    |    |
|  entity_set_llama_type  |  Set llama color  |  Sets the llama color.  |  entity/appearance  |  type: enum<br/>&nbsp;&nbsp;- BROWN<br/>&nbsp;&nbsp;- CREAMY<br/>&nbsp;&nbsp;- GRAY<br/>&nbsp;&nbsp;- WHITE  |  Llamas  |    |    |
|  entity_set_location  |  Launch along vector  |  Launches an entity along the given vector.  |  entity/movement  |  velocity: vector<br/>increment: enum<br/>{TF}  |    |    |    |
|  entity_set_mannequin_description  |  Set mannequin description  |  Sets the mannequin description.  |  entity/appearance  |  description: text  |  Mannequins  |    |    |
|  entity_set_mannequin_immovable  |  Set mannequin movement  |  Sets mannequin movement ability.  |  entity/settings  |  immovable: enum<br/>{TF}  |  Mannequins  |    |    |
|  entity_set_mannequin_main_hand  |  Set mannequin main hand  |  Sets the mannequin main hand.  |  entity/appearance  |  hand: enum<br/>&nbsp;&nbsp;- RIGHT<br/>&nbsp;&nbsp;- LEFT  |  Mannequins  |    |    |
|  entity_set_mannequin_skin  |  Set mannequin skin  |  Sets the mannequin skin.  |  entity/appearance  |  name_or_uuid: text<br/>server_type: enum<br/>&nbsp;&nbsp;- MOJANG<br/>&nbsp;&nbsp;- SERVER<br/>&nbsp;&nbsp;- SERVER_DEFAULT  |  Mannequins  |    |    |
|  entity_set_mannequin_skin_model  |  Set mannequin model type  |  Sets the mannequin skin model type  |  entity/appearance  |  model: enum<br/>&nbsp;&nbsp;- CLASSIC<br/>&nbsp;&nbsp;- SLIM<br/>&nbsp;&nbsp;- UNSET  |  Mannequins  |    |    |
|  entity_set_mannequin_skin_parts  |  Set mannequin skin layers  |  Sets the mannequin skin layer display.  |  entity/appearance  |  hat: enum<br/>{TFN}<br/>jacket: enum<br/>{TFN}<br/>left_sleeve: enum<br/>{TFN}<br/>right_sleeve: enum<br/>{TFN}<br/>left_pants: enum<br/>{TFN}<br/>right_pants: enum<br/>{TFN}<br/>cape: enum<br/>{TFN}  |  Mannequins  |    |    |
|  entity_set_mannequin_skin_patch  |  Set mannequin part texture  |  Sets the texture for the given mannequin part.  |  entity/appearance  |  texture_key: text<br/>patch_target: enum<br/>&nbsp;&nbsp;- BODY<br/>&nbsp;&nbsp;- CAPE<br/>&nbsp;&nbsp;- ELYTRA  |  Mannequins  |  If the "Texture key" argument is omitted, the default texture is applied.  |    |
|  entity_set_marker  |  Set marker mode  |  Sets the armor stand marker mode.  |  entity/settings  |  marker: enum<br/>{TF}  |  Armor stands  |    |    |
|  entity_set_max_health  |  Set entity max health  |  Sets the entity max health.  |  entity/parameters  |  max_health: number<br/>heal_to_max: enum<br/>{TF}  |    |    |    |
|  entity_set_max_invulnerability_ticks  |  Set maximum invulnerability duration  |  Sets the maximum invulnerability duration for the creature.  |  entity/parameters  |  ticks: number  |    |    |    |
|  entity_set_merchant_recipe  |  Set villager trade  |  Sets the villager trade for given items at the given index.  |  entity/settings  |  result: item<br/>ingredient_one: item<br/>ingredient_two: item<br/>index: number<br/>mode: enum<br/>&nbsp;&nbsp;- MERGE<br/>&nbsp;&nbsp;- APPEND<br/>uses: number<br/>max_uses: number<br/>villager_experience: number<br/>price_multiplifier: number<br/>demand: number<br/>special_price: number<br/>ignore_discounts: enum<br/>{TF}<br/>experience_reward: enum<br/>{TF}  |  Villagers<br/>Wandering traders  |    |    |
|  entity_set_minecart_block  |  Set block into minecart  |  Sets the given block into the minecart.  |  entity/appearance  |  block: block<br/>block_offset: number  |  Minecarts  |    |    |
|  entity_set_mob_aggressive  |  Set aggressiveness  |  Sets the entity aggressiveness.  |  entity/appearance  |  aggressive: enum<br/>{TF}  |    |    |    |
|  entity_set_mushroom_cow_type  |  Set mooshroom type  |  Sets the mooshroom type.  |  entity/appearance  |  cow_type: enum<br/>&nbsp;&nbsp;- BROWN<br/>&nbsp;&nbsp;- RED  |  Mooshrooms  |    |    |
|  entity_set_no_physics  |  Set entity physics  |  Sets the creature physics.  |  entity/settings  |  no_physics: enum<br/>{TF}  |    |    |    |
|  entity_set_painting_art  |  Set painting art  |  Sets the art for the painting.  |  entity/miscellaneous  |  art: text<br/>force: enum<br/>{TF}  |  Paintings  |    |    |
|  entity_set_panda_gene  |  Set panda gene  |  Sets the panda gene. It affects their behavior and appearance.  |  entity/settings  |  gene: enum<br/>&nbsp;&nbsp;- MAIN<br/>&nbsp;&nbsp;- HIDDEN<br/>&nbsp;&nbsp;- BOTH<br/>gene_type: enum<br/>&nbsp;&nbsp;- NORMAL<br/>&nbsp;&nbsp;- LAZY<br/>&nbsp;&nbsp;- WORRIED<br/>&nbsp;&nbsp;- PLAYFUL<br/>&nbsp;&nbsp;- BROWN<br/>&nbsp;&nbsp;- WEAK<br/>&nbsp;&nbsp;- AGGRESSIVE  |  Pandas  |    |    |
|  entity_set_panda_on_back  |  Sit panda  |  Sets the Panda sitting state.  |  entity/settings  |  on_back: enum<br/>{TF}  |  Pandas  |    |    |
|  entity_set_panda_rolling  |  Set Panda roll state  |  Sets the Panda roll state.  |  entity/goals  |  rolling: enum<br/>{TF}  |  Pandas  |    |    |
|  entity_set_panda_sad_ticks  |  Set Panda sad time  |  Sets the Panda sad time in ticks.  |  entity/parameters  |  sad_ticks: number  |  Pandas  |    |    |
|  entity_set_parrot_type  |  Set parrot type  |  Sets the parrot type.  |  entity/appearance  |  parrot_type: enum<br/>&nbsp;&nbsp;- BLUE<br/>&nbsp;&nbsp;- CYAN<br/>&nbsp;&nbsp;- GRAY<br/>&nbsp;&nbsp;- GREEN<br/>&nbsp;&nbsp;- RED  |  Parrots  |    |    |
|  entity_set_pathfinder_settings  |  Configure pathfinding  |  Sets the parameters and limits for the entity pathfinding  |  entity/goals  |  navigation_type: enum<br/>&nbsp;&nbsp;- DEFAULT<br/>&nbsp;&nbsp;- GROUND<br/>&nbsp;&nbsp;- FLYING<br/>&nbsp;&nbsp;- WATER_BOUND<br/>&nbsp;&nbsp;- AMPHIBIOUS<br/>&nbsp;&nbsp;- SPIDER<br/>&nbsp;&nbsp;- CLIMBER<br/>can_float: enum<br/>{TFN}<br/>can_open_door: enum<br/>{TFN}<br/>can_pass_door: enum<br/>{TFN}  |  Mobs  |    |    |
|  entity_set_persistence  |  Set creature despawning  |  Sets whether the item or falling block despawns.  |  entity/settings  |  persistence: enum<br/>{TF}  |  Items<br/>Falling blocks  |    |    |
|  entity_set_persistent  |  Set entity saving  |  Sets whether the entity will be saved after the world is unloaded.  |  entity/settings  |  persistent: enum<br/>{TF}  |    |    |    |
|  entity_set_pickup  |  Set pickup ability  |  Sets whether the entity can pick things up.  |  entity/settings  |  can_mob_pickup: enum<br/>{TF}<br/>can_player_pickup: enum<br/>{TF}  |  Item entities  |    |    |
|  entity_set_pickup_delay  |  Set pickup cooldown  |  Sets the number of ticks during which the item cannot be picked up.  |  entity/parameters  |  delay: number  |  Items  |    |    |
|  entity_set_pig_type  |  Set pig type  |  Sets the pig color type.  |  entity/appearance  |  variant: enum<br/>&nbsp;&nbsp;- COLD<br/>&nbsp;&nbsp;- WARM<br/>&nbsp;&nbsp;- TEMPERATE  |  Pigs  |    |    |
|  entity_set_piglin_able_to_hunt  |  Set hunting state  |  Sets the piglin hoglin hunting state.  |  entity/goals  |  able: enum<br/>{TF}  |  Piglins  |    |    |
|  entity_set_piglin_charging_crossbow  |  Set crossbow charging state  |  Sets the piglin crossbow charging state.  |  entity/goals  |  charging: enum<br/>{TF}  |  Piglins  |    |    |
|  entity_set_piglin_dancing  |  Set dance stage  |  Sets the piglin dance stage for the given time.  |  entity/goals  |  dancing_time: number  |  Piglins  |  If the duration value is below 0, the dance will last forever.  |    |
|  entity_set_pose  |  Set entity pose  |  Sets the given pose for the creature.  |  entity/appearance  |  pose: enum<br/>&nbsp;&nbsp;- CROAKING<br/>&nbsp;&nbsp;- CROUCHING<br/>&nbsp;&nbsp;- DIGGING<br/>&nbsp;&nbsp;- DYING<br/>&nbsp;&nbsp;- EMERGING<br/>&nbsp;&nbsp;- FALL_FLYING<br/>&nbsp;&nbsp;- INHALING<br/>&nbsp;&nbsp;- LONG_JUMPING<br/>&nbsp;&nbsp;- ROARING<br/>&nbsp;&nbsp;- SITTING<br/>&nbsp;&nbsp;- SLEEPING<br/>&nbsp;&nbsp;- SNIFFING<br/>&nbsp;&nbsp;- SHOOTING<br/>&nbsp;&nbsp;- SLIDING<br/>&nbsp;&nbsp;- SPIN_ATTACK<br/>&nbsp;&nbsp;- STANDING<br/>&nbsp;&nbsp;- SWIMMING<br/>&nbsp;&nbsp;- USING_TONGUE  |    |    |    |
|  entity_set_potion_cloud_radius  |  Set effect cloud radius  |  Sets the effect cloud radius and its expansion speed.  |  entity/parameters  |  radius: number<br/>shrinking_speed: number  |  Effect cloud  |    |    |
|  entity_set_primed_tnt_block  |  Disguise primed TNT as a block  |  Disguises primed TNT as the given block.  |  entity/appearance  |  block: block  |  Primed TNT  |    |    |
|  entity_set_projectile_display_item  |  Set projectile item  |  Sets the projectile visible item.  |  entity/appearance  |  item: item  |    |    |    |
|  entity_set_projectile_power  |  Set projectile motion vector  |  Sets the projectile motion vector.  |  entity/parameters  |  power: vector  |  Fireballs<br/>Dragon charges<br/>Wither skulls  |    |    |
|  entity_set_projectile_shooter  |  Set projectile arrow  |  Sets the given creature as the arrow for the projectile.  |  entity/settings  |  uuid: text  |    |    |    |
|  entity_set_rabbit_type  |  Set rabbit type  |  Sets the rabbit type.  |  entity/appearance  |  rabbit_type: enum<br/>&nbsp;&nbsp;- BLACK<br/>&nbsp;&nbsp;- BLACK_AND_WHITE<br/>&nbsp;&nbsp;- BROWN<br/>&nbsp;&nbsp;- GOLD<br/>&nbsp;&nbsp;- SALT_AND_PEPPER<br/>&nbsp;&nbsp;- THE_KILLER_BUNNY<br/>&nbsp;&nbsp;- WHITE  |  Rabbits  |    |    |
|  entity_set_rearing  |  Set horse pose  |  Sets whether the horse rears up.  |  entity/settings  |  rearing: enum<br/>{TF}  |  Horses  |    |    |
|  entity_set_riptiding  |  Set Riptide animation  |  Sets the Riptide trident enchantment use animation for the creature.  |  entity/settings  |  riptiding: enum<br/>{TF}  |    |    |    |
|  entity_set_rotation  |  Set rotation  |  Rotates the entity.  |  entity/movement  |  yaw: number<br/>pitch: number  |    |    |    |
|  entity_set_rotation_by_vector  |  Set rotation by vector  |  Rotates the entity by a vector.  |  entity/movement  |  vector: vector  |    |    |    |
|  entity_set_sheep_sheared  |  Set sheep wool  |  Sets whether the sheep has wool.  |  entity  |  sheared: enum<br/>{TF}  |    |    |  deprecated  |
|  entity_set_shulker_bullet_target  |  Set shulker bullet target  |  Sets the attack target for the shulker bullet.  |  entity/goals  |  target: text  |  Shulker bullets  |    |    |
|  entity_set_shulker_peek  |  Set shulker open percentage  |  Sets how far the shulker is open, in percent.  |  entity/appearance  |  rolling: number<br/>silent: enum<br/>{TF}  |  Shulkers  |    |    |
|  entity_set_silenced  |  Silence entity  |  Silences the entity sounds.  |  entity/settings  |  silenced: enum<br/>{TF}  |    |    |    |
|  entity_set_sitting  |  Set sitting mode  |  Sets the sitting mode for the creature.  |  entity/settings  |  sitting: enum<br/>{TF}  |  Wolves<br/>Cats<br/>Parrots<br/>Foxes<br/>Pandas  |    |    |
|  entity_set_size  |  Set creature size  |  Sets the creature size.  |  entity/settings  |  size: number  |  Slimes<br/>Phantoms  |    |    |
|  entity_set_sniffer_state  |  Set sniffer state  |  Sets the given sniffer state.  |  entity/settings  |  state: enum<br/>&nbsp;&nbsp;- DIGGING<br/>&nbsp;&nbsp;- FEELING_HAPPY<br/>&nbsp;&nbsp;- IDLING<br/>&nbsp;&nbsp;- RISING<br/>&nbsp;&nbsp;- SCENTING<br/>&nbsp;&nbsp;- SEARCHING<br/>&nbsp;&nbsp;- SNIFFING  |  Sniffers  |    |    |
|  entity_set_snowman_pumpkin  |  Set snow golem pumpkin  |  Sets whether the snow golem pumpkin is visible.  |  entity/appearance  |  pumpkin: enum<br/>{TF}  |  Snow golems  |    |    |
|  entity_set_tame  |  Tame creature  |  Sets the creature attachment to the given owner.  |  entity/settings  |  name_or_uuid: text  |  Wolves<br/>Cats<br/>Horses<br/>Mules<br/>Llamas<br/>Parrots  |    |    |
|  entity_set_target  |  Set creature target  |  Instructs the creature AI to target a certain creature.  |  entity/goals  |  name_or_uuid: text  |  Mobs  |  Leave an empty slot in the Text field to remove the target.  |    |
|  entity_set_text_display_alignment  |  Set text alignment  |  Sets the text display text alignment.  |  entity/display_entity  |  text_alignment: enum<br/>&nbsp;&nbsp;- CENTER<br/>&nbsp;&nbsp;- LEFT<br/>&nbsp;&nbsp;- RIGHT  |  Text displays  |    |    |
|  entity_set_text_display_background  |  Set background color  |  Sets the text display background color and transparency.  |  entity/display_entity  |  color_hexadecimal: text<br/>opacity: number  |  Text displays  |    |    |
|  entity_set_text_display_line_width  |  Set line width  |  Sets the maximum line width for the text display.  |  entity/display_entity  |  line_width: number  |  Text displays  |    |    |
|  entity_set_text_display_opacity  |  Set text transparency  |  Sets the text display text transparency.  |  entity/display_entity  |  text_opacity: number  |  Text displays  |    |    |
|  entity_set_text_display_see_through  |  Set see-through visibility  |  Sets whether the text display text is visible through blocks.  |  entity/display_entity  |  enable_see_through: enum<br/>{TF}  |  Text displays  |    |    |
|  entity_set_text_display_text  |  Set displayed text  |  Sets the displayed text for the text display.  |  entity/display_entity  |  displayed_text: text<br/>merging_mode: enum<br/>&nbsp;&nbsp;- SPACES<br/>&nbsp;&nbsp;- CONCATENATION<br/>&nbsp;&nbsp;- SEPARATE_LINES  |  Text displays  |    |    |
|  entity_set_text_display_text_shadow  |  Set text shadow  |  Sets whether the text display text shadow is visible.  |  entity/display_entity  |  enable_text_shadow: enum<br/>{TF}  |  Text displays  |    |    |
|  entity_set_tropical_fish_pattern  |  Set fish pattern  |  Sets the tropical fish color and pattern.  |  entity/appearance  |  pattern_color: enum<br/>&nbsp;&nbsp;- WHITE<br/>&nbsp;&nbsp;- ORANGE<br/>&nbsp;&nbsp;- MAGENTA<br/>&nbsp;&nbsp;- LIGHT_BLUE<br/>&nbsp;&nbsp;- YELLOW<br/>&nbsp;&nbsp;- LIME<br/>&nbsp;&nbsp;- PINK<br/>&nbsp;&nbsp;- GRAY<br/>&nbsp;&nbsp;- LIGHT_GRAY<br/>&nbsp;&nbsp;- CYAN<br/>&nbsp;&nbsp;- PURPLE<br/>&nbsp;&nbsp;- BLUE<br/>&nbsp;&nbsp;- BROWN<br/>&nbsp;&nbsp;- GREEN<br/>&nbsp;&nbsp;- RED<br/>&nbsp;&nbsp;- BLACK<br/>&nbsp;&nbsp;- DO_NOT_CHANGE<br/>body_color: enum<br/>&nbsp;&nbsp;- WHITE<br/>&nbsp;&nbsp;- ORANGE<br/>&nbsp;&nbsp;- MAGENTA<br/>&nbsp;&nbsp;- LIGHT_BLUE<br/>&nbsp;&nbsp;- YELLOW<br/>&nbsp;&nbsp;- LIME<br/>&nbsp;&nbsp;- PINK<br/>&nbsp;&nbsp;- GRAY<br/>&nbsp;&nbsp;- LIGHT_GRAY<br/>&nbsp;&nbsp;- CYAN<br/>&nbsp;&nbsp;- PURPLE<br/>&nbsp;&nbsp;- BLUE<br/>&nbsp;&nbsp;- BROWN<br/>&nbsp;&nbsp;- GREEN<br/>&nbsp;&nbsp;- RED<br/>&nbsp;&nbsp;- BLACK<br/>&nbsp;&nbsp;- DO_NOT_CHANGE<br/>pattern: enum<br/>&nbsp;&nbsp;- KOB<br/>&nbsp;&nbsp;- SUNSTREAK<br/>&nbsp;&nbsp;- SNOOPER<br/>&nbsp;&nbsp;- DASHER<br/>&nbsp;&nbsp;- BRINELY<br/>&nbsp;&nbsp;- SPOTTY<br/>&nbsp;&nbsp;- FLOPPER<br/>&nbsp;&nbsp;- STRIPEY<br/>&nbsp;&nbsp;- GLITTER<br/>&nbsp;&nbsp;- BLOCKFISH<br/>&nbsp;&nbsp;- BETTY<br/>&nbsp;&nbsp;- CLAYFISH<br/>&nbsp;&nbsp;- DO_NOT_CHANGE  |  Tropical fish  |    |    |
|  entity_set_vex_charging  |  Set Vex anger  |  Sets the Vex anger stage.  |  entity/goals  |  charging: enum<br/>{TF}  |  Vexes  |    |    |
|  entity_set_vex_limited_lifetime_ticks  |  Set Vex lifetime  |  Sets the Vex lifetime in ticks.  |  entity/parameters  |  lifetime: number  |  Vexes  |    |    |
|  entity_set_villager_biome  |  Set villager biome  |  Sets the villager biome-based type.  |  entity/appearance  |  biome: enum<br/>&nbsp;&nbsp;- DESERT<br/>&nbsp;&nbsp;- JUNGLE<br/>&nbsp;&nbsp;- PLAINS<br/>&nbsp;&nbsp;- SAVANNA<br/>&nbsp;&nbsp;- SNOW<br/>&nbsp;&nbsp;- SWAMP<br/>&nbsp;&nbsp;- TAIGA  |  Villagers  |    |    |
|  entity_set_villager_experience  |  Set villager experience  |  Sets the villager experience amount.  |  entity/parameters  |  experience: number  |  Villagers  |    |    |
|  entity_set_villager_profession  |  Set villager profession  |  Sets the given villager profession.  |  entity/settings  |  profession: enum<br/>&nbsp;&nbsp;- NONE<br/>&nbsp;&nbsp;- ARMORER<br/>&nbsp;&nbsp;- BUTCHER<br/>&nbsp;&nbsp;- CARTOGRAPHER<br/>&nbsp;&nbsp;- CLERIC<br/>&nbsp;&nbsp;- FARMER<br/>&nbsp;&nbsp;- FISHERMAN<br/>&nbsp;&nbsp;- FLETCHER<br/>&nbsp;&nbsp;- LEATHERWORKER<br/>&nbsp;&nbsp;- LIBRARIAN<br/>&nbsp;&nbsp;- MASON<br/>&nbsp;&nbsp;- NITWIT<br/>&nbsp;&nbsp;- SHEPHERD<br/>&nbsp;&nbsp;- TOOLSMITH<br/>&nbsp;&nbsp;- WEAPONSMITH  |  Villagers<br/>Zombie villagers  |    |    |
|  entity_set_visual_fire  |  Show fire  |  Shows fire on the creature.  |  entity/appearance  |  visual_fire: enum<br/>{TFN}  |    |    |    |
|  entity_set_warden_anger_level  |  Set Warden anger level  |  Sets the given Warden anger level towards the given entity.  |  entity/parameters  |  name_or_uuid: text<br/>anger: number  |  Wardens  |  If the anger level towards an entity reaches 80, the Warden starts actively chasing it.  |    |
|  entity_set_warden_digging  |  Set Warden digging type  |  Sets the Warden digging type.  |  entity/miscellaneous  |  digging: enum<br/>&nbsp;&nbsp;- EMERGE<br/>&nbsp;&nbsp;- DIG_DOWN  |  Warden  |    |    |
|  entity_set_waypoint_color  |  Set locator icon color  |  Sets the color of the icon shown on the locator for the entity.  |  entity/settings  |  red: number<br/>green: number<br/>blue: number  |  Mobs  |  The game rule "Locator visibility" must be enabled for this action to work.  |    |
|  entity_set_waypoint_style  |  Set locator icon style  |  Sets the style of the icon shown on the locator for the entity.  |  entity/settings  |  style: text  |  Mobs  |    |    |
|  entity_set_wearing_saddle  |  Set saddle visibility  |  Sets the saddle for the creature.  |  entity/settings  |  wearing: enum<br/>{TF}  |  Pigs<br/>Horses<br/>Lava squids  |    |    |
|  entity_set_wither_invulnerability_ticks  |  Set Wither invulnerability  |  Sets the Wither invulnerability duration.  |  entity/parameters  |  ticks: number  |  Wither  |    |    |
|  entity_set_wolf_sound_variant  |  Set wolf sound  |  Sets the wolf sound type.  |  entity/settings  |  sound_variant: enum<br/>&nbsp;&nbsp;- ANGRY<br/>&nbsp;&nbsp;- BIG<br/>&nbsp;&nbsp;- CLASSIC<br/>&nbsp;&nbsp;- CUTE<br/>&nbsp;&nbsp;- GRUMPY<br/>&nbsp;&nbsp;- PUGLIN<br/>&nbsp;&nbsp;- SAD  |  Wolves  |    |    |
|  entity_set_wolf_type  |  Set wolf type  |  Sets the wolf type.  |  entity/appearance  |  wolf_type: enum<br/>&nbsp;&nbsp;- ASHEN<br/>&nbsp;&nbsp;- SNOWY<br/>&nbsp;&nbsp;- RUSTY<br/>&nbsp;&nbsp;- BLACK<br/>&nbsp;&nbsp;- CHESTNUT<br/>&nbsp;&nbsp;- SPOTTED<br/>&nbsp;&nbsp;- STRIPED<br/>&nbsp;&nbsp;- PALE<br/>&nbsp;&nbsp;- WOODS  |  Wolves  |    |    |
|  entity_set_zombie_arms_raised  |  Set zombie arms raised  |  Sets the zombie arms raised animation.  |  entity  |  arms_raised: enum<br/>{TF}  |    |    |  deprecated  |
|  entity_set_zombie_nautilus_variant  |  Set zombified nautilus type  |  Sets the zombified nautilus type.  |  entity/appearance  |  variant: enum<br/>&nbsp;&nbsp;- TEMPERATE<br/>&nbsp;&nbsp;- WARM  |  Zombified nautiluses  |    |    |
|  entity_shear  |  Shear entity  |  Shears the entity.  |  entity/miscellaneous  |    |  Sheep<br/>Mooshrooms<br/>Swamp creature<br/>Snow golems  |    |    |
|  entity_shear_sheep  |  Shear sheep  |  Shears a sheep.  |  entity  |    |    |    |  deprecated  |
|  entity_sleep  |  Set sleeping animation  |  Sets the sleeping animation for the creature. Best used in a loop.  |  entity/goals  |  sleep: enum<br/>{TF}  |  Foxes  |    |    |
|  entity_swing_hand  |  Play arm swing animation  |  Plays the arm swing animation for the entity.  |  entity/appearance  |  hand_type: enum<br/>&nbsp;&nbsp;- MAIN<br/>&nbsp;&nbsp;- OFF  |    |    |    |
|  entity_teleport  |  Teleportation  |  Teleports the creature to the chosen location.  |  entity/movement  |  location: location<br/>keep_rotation: enum<br/>{TF}  |    |    |    |
|  entity_use_item  |  Use item  |  Instructs the creature AI to use the item in its hand.  |  entity/goals  |  hand: enum<br/>&nbsp;&nbsp;- MAIN_HAND<br/>&nbsp;&nbsp;- OFF_HAND<br/>enable: enum<br/>{TF}  |  Mobs  |    |    |
|  if_entity_collides_at_location  |  Collides at location  |  Checks whether the entity collides with blocks, shulkers, boats and the world border at the given location.  |  if_entity  |  location: location  |    |    |    |
|  if_entity_collides_using_hitbox  |  Collides using a custom hitbox  |  Checks whether the entity collides with blocks, shulkers, boats and the world border using a custom hitbox.  |  if_entity  |  min: location<br/>max: location  |    |    |    |
|  if_entity_collides_with_entity  |  Collides with entity  |  Checks whether the entity hitbox collides with the hitbox of another given entity.  |  if_entity  |  name_or_uuid: text<br/>check_type: enum<br/>&nbsp;&nbsp;- OVERLAPS<br/>&nbsp;&nbsp;- CONTAINS  |    |    |    |
|  if_entity_exists  |  Exists  |  Checks whether the creature is in the world.  |  if_entity  |    |    |    |    |
|  if_entity_has_available_path  |  Has a path available  |  Checks whether the entity can build a path to the given point or target  |  if_entity  |    |    |    |    |
|  if_entity_has_custom_tag  |  Has custom tag  |  Checks whether the creature has a custom tag with the given value.  |  if_entity  |  tag: text<br/>tag_value: text<br/>compare_type: enum<br/>&nbsp;&nbsp;- EQUALS<br/>&nbsp;&nbsp;- CONTAINS<br/>&nbsp;&nbsp;- STARTS_WITH<br/>&nbsp;&nbsp;- ENDS_WITH  |    |    |    |
|  if_entity_has_potion_effect  |  Has potion effect  |  Checks whether the creature has a potion effect.  |  if_entity  |  potions: potion<br/>check_mode: enum<br/>{ANY_ALL}  |    |    |    |
|  if_entity_in_area  |  Inside region  |  Checks whether the entity is in the given region.  |  if_entity  |  location_1: location<br/>location_2: location<br/>ignore_y_axis: enum<br/>{TF}<br/>intersect_type: enum<br/>&nbsp;&nbsp;- POINT<br/>&nbsp;&nbsp;- HITBOX<br/>check_type: enum<br/>&nbsp;&nbsp;- OVERLAPS<br/>&nbsp;&nbsp;- CONTAINS  |    |    |    |
|  if_entity_is_disguised  |  Disguised  |  Checks whether the entity is disguised.  |  if_entity  |    |    |    |    |
|  if_entity_is_grounded  |  Touches the block surface  |  Checks whether the creature touches the block surface.  |  if_entity  |    |    |    |    |
|  if_entity_is_item  |  Is an item  |  Checks whether the creature is an item.  |  if_entity  |    |    |    |    |
|  if_entity_is_minecraft_tagged  |  Has Minecraft tag  |  Checks whether the entity has the given Minecraft tag (e.g. "aquatic").  |  if_entity  |  namespace: text  |    |  The Minecraft tag must start with "#minecraft:"  |    |
|  if_entity_is_mob  |  Is a mob  |  Checks whether the creature is a mob.  |  if_entity  |    |    |    |    |
|  if_entity_is_near_location  |  Near location  |  Checks whether the creature is near the given location.  |  if_entity  |  ignore_y_axis: enum<br/>{TF}<br/>location: location<br/>range: number  |    |    |    |
|  if_entity_is_projectile  |  Is a projectile  |  Checks whether the creature is a projectile.  |  if_entity  |    |    |    |    |
|  if_entity_is_riding_entity  |  Entity rides entity  |  Checks whether the entity is riding any of the other given entities.  |  if_entity  |  entity_ids: text<br/>compare_mode: enum<br/>&nbsp;&nbsp;- TYPE<br/>&nbsp;&nbsp;- NAME_OR_UUID  |    |    |    |
|  if_entity_is_standing_on_block  |  Standing on block  |  Checks whether the entity is standing on a certain block or location.  |  if_entity  |  blocks: block<br/>locations: location<br/>only_solid: enum<br/>{TF}  |    |    |    |
|  if_entity_is_type  |  Creature type equals  |  Checks whether the creature type equals the type in the chest.  |  if_entity  |  entity_types: item  |    |    |    |
|  if_entity_is_undead  |  Is undead  |  Checks whether the creature is undead.  |  if_entity  |    |    |    |    |
|  if_entity_is_vehicle  |  Is a vehicle  |  Checks whether the creature is a vehicle.  |  if_entity  |    |    |    |    |
|  if_entity_name_equals  |  Name equals  |  Checks whether the creature name equals the name in the chest.  |  if_entity  |  names_or_uuids: text  |    |    |    |
|  if_entity_spawn_reason_equals  |  Spawn reason equals  |  Checks whether the creature spawn reason equals a certain value.  |  if_entity  |  reason: enum<br/>&nbsp;&nbsp;- BEEHIVE<br/>&nbsp;&nbsp;- BREEDING<br/>&nbsp;&nbsp;- BUILD_IRONGOLEM<br/>&nbsp;&nbsp;- BUILD_SNOWMAN<br/>&nbsp;&nbsp;- BUILD_WITHER<br/>&nbsp;&nbsp;- COMMAND<br/>&nbsp;&nbsp;- CURED<br/>&nbsp;&nbsp;- CUSTOM<br/>&nbsp;&nbsp;- DEFAULT<br/>&nbsp;&nbsp;- DISPENSE_EGG<br/>&nbsp;&nbsp;- DROWNED<br/>&nbsp;&nbsp;- EGG<br/>&nbsp;&nbsp;- ENDER_PEARL<br/>&nbsp;&nbsp;- EXPLOSION<br/>&nbsp;&nbsp;- FROZEN<br/>&nbsp;&nbsp;- INFECTION<br/>&nbsp;&nbsp;- JOCKEY<br/>&nbsp;&nbsp;- LIGHTNING<br/>&nbsp;&nbsp;- MOUNT<br/>&nbsp;&nbsp;- NATURAL<br/>&nbsp;&nbsp;- NETHER_PORTAL<br/>&nbsp;&nbsp;- OCELOT_BABY<br/>&nbsp;&nbsp;- PATROL<br/>&nbsp;&nbsp;- PIGLIN_ZOMBIFIED<br/>&nbsp;&nbsp;- RAID<br/>&nbsp;&nbsp;- REINFORCEMENTS<br/>&nbsp;&nbsp;- SHEARED<br/>&nbsp;&nbsp;- SHOULDER_ENTITY<br/>&nbsp;&nbsp;- SILVERFISH_BLOCK<br/>&nbsp;&nbsp;- SLIME_SPLIT<br/>&nbsp;&nbsp;- SPAWNER<br/>&nbsp;&nbsp;- SPAWNER_EGG<br/>&nbsp;&nbsp;- TRAP<br/>&nbsp;&nbsp;- VILLAGER_DEFENSE<br/>&nbsp;&nbsp;- VILLAGE_INVASION  |    |    |    |

## Quick ref
> Argument **names and types only**, one line per action/condition — scan this first. Exact enum values and extra info: see the full table row above. ⚠ deprecated = do not use.

- `entity_attach_lead` — (no arguments)
- `entity_celar_potion_effects` — (no arguments)
- `entity_clear_merchant_recipes` — (no arguments)
- `entity_complete_using_active_item` — (no arguments)
- `entity_damage` — (no arguments)
- `entity_disguise_as_block` — (no arguments)
- `entity_disguise_as_entity` — (no arguments)
- `entity_disguise_as_item` — (no arguments)
- `entity_disguise_as_player` — (no arguments)
- `entity_eat_grass` — (no arguments)
- `entity_eat_target` — (no arguments)
- `entity_explode` — (no arguments)
- `entity_face_location` — (no arguments)
- `entity_get_attribute` — (no arguments)
- `entity_get_custom_tag` — (no arguments)
- `entity_get_custom_tags` — (no arguments)
- `entity_get_equipment_item` — (no arguments)
- `entity_get_nbt` — (no arguments)
- `entity_give_potion_effects` — (no arguments)
- `entity_heal` — (no arguments)
- `entity_ignite_creeper` — (no arguments)
- `entity_jump` — (no arguments)
- `entity_launch_forward` — (no arguments)
- `entity_launch_projectile` — (no arguments)
- `entity_launch_to_location` — (no arguments)
- `entity_launch_up` — (no arguments)
- `entity_leave_vehicle` — (no arguments)
- `entity_mimic_disguise_from_entity` — (no arguments)
- `entity_modify_piglin_barter_materials` — (no arguments)
- `entity_modify_piglin_interested_materials` — (no arguments)
- `entity_move_to_location` — (no arguments)
- `entity_move_to_location_stop` — (no arguments)
- `entity_play_damage_animation` — (no arguments)
- `entity_play_hurt_animation` — (no arguments)
- `entity_ram_target` — (no arguments)
- `entity_remove` — (no arguments)
- `entity_remove_custom_tag` — (no arguments)
- `entity_remove_custom_tags` — (no arguments)
- `entity_remove_disguise` — (no arguments)
- `entity_remove_merchant_recipe` — (no arguments)
- `entity_remove_potion_effect` — (no arguments)
- `entity_reset_display_brightness` — (no arguments)
- `entity_reset_display_glow_color` — (no arguments)
- `entity_reset_mannequin_description` — (no arguments)
- `entity_reset_text_display_background` — (no arguments)
- `entity_reset_waypoint_color` — (no arguments)
- `entity_retrieve_fishing_hook` — (no arguments)
- `entity_ride_entity` — (no arguments)
- `entity_roll_armadillo` — (no arguments)
- `entity_set_absorption_health` — (no arguments)
- `entity_set_age_lock` — (no arguments)
- `entity_set_ai` — (no arguments)
- `entity_set_allay_dancing` — (no arguments)
- `entity_set_angry` — (no arguments)
- `entity_set_animal_age` — (no arguments)
- `entity_set_armor_items` — (no arguments)
- `entity_set_armor_stand_parts` — (no arguments)
- `entity_set_armor_stand_pose` — (no arguments)
- `entity_set_arrow_hit_sound` — (no arguments)
- `entity_set_arrow_pierce` — (no arguments)
- `entity_set_attribute` — (no arguments)
- `entity_set_aware` — (no arguments)
- `entity_set_axolotl_type` — (no arguments)
- `entity_set_baby` — (no arguments)
- `entity_set_base_arrow_damage` — (no arguments)
- `entity_set_bee_has_stinger` — (no arguments)
- `entity_set_bee_nectar` — (no arguments)
- `entity_set_block_display_block` — (no arguments)
- `entity_set_camel_dashing` — (no arguments)
- `entity_set_carrying_chest` — (no arguments)
- `entity_set_cat_lying_down` — (no arguments)
- `entity_set_cat_type` — (no arguments)
- `entity_set_celebrating` — (no arguments)
- `entity_set_chicken_type` — (no arguments)
- `entity_set_collidable` — (no arguments)
- `entity_set_copper_golem_oxidizing` — (no arguments)
- `entity_set_copper_golem_oxidizing_at_time` — (no arguments)
- `entity_set_copper_golem_weathering` — (no arguments)
- `entity_set_cow_type` — (no arguments)
- `entity_set_creeper_charge` — (no arguments)
- `entity_set_creeper_fuse` — (no arguments)
- `entity_set_current_health` — (no arguments)
- `entity_set_custom_name` — (no arguments)
- `entity_set_custom_name_visibility` — (no arguments)
- `entity_set_custom_tag` — (no arguments)
- `entity_set_death_drops` — (no arguments)
- `entity_set_death_time` — (no arguments)
- `entity_set_default_visible` — (no arguments)
- `entity_set_despawning` — (no arguments)
- `entity_set_display_billboard` — (no arguments)
- `entity_set_display_brightness` — (no arguments)
- `entity_set_display_correct_transformation_matrix` — (no arguments)
- `entity_set_display_culling_suze` — (no arguments)
- `entity_set_display_glow_color` — (no arguments)
- `entity_set_display_interpolation` — (no arguments)
- `entity_set_display_rotation_from_axis_angle` — (no arguments)
- `entity_set_display_rotation_from_euler_angles` — (no arguments)
- `entity_set_display_rotation_from_vector` — (no arguments)
- `entity_set_display_scale` — (no arguments)
- `entity_set_display_shadow` — (no arguments)
- `entity_set_display_teleport_duration` — (no arguments)
- `entity_set_display_transformation_matrix` — (no arguments) ⚠ deprecated
- `entity_set_display_translation` — (no arguments)
- `entity_set_display_view_range` — (no arguments)
- `entity_set_dragon_phase` — (no arguments)
- `entity_set_dye_color` — (no arguments)
- `entity_set_end_crystal_beam` — (no arguments)
- `entity_set_enderman_block` — (no arguments)
- `entity_set_equipment_item` — (no arguments)
- `entity_set_explosive_power` — (no arguments)
- `entity_set_fall_distance` — (no arguments)
- `entity_set_falling_block_type` — (no arguments)
- `entity_set_fire_ticks` — (no arguments)
- `entity_set_fishing_wait` — (no arguments)
- `entity_set_fox_leaping` — (no arguments)
- `entity_set_fox_type` — (no arguments)
- `entity_set_freeze_ticks` — (no arguments)
- `entity_set_friction` — (no arguments)
- `entity_set_frog_type` — (no arguments)
- `entity_set_fuse_ticks` — (no arguments)
- `entity_set_gliding` — (no arguments)
- `entity_set_glow_squid_dark` — (no arguments)
- `entity_set_glowing` — (no arguments)
- `entity_set_goat_screaming` — (no arguments)
- `entity_set_gravity` — (no arguments)
- `entity_set_hanging_facing_location` — (no arguments)
- `entity_set_horse_jump` — (no arguments)
- `entity_set_horse_pattern` — (no arguments)
- `entity_set_immune_to_zombification` — (no arguments)
- `entity_set_interaction_responsive` — (no arguments)
- `entity_set_interaction_size` — (no arguments)
- `entity_set_invisible` — (no arguments)
- `entity_set_invulnerability_ticks` — (no arguments)
- `entity_set_invulnerable` — (no arguments)
- `entity_set_item` — (no arguments)
- `entity_set_item_display_item` — (no arguments)
- `entity_set_item_display_model_type` — (no arguments)
- `entity_set_item_frame_item_drop_chance` — (no arguments)
- `entity_set_item_in_frame` — (no arguments)
- `entity_set_item_owner` — (no arguments)
- `entity_set_llama_type` — (no arguments)
- `entity_set_location` — (no arguments)
- `entity_set_mannequin_description` — (no arguments)
- `entity_set_mannequin_immovable` — (no arguments)
- `entity_set_mannequin_main_hand` — (no arguments)
- `entity_set_mannequin_skin` — (no arguments)
- `entity_set_mannequin_skin_model` — (no arguments)
- `entity_set_mannequin_skin_parts` — (no arguments)
- `entity_set_mannequin_skin_patch` — (no arguments)
- `entity_set_marker` — (no arguments)
- `entity_set_max_health` — (no arguments)
- `entity_set_max_invulnerability_ticks` — (no arguments)
- `entity_set_merchant_recipe` — (no arguments)
- `entity_set_minecart_block` — (no arguments)
- `entity_set_mob_aggressive` — (no arguments)
- `entity_set_mushroom_cow_type` — (no arguments)
- `entity_set_no_physics` — (no arguments)
- `entity_set_painting_art` — (no arguments)
- `entity_set_panda_gene` — (no arguments)
- `entity_set_panda_on_back` — (no arguments)
- `entity_set_panda_rolling` — (no arguments)
- `entity_set_panda_sad_ticks` — (no arguments)
- `entity_set_parrot_type` — (no arguments)
- `entity_set_pathfinder_settings` — (no arguments)
- `entity_set_persistence` — (no arguments)
- `entity_set_persistent` — (no arguments)
- `entity_set_pickup` — (no arguments)
- `entity_set_pickup_delay` — (no arguments)
- `entity_set_pig_type` — (no arguments)
- `entity_set_piglin_able_to_hunt` — (no arguments)
- `entity_set_piglin_charging_crossbow` — (no arguments)
- `entity_set_piglin_dancing` — (no arguments)
- `entity_set_pose` — (no arguments)
- `entity_set_potion_cloud_radius` — (no arguments)
- `entity_set_primed_tnt_block` — (no arguments)
- `entity_set_projectile_display_item` — (no arguments)
- `entity_set_projectile_power` — (no arguments)
- `entity_set_projectile_shooter` — (no arguments)
- `entity_set_rabbit_type` — (no arguments)
- `entity_set_rearing` — (no arguments)
- `entity_set_riptiding` — (no arguments)
- `entity_set_rotation` — (no arguments)
- `entity_set_rotation_by_vector` — (no arguments)
- `entity_set_sheep_sheared` — (no arguments) ⚠ deprecated
- `entity_set_shulker_bullet_target` — (no arguments)
- `entity_set_shulker_peek` — (no arguments)
- `entity_set_silenced` — (no arguments)
- `entity_set_sitting` — (no arguments)
- `entity_set_size` — (no arguments)
- `entity_set_sniffer_state` — (no arguments)
- `entity_set_snowman_pumpkin` — (no arguments)
- `entity_set_tame` — (no arguments)
- `entity_set_target` — (no arguments)
- `entity_set_text_display_alignment` — (no arguments)
- `entity_set_text_display_background` — (no arguments)
- `entity_set_text_display_line_width` — (no arguments)
- `entity_set_text_display_opacity` — (no arguments)
- `entity_set_text_display_see_through` — (no arguments)
- `entity_set_text_display_text` — (no arguments)
- `entity_set_text_display_text_shadow` — (no arguments)
- `entity_set_tropical_fish_pattern` — (no arguments)
- `entity_set_vex_charging` — (no arguments)
- `entity_set_vex_limited_lifetime_ticks` — (no arguments)
- `entity_set_villager_biome` — (no arguments)
- `entity_set_villager_experience` — (no arguments)
- `entity_set_villager_profession` — (no arguments)
- `entity_set_visual_fire` — (no arguments)
- `entity_set_warden_anger_level` — (no arguments)
- `entity_set_warden_digging` — (no arguments)
- `entity_set_waypoint_color` — (no arguments)
- `entity_set_waypoint_style` — (no arguments)
- `entity_set_wearing_saddle` — (no arguments)
- `entity_set_wither_invulnerability_ticks` — (no arguments)
- `entity_set_wolf_sound_variant` — (no arguments)
- `entity_set_wolf_type` — (no arguments)
- `entity_set_zombie_arms_raised` — (no arguments) ⚠ deprecated
- `entity_set_zombie_nautilus_variant` — (no arguments)
- `entity_shear` — (no arguments)
- `entity_shear_sheep` — (no arguments) ⚠ deprecated
- `entity_sleep` — (no arguments)
- `entity_swing_hand` — (no arguments)
- `entity_teleport` — (no arguments)
- `entity_use_item` — (no arguments)
- `if_entity_collides_at_location` — (no arguments)
- `if_entity_collides_using_hitbox` — (no arguments)
- `if_entity_collides_with_entity` — (no arguments)
- `if_entity_exists` — (no arguments)
- `if_entity_has_available_path` — (no arguments)
- `if_entity_has_custom_tag` — (no arguments)
- `if_entity_has_potion_effect` — (no arguments)
- `if_entity_in_area` — (no arguments)
- `if_entity_is_disguised` — (no arguments)
- `if_entity_is_grounded` — (no arguments)
- `if_entity_is_item` — (no arguments)
- `if_entity_is_minecraft_tagged` — (no arguments)
- `if_entity_is_mob` — (no arguments)
- `if_entity_is_near_location` — (no arguments)
- `if_entity_is_projectile` — (no arguments)
- `if_entity_is_riding_entity` — (no arguments)
- `if_entity_is_standing_on_block` — (no arguments)
- `if_entity_is_type` — (no arguments)
- `if_entity_is_undead` — (no arguments)
- `if_entity_is_vehicle` — (no arguments)
- `if_entity_name_equals` — (no arguments)
- `if_entity_spawn_reason_equals` — (no arguments)
